# Historial de cambios

## v1.1

- Añade módulos de despeje que permiten seleccionar el dato faltante.
- Resuelve `p` o el mejor `n` entero desde una probabilidad binomial.
- Resuelve `lambda` desde cualquier evento Poisson y calcula cuantiles discretos.
- Amplía los momentos binomiales: `n,p` desde media-varianza, `n` desde media-`p`, `p` desde media-`n` y las dos soluciones de `p` desde varianza-`n`.
- Despeja cualquiera de los cuatro valores de la regla de escalado Poisson.
- Permite hallar el `p` individual requerido para una probabilidad de aprobar dada.
- Resuelve corte, media o desviación normal con una condición y media-desviación con un sistema de dos condiciones.
- Añade intervalos normales simétricos inversos.
- Despeja corte, media, desviación o tamaño `n` en medias muestrales y sumas.
- Añade sistemas de dos ecuaciones para `Xbarra` y para sumas.
- Despeja `n`, error máximo o desviación en la relación de confianza.
- Acepta colas derechas directamente y las transforma en acumuladas izquierdas.
- Verifica cada raíz inversa por sustitución y contempla soluciones múltiples o tangentes.
- Eleva la regresión determinista de 28 a 51 comprobaciones.

## v1.0

- Primera versión para las unidades 1, 2 y 3.
