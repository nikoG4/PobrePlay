# Compilación e instalación en Windows 10

La Graph 35+E II pertenece a la familia fx-9860GIII y utiliza add-ins `.g1a`. fxSDK soporta oficialmente Linux y Ubuntu sobre WSL; Windows nativo no es el entorno recomendado.

## 1. Preparar WSL

En PowerShell como administrador:

```powershell
wsl --install
```

Reinicie si Windows lo solicita, abra Ubuntu y cree el usuario Linux. En Windows 10, `wsl --install` requiere la versión 2004/build 19041 o posterior.

## 2. Instalar fxSDK y gint

Dentro de Ubuntu/WSL:

```bash
sudo apt update
sudo apt install -y curl git python3 build-essential cmake pkg-config \
  python3-pil libusb-1.0-0-dev libsdl2-dev

curl "https://gitea.planet-casio.com/Lephenixnoir/GiteaPC/raw/branch/master/install.sh" \
  -o /tmp/giteapc-install.sh
bash /tmp/giteapc-install.sh
source ~/.profile

giteapc install Lephenixnoir/fxsdk noudisks2 \
  Lephenixnoir/sh-elf-binutils Lephenixnoir/sh-elf-gcc
giteapc install Lephenixnoir/OpenLibm Vhex-Kernel-Core/fxlibc \
  Lephenixnoir/sh-elf-gcc
giteapc install Lephenixnoir/gint
```

La construcción inicial del compilador cruzado puede tardar. Si el instalador indica que modificó otra configuración de shell, cierre Ubuntu y vuelva a abrirlo en lugar de ejecutar `source ~/.profile`.

## 3. Compilar

Conviene trabajar dentro del sistema de archivos Linux, por ejemplo `~/StatSolve-U123`, y no directamente bajo `/mnt/c`.

```bash
cd ~/StatSolve-U123
./tests/run_host_tests.sh
fxsdk build-fx
fxgxa -d STAT-U123.g1a
```

Resultados esperados:

- las pruebas muestran `PASS: 28 numerical checks`;
- `fxsdk build-fx` termina sin errores;
- `fxgxa -d` reconoce el encabezado y el nombre `STAT U123`.

## 4. Copiar a la Graph 35+E II

1. Conecte la calculadora por USB con un cable de datos.
2. Seleccione en la calculadora el modo de almacenamiento USB cuando lo solicite.
3. En el Explorador de Windows abra la unidad extraíble de la calculadora.
4. Copie `STAT-U123.g1a` al **directorio raíz**, no dentro de una carpeta.
5. Expulse la unidad de forma segura y termine la conexión USB.
6. El icono de la curva normal con sigma debe aparecer en el menú principal como `STAT U123`.

Si no aparece, confirme que el archivo termina en `.g1a`, está en la raíz y que `fxgxa -d STAT-U123.g1a` lo valida. CASIO recomienda tener el sistema operativo actualizado antes de instalar add-ins.

Referencias: [compatibilidad y compilación de fxSDK](https://github.com/lephe/Fx-SDK), [modelos compatibles y add-ins de CASIO](https://edu.casio.com/intl/support/downloads/) y [guía oficial de transferencia](https://edu.casio.com/content/dam/casio/global/edu-casio-com/download/files/19_Inst_Users_Guide.pdf).
