# STAT U123 v1.1 para Casio Graph 35+E II

Add-in nativo de estadística para las unidades 1, 2 y 3 de **Estadísticas y Probabilidades II**. El proyecto genera `STAT-U123.g1a`, compatible con la Casio Graph 35+E II y la familia fx-9860GIII/fx-9750GIII.

El objetivo no es guardar ejercicios concretos, sino resolver sus variantes numéricas. Cada módulo pide los parámetros, identifica el evento y muestra la transformación, los parámetros derivados, los puntajes `z` cuando corresponda y el resultado.

## Funciones incluidas

- Unidad 1: binomial y Poisson directas; despeje numérico de `p`, `n` o `lambda` desde una probabilidad; cuantiles discretos; despejes de momentos y sistema para obtener `n,p` desde media y varianza; escalado de tasas con cualquiera de los cuatro valores como incógnita; examen con penalización directo o con `p` requerido; frecuencia esperada y su despeje; aproximación binomial-Poisson.
- Unidad 2: normal directa; despeje de corte, `mu` o `sigma`; sistema de dos ecuaciones para reconstruir `mu,sigma`; intervalos simétricos; aproximación normal a binomial con corrección de continuidad y frecuencia esperada.
- Unidad 3: distribución de la media muestral; despeje de corte, `mu`, `sigma` o `n`; sistemas de dos condiciones; corrección por población finita opcional; suma/peso total directa e inversa; tamaño muestral, error y desviación como posibles incógnitas.

La [matriz de cobertura](docs/COBERTURA.md) relaciona estos módulos con las variantes de las guías, las clases, el control y los capítulos de los libros.

## Estado de verificación

- Núcleo matemático compilado en C11 con `-Wall -Wextra -Werror -pedantic`.
- Interfaz comprobada sintácticamente con dobles de la API de gint.
- **51 comprobaciones numéricas aprobadas**, tomadas de las guías 1-3, el control y variantes directas, inversas y por sistema.
- **216 recorridos inversos aleatorios aprobados**: se generó una probabilidad desde parámetros conocidos y se comprobó que el resolutor recuperara el parámetro original.
- Cálculos estables alrededor de la moda para binomial; colas directas para Poisson; CDF normal e inversa sin depender de una tabla Z almacenada.

Ejecutar las pruebas en Linux/WSL:

```bash
./tests/run_host_tests.sh
```

## Compilar el `.g1a`

Se necesita fxSDK con el compilador cruzado SuperH y gint. Con el entorno instalado:

```bash
fxsdk build-fx
fxgxa -d STAT-U123.g1a
```

El primer comando construye el add-in de la familia fx-9860G y deja `STAT-U123.g1a` en la raíz del proyecto. Consulte [INSTALAR.md](INSTALAR.md) para preparar WSL en Windows 10 y copiarlo a la calculadora.

## Uso básico

1. Seleccione la unidad con `↑`/`↓` y `EXE`.
2. Ingrese decimales con punto (`0.25`, no `0,25`).
3. En distribuciones discretas elija la desigualdad exacta del enunciado.
4. En un problema inverso con cola derecha `r`, ingrese como área izquierda `F=1-r`.
5. Recorra el desarrollo con `↑`/`↓`; `EXIT` vuelve al menú anterior.

## Cómo resolver variantes

- Si el enunciado entrega todos los parámetros y pide una probabilidad, use el módulo directo (`Binomial`, `Poisson`, `Normal`, `Media muestral` o `Suma`).
- Si pregunta “¿qué valor debe tener...?”, elija un módulo `despejar` y seleccione el dato faltante.
- Si entrega dos porcentajes o dos cortes para hallar dos parámetros, use un módulo `Sistema`.
- Puede ingresar una cola derecha directamente; el add-in la convierte a área izquierda `F=1-r`.
- En inversiones no monótonas puede haber dos respuestas. El add-in muestra todas las raíces encontradas y vuelve a calcular la probabilidad para verificar cada una.
- Cuando la incógnita es `n`, primero muestra el valor teórico y después los enteros vecinos que deben compararse, porque un tamaño de muestra o una cantidad de elementos no puede ser fraccionario.

## Límites deliberados

- La unidad 4 (proporciones, diferencias e intervalos de confianza) no se incluyó porque el alcance solicitado fue unidades 1-3.
- La normal usa cálculo numérico, por lo que puede diferir en las últimas cifras de una respuesta obtenida redondeando una tabla Z a dos decimales.
- La corrección por población finita se aplica solo si se ingresa `N>0`; con `N=0` se usa `sigma/sqrt(n)`.
- Las búsquedas inversas de binomial admiten `n<=5000` en la interfaz para mantener un tiempo razonable en la calculadora. Poisson busca `lambda` entre `0` y `1 000 000`.
- Use el add-in durante una evaluación únicamente si las reglas de la institución y el docente lo permiten. El modo examen puede restringir programas y aplicaciones.

## Fuentes de diseño

- Guías, clases, formulario y control incluidos en `estadistica 2.zip`.
- [Estadística aplicada a los negocios y la economía](https://gc.scalahed.com/recursos/files/r161r/w25633w/Estadistica%20para%20Administracion%20y%20Negocios.pdf), especialmente capítulos 6-8.
- [Copia de Biblioteca Digital de la Universidad de Cuenca](https://biblioteca.ucuenca.edu.ec/digital/files/original/9a93536fd61609f0e457e10b145f89af0bb7dc40.pdf).
- [fxSDK](https://github.com/lephe/Fx-SDK), formato `.g1a`, plataforma y flujo de compilación.
- [Descargas y add-ins oficiales de CASIO](https://edu.casio.com/intl/support/downloads/), que agrupa Graph 35+E II con fx-9860GIII/fx-9750GIII.
