# STAT U123G: prototipo guiado basado en fuentes originales v1.1

**NO REEMPLAZA A STAT U123 v2.1.0.** El ejecutable v2.1.0 de la calculadora contiene funciones y mejoras que no están documentadas en el código v1.1 recuperado. Esta versión se instala al lado (identificador interno `@STU123`).

## Qué se modificó

1. Menú `GUIA: ELEGIR MODULO` y entrada de ayuda en las tres unidades; diagnóstico por el tipo de enunciado.
2. Tras introducir los parámetros empieza **directamente** el recorrido guiado. Ya no hay una pantalla aislada de resultado.
3. `F2`/flecha abajo/EXE avanza; `↑` retrocede, `F3` salta a la última pantalla, `EXIT` vuelve. Cada página recuerda su etapa de cálculo.
4. Ajuste automático de líneas de 21 caracteres: no se truncan etiquetas o cifras largas sin indicar su continuación.
5. Renderizador decimal propio para evitar que desaparezcan números con `%g` en fxSDK/gint.
6. Rótulos PASO específicos para los cálculos directos binomial, Poisson, normal y media muestral; los demás módulos recorren las fórmulas y operaciones procedentes de v1.1, con guía inicial.

## Qué NO hay que asumir

- No recuperamos el código fuente v2.1.0, solo su ejecutable. Esta reconstrucción **NO demuestra paridad funcional** con v2.1.0.
- Algunas ramas de despejes en v1.1 muestran valores intermedios sin sustituciones de cada operación: faltan mejoras pedagógicas por módulo.
- Los datos de examen no se introducen como texto libre: se elige un módulo y se introducen los parámetros.
- La interfaz simulada y las pruebas unitarias **no sustituyen una prueba física en la Casio Graph 35+E II**.

## Compilación y pruebas

`bash tests/run_host_tests.sh` (51 casos del núcleo + chequeo sintáctico)

`cc -std=c11 -O2 -Wall -Wextra -Werror -pedantic -Itests/stubs -Isrc tests/test_guided_ui.c src/stats_core.c -lm -o /tmp/test_ui && /tmp/test_ui`

Para la calculadora: `fxsdk build-fx`. El resultado esperado es `STAT-U123-GUIADO.g1a`.

## Convivencia

Mantener `STAT-U123.g1a` v2.1.0; copiar además `STAT-U123-GUIADO.g1a` a la raíz USB. Los identificadores internos son distintos (`@STATU` y `@STU123`).
