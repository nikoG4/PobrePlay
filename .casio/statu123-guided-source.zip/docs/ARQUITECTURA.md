# Arquitectura y decisiones numéricas

## Separación

- `src/stats_core.c`: funciones matemáticas portables, sin dependencia de CASIO.
- `src/main.c`: menús, entrada por teclado y desarrollos paginados para pantalla 128×64.
- `tests/test_stats_core.c`: regresión numérica contra ejercicios del curso.
- `tests/stubs/gint`: dobles mínimos para comprobar la sintaxis de la interfaz en un host.

El núcleo también contiene los despejes algebraicos y las búsquedas de raíces. La interfaz solo recopila la incógnita y los datos conocidos, y después muestra el procedimiento y la sustitución de verificación.

## Estabilidad

- La binomial suma rangos expandiéndose desde la moda. Esto evita comenzar en `q^n`, que puede subdesbordar cuando `n` es grande.
- Las colas superiores de Poisson se suman directamente cuando el umbral está a la derecha de `lambda`; cuando está a la izquierda se usa el complemento de la CDF inferior.
- La CDF normal usa una aproximación racional con error absoluto inferior a `8e-8`; la inversa usa la aproximación de Acklam y una corrección de Newton.
- El tamaño muestral siempre se redondea hacia arriba.
- La aproximación normal a binomial aplica corrección de continuidad según la desigualdad exacta.
- Las inversiones de binomial y Poisson recorren el dominio y refinan cada cambio de signo por bisección. No suponen que exista una única solución.
- Los sistemas de normal, `Xbarra` y sumas se transforman en dos ecuaciones de cuantiles `x=mu+z*sigma` antes de recuperar los parámetros originales.

## Límites de entrada

La interfaz limita `n` binomial directo a 100000, las búsquedas inversas de `p` y `n` a 5000 y `lambda` a 1000000 para impedir tiempos o exponentes absurdos en una calculadora de recursos limitados. Los casos del material están muy por debajo de esos límites.

## Ampliación futura

La unidad 4 puede agregarse reutilizando `stat_normal_event()` para proporciones, diferencias de medias/proporciones e intervalos de confianza. Se dejó fuera de esta versión para conservar el alcance solicitado.
