# Matriz de cobertura de ejercicios y variantes

## Cómo traducir el enunciado

### Distribuciones discretas

| Frase del enunciado | Evento que debe elegirse |
|---|---|
| exactamente `k` | `P(X = k)` |
| a lo sumo, como máximo, no más de `k` | `P(X <= k)` |
| menos de `k` | `P(X < k)` |
| al menos, por lo menos `k` | `P(X >= k)` |
| más de `k` | `P(X > k)` |
| entre `a` y `b`, ambos incluidos | `P(a <= X <= b)` |
| fuera del intervalo, incluyendo los extremos externos | `P(X <= a o X >= b)` |
| ninguno | `P(X = 0)` |
| por lo menos uno | `P(X >= 1) = 1-P(X=0)` |

El add-in conserva la diferencia entre `<` y `<=`, que es esencial en binomial y Poisson.

### Distribución normal

En una variable continua, `P(X<a)=P(X<=a)` y `P(X>a)=P(X>=a)`, porque la probabilidad en un punto exacto es cero. Para percentiles inversos, el add-in siempre pide área acumulada izquierda `F(x)`:

- “el 10% supera `x`” → `F(x)=0.90`;
- “el 90% supera `x`” → `F(x)=0.10`;
- “el 5% queda por debajo” → `F(x)=0.05`.

## Unidad 1 - Binomial y Poisson

| Variante observada en el material | Módulo |
|---|---|
| Binomial exacta, acumulada, cola o intervalo | `Binomial` |
| Hallar `p` cuando se conoce una probabilidad binomial | `Bin: hallar p de P` |
| Hallar el `n` entero que mejor reproduce una probabilidad | `Bin: hallar n de P` |
| Hallar `n` o `p` desde media o varianza; sistema media-varianza | `Bin: momentos/desp.` |
| Media, varianza y desviación binomial | aparecen en el desarrollo de `Binomial` |
| Número esperado entre 800 familias o 1000 lotes | `Esperado en M grupos` |
| Hallar cantidad de grupos, probabilidad o esperado | `E=M*P: despejar` |
| Examen al azar con premio y penalización | `Examen con penaliz.` |
| Hallar la probabilidad individual `p` necesaria para aprobar con una probabilidad dada | `Examen con penaliz.` → `Hallar p requerido` |
| Poisson exacta, acumulada, cola o intervalo | `Poisson` |
| Tasa dada por hora y consulta por minutos | `Poisson: escalar tasa` |
| Densidad por m² y consulta en otra superficie | `Poisson: escalar tasa` |
| Hallar páginas/tiempo/área usando `P(X=0)` | `Poisson: lambda de P0`, luego `Regla tasa: despejar` si corresponde |
| Hallar `lambda` desde `P(X=k)`, una acumulada, cola o intervalo | `Poi: hallar lambda de P` |
| Hallar tasa base, intervalo base, intervalo nuevo o tasa nueva | `Regla tasa: despejar` |
| Hallar el menor conteo `k` que alcanza un porcentaje acumulado | `Cuantil Bin/Poisson` |
| Aproximar binomial rara mediante Poisson, `lambda=np` | `Aprox Bin->Poisson` |

## Unidad 2 - Distribución normal

| Variante observada | Módulo |
|---|---|
| Menor/mayor que un valor | `Normal: probabilidad` |
| Entre dos valores | `Normal: probabilidad` |
| Dentro/fuera de una distancia de la media | `Normal: probabilidad`, opción dentro/fuera |
| Valor excedido por cierto porcentaje | `Normal: cuantil/corte` |
| Percentil inferior o superior | `Normal: cuantil/corte` |
| Hallar corte, `mu` o `sigma` con una condición | `Normal: despejar dato` |
| Hallar `mu` y `sigma` con dos porcentajes | `Sistema: hallar mu,sig` |
| Hallar amplitud, `sigma` o probabilidad de intervalo central | `Normal: intervalo sim.` |
| Cantidad esperada en una población | `Esperado en poblacion` |
| Aproximación normal a una binomial grande | `Aprox normal-binomial` |

### Corrección de continuidad aplicada automáticamente

| Evento binomial | Intervalo normal usado |
|---|---|
| `X = k` | `k-0.5 < Y < k+0.5` |
| `X <= k` | `Y < k+0.5` |
| `X < k` | `Y < k-0.5` |
| `X >= k` | `Y > k-0.5` |
| `X > k` | `Y > k+0.5` |
| `a <= X <= b` | `a-0.5 < Y < b+0.5` |

También se muestran la probabilidad binomial exacta y la diferencia respecto de la aproximación.

## Unidad 3 - Distribuciones muestrales

| Variante observada | Módulo |
|---|---|
| Parámetros de `Xbarra` | `Parametros de Xbarra` |
| Probabilidad de una media por debajo/encima/entre límites | `Media muestral` |
| Comparar muestras de tamaños diferentes | repetir `Media muestral` con cada `n` |
| Peso total, suma de cajas o total de eventos | `Suma / peso total` |
| Hallar un límite/percentil de `Xbarra` | `Corte de media` |
| Hallar `n` para error y confianza dados | `Tamano muestral` |
| Hallar corte, `mu`, `sigma` o `n` desde una probabilidad de `Xbarra` | `Xbarra: despejar dato` |
| Hallar `mu` y `sigma` poblacionales desde dos condiciones de `Xbarra` | `Sistema de Xbarra` |
| Despejar `n`, error máximo o `sigma` en la relación de confianza | `Error/conf: despejar` |
| Hallar corte total, media individual, desvío individual o cantidad | `Suma: despejar dato` |
| Hallar media y desvío individuales desde dos condiciones del total | `Sistema de suma` |
| Muestreo sin reemplazo desde población finita | indicar `N`; `N=0` omite la corrección |

Fórmulas usadas:

```text
E(Xbarra) = mu
SE(Xbarra) = sigma/sqrt(n)
FPC = sqrt((N-n)/(N-1))
E(Suma) = n*mu
SD(Suma) = sqrt(n)*sigma
```

## Qué ocurre cuando hay varias soluciones

Algunas ecuaciones inversas no son monótonas. Por ejemplo, una probabilidad exacta `P(X=k)` puede corresponder a dos valores distintos de `p` o de `lambda`. Los módulos inversos no eligen una raíz silenciosamente: enumeran las soluciones admisibles y muestran `verif P=...` para cada una.

Los sistemas estadísticos se reducen a dos ecuaciones lineales después de transformar los porcentajes a puntajes `z`:

```text
x1 = mu + z1*sigma
x2 = mu + z2*sigma
```

Para `Xbarra`, `sigma` representa primero el error estándar y luego se recupera la desviación poblacional. Para una suma, primero se resuelven la media y desviación del total y después se deshace el escalado por `n`.

## Casos de regresión tomados del curso

Las pruebas automáticas cubren, entre otros:

- tazas rotas `Bin(10,0.10)`;
- aplicación móvil `Bin(10,0.20)`;
- examen de 10 preguntas con penalización de 0.25;
- llamadas Poisson escaladas a 15, 30 y 90 minutos;
- reclutas `N(72,6)` y cuantiles de lámparas `N(10000,800)`;
- reconstrucción de parámetros del control desde `F(4)=0.40` y `F(6)=0.65`;
- medias de envases, promedio de calificaciones y suma del montacargas;
- corrección por población finita y tamaño muestral.
- despejes inversos de `p`, `n`, `lambda`, `mu` y `sigma`, incluidos casos con dos raíces y raíces tangentes.

## Diferencias de redondeo detectadas

Las guías suelen leer una tabla Z con dos decimales. El add-in evalúa la CDF numéricamente y muestra más cifras, por lo que resultados como `0.3372` pueden aparecer como aproximadamente `0.3385` al usar el valor `z` sin redondear.

En la Guía 2, ejercicio 6, las condiciones escritas `P(X>4)=0.60` y `P(X>7)=0.10` producen aproximadamente `mu=4.495` y `sigma=1.955`; la respuesta impresa `4.316` y `2.094` no satisface simultáneamente esas dos condiciones. El add-in resuelve las ecuaciones que se ingresan y no fuerza la respuesta impresa.
