#include <gint/display.h>
#include <gint/keyboard.h>

#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stats_core.h"

#define ARRAY_SIZE(x) ((int)(sizeof(x) / sizeof((x)[0])))
#define SOL_MAX_LINES 100
#define SOL_LINE_SIZE 24

typedef struct {
    char line[SOL_MAX_LINES][SOL_LINE_SIZE];
    unsigned char is_heading[SOL_MAX_LINES];
    int count;
} solution_t;

static void header(const char *title)
{
    drect(0, 0, 127, 8, C_BLACK);
    dtext(2, 1, C_WHITE, title);
}

static void footer(const char *text)
{
    dline(0, 55, 127, 55, C_BLACK);
    dtext(1, 57, C_BLACK, text);
}

/* Numeric formatting on SuperH: gint's tiny printf may not implement %g.
   Every real value is rendered without depending on floating-point printf. */
static void putchar_safe(char *out, size_t cap, size_t *len, char ch)
{
    if(*len + 1 < cap) out[(*len)++] = ch;
    out[*len] = 0;
}
static void puts_safe(char *out, size_t cap, size_t *len, const char *str)
{
    while(str && *str) putchar_safe(out, cap, len, *str++);
}
static void out_uint(char *out, size_t cap, size_t *pos, unsigned long long v)
{
    char buf[24]; int n=0;
    do {buf[n++]=(char)('0'+(v%10ULL)); v/=10ULL;}while(v && n<24);
    while(n--)putchar_safe(out,cap,pos,buf[n]);
}
static void numtext(char out[32], double value)
{
    size_t pos=0;
    out[0]=0;
    if(isnan(value)) { strcpy(out,"NaN"); return; }
    if(!isfinite(value)) { strcpy(out,value<0?"-Inf":"Inf"); return; }
    if(value == 0) { strcpy(out,"0"); return; }
    if(value < 0) { putchar_safe(out,32,&pos,'-'); value=-value; }
    int ex=(int)floor(log10(value));
    if(ex < -4 || ex > 6) {
        double mant=value/pow(10.0,ex);
        unsigned long long v=(unsigned long long)floor(mant*1000000.0+0.5);
        if(v>=10000000ULL) { v=1000000; ex++; }
        putchar_safe(out,32,&pos,(char)('0'+v/1000000ULL));
        unsigned long long rem=v%1000000ULL;
        if(rem) {
            char digits[6];
            for(int i=5;i>=0;i--) { digits[i]=(char)('0'+rem%10ULL); rem/=10ULL; }
            int last=5; while(last>=0 && digits[last]=='0') last--;
            putchar_safe(out,32,&pos,'.');
            for(int i=0;i<=last;i++) putchar_safe(out,32,&pos,digits[i]);
        }
        putchar_safe(out,32,&pos,'e');
        putchar_safe(out,32,&pos,ex>=0?'+':'-');
        char tmp[20]; snprintf(tmp,sizeof tmp,"%d",ex>=0?ex:-ex);
        puts_safe(out,32,&pos,tmp);
    } else {
        int decimals=6-ex;
        unsigned long long scale=1;
        for(int i=0;i<decimals;i++) scale*=10ULL;
        unsigned long long scaled=(unsigned long long)floor(value*scale+0.5);
        out_uint(out,32,&pos,scaled/scale);
        unsigned long long rem=scaled%scale;
        if(rem) {
            char digits[16];
            for(int i=decimals-1;i>=0;i--) { digits[i]=(char)('0'+rem%10ULL); rem/=10ULL; }
            int last=decimals-1;while(last>=0&&digits[last]=='0')last--;
            putchar_safe(out,32,&pos,'.');
            for(int i=0;i<=last;i++)putchar_safe(out,32,&pos,digits[i]);
        }
    }
}
/* Only the conversions used by the recovered v1.1 project are implemented.
   Keeps the original values when the original source used %.10g. */
static void portable_vformat(char *dest, size_t cap, const char *fmt, va_list args)
{
    size_t len=0;
    dest[0]=0;
    while(*fmt) {
        if(*fmt!='%') { putchar_safe(dest,cap,&len,*fmt++); continue; }
        fmt++;
        if(*fmt=='%') { putchar_safe(dest,cap,&len,'%'); fmt++; continue; }
        while(*fmt=='-'||*fmt=='+'||*fmt=='#'||*fmt==' '||*fmt=='0')fmt++;
        while(*fmt>='0'&&*fmt<='9')fmt++;
        if(*fmt=='.'){fmt++;while(*fmt>='0'&&*fmt<='9')fmt++;}
        while(*fmt=='l'||*fmt=='h'||*fmt=='z')fmt++;
        char code=*fmt; if(code)fmt++;
        char buf[36];buf[0]=0;
        if(code=='g'||code=='f'||code=='e'||code=='E') numtext(buf,va_arg(args,double));
        else if(code=='d'||code=='i')snprintf(buf,sizeof buf,"%d",va_arg(args,int));
        else if(code=='u')snprintf(buf,sizeof buf,"%u",va_arg(args,unsigned int));
        else if(code=='s')puts_safe(dest,cap,&len,va_arg(args,const char *));
        else if(code=='c') putchar_safe(dest,cap,&len,(char)va_arg(args,int));
        else putchar_safe(dest,cap,&len,'?');
        if(code!='s')puts_safe(dest,cap,&len,buf);
    }
}
static void portable_format(char *dest, size_t cap, const char *fmt, ...)
{
    va_list args;
    va_start(args,fmt);
    portable_vformat(dest,cap,fmt,args);
    va_end(args);
}

/* Hard screen width is 21 glyphs. Break between words instead of allowing
   gint to cut data off the right edge. Section headings don't use body rows. */
static void add_text(solution_t *s, const char *text)
{
    while(*text && s->count<SOL_MAX_LINES) {
        size_t n=strlen(text);
        size_t cut=n>21?21:n;
        if(n>21) {
            for(int i=21;i>=9;i--) if(text[i]==' ') {cut=(size_t)i;break;}
        }
        memcpy(s->line[s->count],text,cut);
        s->line[s->count][cut]=0;
        s->is_heading[s->count]=0;
        s->count++;
        text+=cut;while(*text==' ')text++;
    }
}
static void add_line(solution_t *s, const char *fmt, ...)
{
    char temp[160];
    va_list args;
    va_start(args,fmt);
    portable_vformat(temp,sizeof temp,fmt,args);
    va_end(args);
    add_text(s,temp);
}
static void add_section(solution_t *s, const char *title)
{
    if(s->count>=SOL_MAX_LINES)return;
    snprintf(s->line[s->count],SOL_LINE_SIZE,"%.21s",title);
    s->is_heading[s->count]=1;
    s->count++;
}

typedef struct {const char *name,*meaning,*method,*warning;} tip_t;
static tip_t tips(const char *title)
{
    if(strstr(title,"Binomial")||strstr(title,"Bin:"))
        return (tip_t){"BINOMIAL","n ensayos, p fijo","Exitos independientes","Atento a >= y >"};
    if(strstr(title,"Poisson")||strstr(title,"lambda")||strstr(title,"tasa"))
        return (tip_t){"POISSON","Cuenta eventos en area","lambda=tasa*intervalo","Buscar tasa por unidad"};
    if(strstr(title,"Normal")||strstr(title,"Cuantil")||strstr(title,"sigma"))
        return (tip_t){"NORMAL","Dato continuo","z=(x-mu)/sigma","Area der = 1-F"};
    if(strstr(title,"muestr")||strstr(title,"Xbarra")||strstr(title,"Parametros"))
        return (tip_t){"MEDIA MUESTRAL","Promedio de n datos","EE=sigma/sqrt(n)","Si N>0 usa FPC"};
    if(strstr(title,"Suma")||strstr(title,"total"))
        return (tip_t){"SUMA DE DATOS","Total de n elementos","muS=n*mu, sigS=rt(n)*s","No dividir entre n"};
    if(strstr(title,"Esperado"))
        return (tip_t){"NUMERO ESPERADO","P es prob individual","Esperado = M * P","Cantidad aprox, no P"};
    if(strstr(title,"Examen"))
        return (tip_t){"PUNTAJE","Acierto=suma puntos","Separar premio/multa","No confundir k y nota"};
    return (tip_t){"DESPEJE","Buscar el dato faltante","Reordenar y verificar","Revisar unidades"};
}
/* No standalone RESULTADO screen: the explanation is the result screen.
   The intro identifies the method; original calculation lines then follow
   in pages of five, with section titles occupying the header bar. */
static void show_solution(const char *title, const solution_t *s)
{
    tip_t t=tips(title);
    int start[120],end[120],heads[120],pages=1;
    int i=0,last_heading=-1;
    while(i<s->count && pages<119) {
        if(s->is_heading[i]) {last_heading=i;i++;continue;}
        int j=i; while(j<s->count && !s->is_heading[j]) j++;
        while(i<j && pages<119) {
            start[pages]=i;
            end[pages]=i+5<j?i+5:j;
            heads[pages]=last_heading;
            i=end[pages];pages++;
        }
    }
    int page=0;
    while(true) {
        dclear(C_WHITE);
        char titlebuf[24];
        if(page==0)snprintf(titlebuf,sizeof titlebuf,"PASO 1: %s",t.name);
        else if(heads[page]>=0)snprintf(titlebuf,sizeof titlebuf,"%s",s->line[heads[page]]);
        else snprintf(titlebuf,sizeof titlebuf,"PASO %d: CUENTAS",(page+1)%1000);
        header(titlebuf);
        if(page==0) {
            dtext(1,11,C_BLACK,"Para este enunciado:");
            dtext(1,20,C_BLACK,t.meaning);
            dtext(1,29,C_BLACK,t.method);
            dtext(1,38,C_BLACK,t.warning);
        } else {
            int line=0;
            for(int j=start[page];j<end[page];j++,line++)
                dtext(1,11+line*9,C_BLACK,s->line[j]);
        }
        char nav[32];snprintf(nav,sizeof nav,"%d/%d F2> F3FIN",page+1,pages);
        footer(nav);
        dupdate();
        int key=getkey().key;
        if(key==KEY_EXIT)return;
        if(key==KEY_F2 || key==KEY_DOWN || key==KEY_EXE){
            if(page+1<pages)page++;
            else if(key==KEY_EXE)return;
        }
        if(key==KEY_UP && page>0)page--;
        if(key==KEY_F3)page=pages-1;
        if(key==KEY_F1 && page>0)page--;
    }
}

static void show_message(const char *title, const char *a,
                         const char *b, const char *c)
{
    dclear(C_WHITE);
    header(title);
    if(a) dtext(1, 14, C_BLACK, a);
    if(b) dtext(1, 26, C_BLACK, b);
    if(c) dtext(1, 38, C_BLACK, c);
    footer("EXE/EXIT volver");
    dupdate();
    while(true) {
        int key = getkey().key;
        if(key == KEY_EXE || key == KEY_EXIT) return;
    }
}

static int menu_select(const char *title, const char *const *items, int count)
{
    int selected = 0;
    int first = 0;
    while(true) {
        if(selected < first) first = selected;
        if(selected >= first + 5) first = selected - 4;

        dclear(C_WHITE);
        header(title);
        for(int row = 0; row < 5 && first + row < count; row++) {
            int i = first + row;
            if(i == selected) drect(0, 10 + row * 9, 127,
                                    18 + row * 9, C_BLACK);
            dtext(2, 11 + row * 9, i == selected ? C_WHITE : C_BLACK,
                  items[i]);
        }
        footer("EXE=OK EXIT=Volver");
        dupdate();

        int key = getkey().key;
        if(key == KEY_EXIT) return -1;
        if(key == KEY_EXE) return selected;
        if(key == KEY_UP) selected = (selected + count - 1) % count;
        if(key == KEY_DOWN) selected = (selected + 1) % count;
    }
}

static int key_digit(int key)
{
    switch(key) {
    case KEY_0: return 0;
    case KEY_1: return 1;
    case KEY_2: return 2;
    case KEY_3: return 3;
    case KEY_4: return 4;
    case KEY_5: return 5;
    case KEY_6: return 6;
    case KEY_7: return 7;
    case KEY_8: return 8;
    case KEY_9: return 9;
    default: return -1;
    }
}

static void append_char(char *buf, int capacity, char ch)
{
    int len = (int)strlen(buf);
    if(len + 1 >= capacity) return;
    buf[len] = ch;
    buf[len + 1] = '\0';
}

static void toggle_negative(char *buf, int capacity)
{
    int len = (int)strlen(buf);
    char *exp = strchr(buf, 'e');
    if(exp && exp[1] == '\0') {
        append_char(buf, capacity, '-');
        return;
    }
    if(buf[0] == '-') memmove(buf, buf + 1, (size_t)len);
    else if(len + 1 < capacity) {
        memmove(buf + 1, buf, (size_t)len + 1);
        buf[0] = '-';
    }
}

static bool prompt_double(const char *label, double minimum, double maximum,
                          bool min_inclusive, bool max_inclusive, double *out)
{
    char buf[22] = "";
    bool invalid = false;
    while(true) {
        dclear(C_WHITE);
        header("Ingresar dato");
        dtext(1, 13, C_BLACK, label);
        drect_border(1, 25, 126, 38, C_WHITE, 1, C_BLACK);
        dtext(4, 28, C_BLACK, buf[0] ? buf : "_");
        dtext(1, 43, C_BLACK, "Punto decimal: .");
        if(invalid) dtext(1, 49, C_BLACK, "Valor fuera rango");
        footer("EXE=OK DEL=borrar");
        dupdate();

        int key = getkey().key;
        if(key == KEY_EXIT) return false;
        if(key == KEY_DEL) {
            int len = (int)strlen(buf);
            if(len > 0) buf[len - 1] = '\0';
            invalid = false;
            continue;
        }
        if(key == KEY_NEG) {
            toggle_negative(buf, ARRAY_SIZE(buf));
            invalid = false;
            continue;
        }
        int digit = key_digit(key);
        if(digit >= 0) {
            append_char(buf, ARRAY_SIZE(buf), (char)('0' + digit));
            invalid = false;
            continue;
        }
        if(key == KEY_DOT && !strchr(buf, '.') && !strchr(buf, 'e')) {
            if(!buf[0] || (buf[0] == '-' && !buf[1])) append_char(buf, ARRAY_SIZE(buf), '0');
            append_char(buf, ARRAY_SIZE(buf), '.');
            invalid = false;
            continue;
        }
        if(key == KEY_EXP && !strchr(buf, 'e') && buf[0] &&
           strcmp(buf, "-") != 0) {
            append_char(buf, ARRAY_SIZE(buf), 'e');
            invalid = false;
            continue;
        }
        if(key == KEY_EXE) {
            char *end = NULL;
            double value = strtod(buf, &end);
            bool lower = min_inclusive ? value >= minimum : value > minimum;
            bool upper = max_inclusive ? value <= maximum : value < maximum;
            if(buf[0] && end && *end == '\0' && isfinite(value) && lower && upper) {
                *out = value;
                return true;
            }
            invalid = true;
        }
    }
}

static bool prompt_int(const char *label, int minimum, int maximum, int *out)
{
    double value;
    while(true) {
        if(!prompt_double(label, minimum, maximum, true, true, &value)) return false;
        double rounded = floor(value + 0.5);
        if(fabs(value - rounded) < 1e-9) {
            *out = (int)rounded;
            return true;
        }
        show_message("Dato invalido", "Debe ser entero", NULL, NULL);
    }
}

static int pick_discrete_event(void)
{
    static const char *items[] = {
        "P(X = k)", "P(X <= k)", "P(X < k)",
        "P(X >= k)", "P(X > k)", "P(a <= X <= b)",
        "P(X <= a o X >= b)"
    };
    return menu_select("Elegir evento", items, ARRAY_SIZE(items));
}

static int pick_continuous_event(void)
{
    static const char *items[] = {
        "P(X <= a)", "P(X >= a)", "P(a <= X <= b)",
        "P(fuera de a,b)"
    };
    int choice = menu_select("Elegir area", items, ARRAY_SIZE(items));
    static const stat_event_t map[] = {
        STAT_LE, STAT_GE, STAT_BETWEEN, STAT_OUTSIDE
    };
    return choice < 0 ? -1 : (int)map[choice];
}

static bool input_discrete_bounds(stat_event_t event, int maximum,
                                  int *a, int *b)
{
    bool two_bounds = event == STAT_BETWEEN || event == STAT_OUTSIDE;
    if(!prompt_int(two_bounds ? "Limite a" : "Valor k",
                   0, maximum, a)) return false;
    *b = *a;
    if(two_bounds &&
       !prompt_int("Limite b", 0, maximum, b)) return false;
    if(*a > *b) {
        int swap = *a;
        *a = *b;
        *b = swap;
    }
    return true;
}

static bool input_continuous_bounds(stat_event_t event, double *a, double *b)
{
    if(!prompt_double(event == STAT_BETWEEN || event == STAT_OUTSIDE ?
                      "Limite a" : "Valor a", -1e100, 1e100,
                      true, true, a)) return false;
    *b = *a;
    if((event == STAT_BETWEEN || event == STAT_OUTSIDE) &&
       !prompt_double("Limite b", -1e100, 1e100, true, true, b)) return false;
    if(*a > *b) {
        double swap = *a;
        *a = *b;
        *b = swap;
    }
    return true;
}

static bool input_left_cdf(double *left)
{
    static const char *items[] = {
        "Area izquierda F", "Cola derecha r"
    };
    int choice = menu_select("Dato porcentual", items, ARRAY_SIZE(items));
    if(choice < 0) return false;
    double value;
    if(!prompt_double(choice == 0 ? "F=P(X<=x)" : "r=P(X>=x)",
                      0.0, 1.0, false, false, &value)) return false;
    *left = choice == 0 ? value : 1.0 - value;
    return true;
}

static void discrete_event_text(char *buf, int size, stat_event_t event,
                                int a, int b)
{
    switch(event) {
    case STAT_EQ: snprintf(buf, size, "X=%d", a); break;
    case STAT_LE: snprintf(buf, size, "X<=%d", a); break;
    case STAT_LT: snprintf(buf, size, "X<%d", a); break;
    case STAT_GE: snprintf(buf, size, "X>=%d", a); break;
    case STAT_GT: snprintf(buf, size, "X>%d", a); break;
    case STAT_BETWEEN: snprintf(buf, size, "%d<=X<=%d", a, b); break;
    case STAT_OUTSIDE: snprintf(buf, size, "X<=%d o X>=%d", a, b); break;
    default: snprintf(buf, size, "evento");
    }
}

static void continuous_event_text(char *buf, int size, stat_event_t event,
                                  double a, double b)
{
    switch(event) {
    case STAT_LE: portable_format(buf, (size_t)size, "X<=%.6g", a); break;
    case STAT_GE: portable_format(buf, (size_t)size, "X>=%.6g", a); break;
    case STAT_BETWEEN: portable_format(buf, (size_t)size, "%.5g<=X<=%.5g", a, b); break;
    case STAT_OUTSIDE: portable_format(buf, (size_t)size, "X fuera [%.4g,%.4g]", a, b); break;
    default: snprintf(buf, size, "evento");
    }
}

static void add_probability(solution_t *s, double p)
{
    add_line(s, "P = %.10g", p);
    add_line(s, "Porc = %.7g%%", 100.0 * p);
}

static bool input_binomial(int *n, double *p, stat_event_t *event,
                           int *a, int *b)
{
    if(!prompt_int("Numero ensayos n", 1, 100000, n)) return false;
    if(!prompt_double("Prob exito p", 0.0, 1.0, true, true, p)) return false;
    int e = pick_discrete_event();
    if(e < 0) return false;
    *event = (stat_event_t)e;
    return input_discrete_bounds(*event, *n, a, b);
}

static bool input_poisson(double *lambda, stat_event_t *event,
                          int *a, int *b)
{
    if(!prompt_double("Tasa lambda", 0.0, 1e6, true, true, lambda)) return false;
    int e = pick_discrete_event();
    if(e < 0) return false;
    *event = (stat_event_t)e;
    return input_discrete_bounds(*event, 1000000, a, b);
}

static bool input_normal(double *mu, double *sigma, stat_event_t *event,
                         double *a, double *b)
{
    if(!prompt_double("Media mu", -1e100, 1e100, true, true, mu)) return false;
    if(!prompt_double("Desv sigma", 0.0, 1e100, false, true, sigma)) return false;
    int e = pick_continuous_event();
    if(e < 0) return false;
    *event = (stat_event_t)e;
    return input_continuous_bounds(*event, a, b);
}

static void calc_binomial(void)
{
    int n, a, b;
    double p;
    stat_event_t event;
    if(!input_binomial(&n, &p, &event, &a, &b)) return;

    double probability = stat_binomial_event(n, p, event, a, b);
    double mean = n * p;
    double variance = n * p * (1.0 - p);
    char ev[32];
    discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);

    solution_t s = {0};
    add_section(&s, "PASO 2: IDENTIFICAR");
    add_line(&s, "X ~ Bin(n,p)");
    add_line(&s, "n=%d", n);
    add_line(&s, "p=%.10g", p);
    add_line(&s, "q=1-p=%.10g", 1.0-p);
    add_line(&s, "Evento: %s", ev);
    add_section(&s, "PASO 3: LA FORMULA");
    if(event == STAT_EQ) {
        add_line(&s, "P=C(n,k)p^kq^(n-k)");
        add_line(&s, "k=%d", a);
    }
    else add_line(&s, "P=suma de P(X=k)");
    add_section(&s, "PASO 4: PARAMETROS");
    add_line(&s, "mu=np=%.10g", mean);
    add_line(&s, "var=npq=%.10g", variance);
    add_line(&s, "sigma=%.10g", sqrt(variance));
    add_section(&s, "PASO 5: RESPUESTA");
    add_probability(&s, probability);
    show_solution("Binomial", &s);
}

static void calc_poisson(void)
{
    double lambda;
    int a, b;
    stat_event_t event;
    if(!input_poisson(&lambda, &event, &a, &b)) return;
    double probability = stat_poisson_event(lambda, event, a, b);
    char ev[32];
    discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);

    solution_t s = {0};
    add_section(&s, "PASO 2: IDENTIFICAR");
    add_line(&s, "X ~ Poi(lambda)");
    add_line(&s, "lambda=%.10g", lambda);
    add_line(&s, "Evento: %s", ev);
    add_section(&s, "PASO 3: FORMULA");
    if(event == STAT_EQ) add_line(&s, "P=e^-L L^k / k!");
    else add_line(&s, "P=suma/complemento");
    add_section(&s, "PASO 4: PARAMETROS");
    add_line(&s, "mu=lambda=%.10g", lambda);
    add_line(&s, "var=lambda=%.10g", lambda);
    add_line(&s, "sigma=%.10g", sqrt(lambda));
    add_section(&s, "PASO 5: RESPUESTA");
    add_probability(&s, probability);
    show_solution("Poisson", &s);
}

static void calc_scaled_poisson(void)
{
    double lambda0, exposure0, exposure1;
    if(!prompt_double("Lambda base", 0.0, 1e6, true, true, &lambda0)) return;
    if(!prompt_double("Intervalo base", 0.0, 1e100, false, true, &exposure0)) return;
    if(!prompt_double("Intervalo pedido", 0.0, 1e100, true, true, &exposure1)) return;
    double lambda = stat_poisson_scaled_lambda(lambda0, exposure0, exposure1);
    int e = pick_discrete_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    int a, b;
    if(!input_discrete_bounds(event, 1000000, &a, &b)) return;
    double probability = stat_poisson_event(lambda, event, a, b);
    char ev[32];
    discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);

    solution_t s = {0};
    add_line(&s, "Ajuste de intervalo");
    add_line(&s, "L=L0(t/t0)");
    add_line(&s, "L0=%.8g", lambda0);
    add_line(&s, "t0=%.8g t=%.8g", exposure0, exposure1);
    add_line(&s, "Lambda=%.10g", lambda);
    add_line(&s, "Evento: %s", ev);
    add_probability(&s, probability);
    show_solution("Poisson escalado", &s);
}

static void calc_poisson_from_p0(void)
{
    double p0;
    if(!prompt_double("P(X=0)", 0.0, 1.0, false, false, &p0)) return;
    double lambda = stat_poisson_lambda_from_p0(p0);
    solution_t s = {0};
    add_line(&s, "P(0)=e^(-lambda)");
    add_line(&s, "P(0)=%.10g", p0);
    add_line(&s, "ln P0=-lambda");
    add_line(&s, "lambda=-ln(P0)");
    add_line(&s, "lambda=%.10g", lambda);
    show_solution("Hallar lambda", &s);
}

static void calc_binomial_solve_p(void)
{
    int n, a, b;
    double target;
    if(!prompt_int("Numero ensayos n", 1, 5000, &n)) return;
    int e = pick_discrete_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    if(!input_discrete_bounds(event, n, &a, &b)) return;
    if(!prompt_double("Probabilidad dada", 0.0, 1.0,
                      false, false, &target)) return;

    double roots[6];
    int count = stat_binomial_solve_p(n, event, a, b, target,
                                      roots, ARRAY_SIZE(roots));
    solution_t s = {0};
    char ev[32];
    discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);
    add_line(&s, "Despejar p en Bin(n,p)");
    add_line(&s, "n=%d Evento %s", n, ev);
    add_line(&s, "P objetivo=%.10g", target);
    add_line(&s, "Busqueda + biseccion");
    if(count == 0) add_line(&s, "Sin solucion en 0<p<1");
    for(int i = 0; i < count; i++) {
        double verify = stat_binomial_event(n, roots[i], event, a, b);
        add_line(&s, "p%d=%.10g", i + 1, roots[i]);
        add_line(&s, "verif P=%.10g", verify);
    }
    if(count > 1) add_line(&s, "Hay %d soluciones validas", count);
    show_solution("Binomial: hallar p", &s);
}

static void calc_binomial_moments(void)
{
    static const char *items[] = {
        "n,p desde mu,var", "n desde mu,p", "p desde mu,n",
        "p desde var,n"
    };
    int mode = menu_select("Momentos binomial", items, ARRAY_SIZE(items));
    if(mode < 0) return;
    double mean = NAN, variance = NAN, n_real = NAN, p = NAN;
    int n = 0;
    solution_t s = {0};
    add_line(&s, "mu=n*p");
    add_line(&s, "var=n*p*(1-p)");
    if(mode == 0) {
        if(!prompt_double("Media binomial", 0.0, 1e8,
                          false, true, &mean)) return;
        if(!prompt_double("Varianza binomial", 0.0, 1e8,
                          true, true, &variance)) return;
        if(!stat_binomial_from_mean_variance(mean, variance,
                                              &n_real, &p)) {
            show_message("Sin solucion", "Se requiere", "0<=varianza<media", NULL);
            return;
        }
        if(n_real > 1e8) {
            show_message("Resultado muy grande", "n supera 100000000", NULL, NULL);
            return;
        }
        n = (int)floor(n_real + 0.5);
        add_line(&s, "var/mu=1-p");
        add_line(&s, "p=1-var/mu=%.10g", p);
        add_line(&s, "n=mu/p=%.10g", n_real);
        add_line(&s, "n entero cercano=%d", n);
        if(fabs(n_real - n) > 1e-7) add_line(&s, "Datos no dan n entero");
        else {
            add_line(&s, "Verif mu=%.10g", n * p);
            add_line(&s, "Verif var=%.10g", n * p * (1.0 - p));
        }
    }
    if(mode == 1) {
        if(!prompt_double("Media binomial", 0.0, 1e8,
                          false, true, &mean)) return;
        if(!prompt_double("Prob exito p", 0.0, 1.0,
                          false, true, &p)) return;
        n_real = mean / p;
        if(!isfinite(n_real) || n_real > 1e8) {
            show_message("Resultado muy grande", "n supera 100000000", NULL, NULL);
            return;
        }
        n = (int)floor(n_real + 0.5);
        add_line(&s, "n=mu/p=%.10g", n_real);
        add_line(&s, "n entero cercano=%d", n);
    }
    if(mode == 2) {
        if(!prompt_double("Media binomial", 0.0, 1e8,
                          true, true, &mean)) return;
        if(!prompt_int("Ensayos n", 1, 100000000, &n)) return;
        p = mean / n;
        if(!stat_probability_valid(p, false)) {
            show_message("Sin solucion", "mu debe estar", "entre 0 y n", NULL);
            return;
        }
        add_line(&s, "p=mu/n=%.10g", p);
        add_line(&s, "Verif n*p=%.10g", n * p);
    }
    if(mode == 3) {
        if(!prompt_double("Varianza binomial", 0.0, 2.5e7,
                          true, true, &variance)) return;
        if(!prompt_int("Ensayos n", 1, 100000000, &n)) return;
        double disc = 1.0 - 4.0 * variance / n;
        if(disc < 0.0) {
            show_message("Sin solucion", "var no puede superar", "n/4", NULL);
            return;
        }
        double p1 = 0.5 * (1.0 - sqrt(disc));
        double p2 = 0.5 * (1.0 + sqrt(disc));
        add_line(&s, "p^2-p+var/n=0");
        add_line(&s, "p1=%.10g", p1);
        add_line(&s, "p2=%.10g", p2);
        add_line(&s, "Ambas dan var=%.10g", variance);
    }
    show_solution("Bin: momentos", &s);
}

static void calc_binomial_solve_n(void)
{
    int a, b, max_n;
    double p, target, matched;
    int e = pick_discrete_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    if(!input_discrete_bounds(event, 5000, &a, &b)) return;
    if(!prompt_double("Prob exito p", 0.0, 1.0,
                      true, true, &p)) return;
    if(!prompt_double("Probabilidad dada", 0.0, 1.0,
                      true, true, &target)) return;
    if(!prompt_int("Buscar n hasta", 1, 5000, &max_n)) return;
    int best_n = stat_binomial_best_n(p, event, a, b, target,
                                      1, max_n, &matched);
    if(best_n < 0) {
        show_message("Sin solucion", "Revise el rango de n", NULL, NULL);
        return;
    }
    solution_t s = {0};
    char ev[32];
    discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);
    add_line(&s, "Buscar n entero");
    add_line(&s, "p=%.10g Evento %s", p, ev);
    add_line(&s, "P objetivo=%.10g", target);
    add_line(&s, "Mejor n=%d", best_n);
    add_line(&s, "P con n=%.10g", matched);
    add_line(&s, "Error abs=%.10g", fabs(matched - target));
    if(best_n > 1)
        add_line(&s, "P(n-1)=%.10g",
                 stat_binomial_event(best_n - 1, p, event, a, b));
    if(best_n < max_n)
        add_line(&s, "P(n+1)=%.10g",
                 stat_binomial_event(best_n + 1, p, event, a, b));
    show_solution("Binomial: hallar n", &s);
}

static void calc_discrete_quantile(void)
{
    static const char *items[] = {"Binomial", "Poisson"};
    int model = menu_select("Cuantil discreto", items, ARRAY_SIZE(items));
    if(model < 0) return;
    double left;
    int k;
    solution_t s = {0};
    if(model == 0) {
        int n;
        double p;
        if(!prompt_int("Ensayos n", 1, 100000, &n)) return;
        if(!prompt_double("Prob exito p", 0.0, 1.0,
                          true, true, &p)) return;
        if(!input_left_cdf(&left)) return;
        k = stat_binomial_quantile(n, p, left);
        add_line(&s, "X~Bin(%d,%.8g)", n, p);
        add_line(&s, "Menor k con F(k)>=F");
        add_line(&s, "F objetivo=%.10g", left);
        add_line(&s, "k=%d", k);
        add_line(&s, "F(k)=%.10g",
                 stat_binomial_event(n, p, STAT_LE, k, k));
        add_line(&s, "F(k-1)=%.10g",
                 k > 0 ? stat_binomial_event(n, p, STAT_LE, k - 1, k - 1) : 0.0);
    }
    else {
        double lambda;
        if(!prompt_double("Tasa lambda", 0.0, 1e6,
                          true, true, &lambda)) return;
        if(!input_left_cdf(&left)) return;
        k = stat_poisson_quantile(lambda, left);
        add_line(&s, "X~Poi(%.10g)", lambda);
        add_line(&s, "Menor k con F(k)>=F");
        add_line(&s, "F objetivo=%.10g", left);
        add_line(&s, "k=%d", k);
        add_line(&s, "F(k)=%.10g",
                 stat_poisson_event(lambda, STAT_LE, k, k));
        add_line(&s, "F(k-1)=%.10g",
                 k > 0 ? stat_poisson_event(lambda, STAT_LE, k - 1, k - 1) : 0.0);
    }
    show_solution("Cuantil discreto", &s);
}

static void calc_poisson_solve_lambda(void)
{
    int a, b;
    double target;
    int e = pick_discrete_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    if(!input_discrete_bounds(event, 1000000, &a, &b)) return;
    if(!prompt_double("Probabilidad dada", 0.0, 1.0,
                      false, false, &target)) return;
    double roots[6];
    int count = stat_poisson_solve_lambda(event, a, b, target,
                                          roots, ARRAY_SIZE(roots));
    solution_t s = {0};
    char ev[32];
    discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);
    add_line(&s, "Despejar lambda");
    add_line(&s, "Evento %s", ev);
    add_line(&s, "P objetivo=%.10g", target);
    add_line(&s, "Busqueda + biseccion");
    if(count == 0) add_line(&s, "Sin solucion 0<=L<=1e6");
    for(int i = 0; i < count; i++) {
        double verify = stat_poisson_event(roots[i], event, a, b);
        add_line(&s, "lambda%d=%.10g", i + 1, roots[i]);
        add_line(&s, "verif P=%.10g", verify);
    }
    if(count > 1) add_line(&s, "Hay %d soluciones validas", count);
    show_solution("Poisson: hallar L", &s);
}

static void calc_poisson_scale_unknown(void)
{
    static const char *items[] = {
        "Hallar lambda base", "Hallar intervalo base",
        "Hallar intervalo nuevo", "Hallar lambda nueva"
    };
    int unknown = menu_select("L=L0*t/t0", items, ARRAY_SIZE(items));
    if(unknown < 0) return;
    double l0 = NAN, t0 = NAN, t = NAN, l = NAN;
    if(unknown != 0 && !prompt_double("Lambda base L0", 0.0, 1e100,
                                     false, true, &l0)) return;
    if(unknown != 1 && !prompt_double("Intervalo base t0", 0.0, 1e100,
                                     false, true, &t0)) return;
    if(unknown != 2 && !prompt_double("Intervalo nuevo t", 0.0, 1e100,
                                     false, true, &t)) return;
    if(unknown != 3 && !prompt_double("Lambda nueva L", 0.0, 1e100,
                                     false, true, &l)) return;
    if(unknown == 0) l0 = l * t0 / t;
    if(unknown == 1) t0 = l0 * t / l;
    if(unknown == 2) t = l * t0 / l0;
    if(unknown == 3) l = l0 * t / t0;
    if(!isfinite(l0) || !isfinite(t0) || !isfinite(t) || !isfinite(l)) {
        show_message("Resultado fuera rango", "Use valores menores", NULL, NULL);
        return;
    }
    solution_t s = {0};
    add_line(&s, "L=L0*t/t0");
    add_line(&s, "L0=%.10g", l0);
    add_line(&s, "t0=%.10g", t0);
    add_line(&s, "t=%.10g", t);
    add_line(&s, "L=%.10g", l);
    add_line(&s, "Verif L0*t/t0=%.10g", l0 * t / t0);
    show_solution("Despejar tasa", &s);
}

static void calc_expected_relation(void)
{
    static const char *items[] = {
        "Hallar esperado E", "Hallar grupos M", "Hallar probabilidad P"
    };
    int unknown = menu_select("E=M*P", items, ARRAY_SIZE(items));
    if(unknown < 0) return;
    double expected = NAN, groups = NAN, probability = NAN;
    if(unknown != 0 && !prompt_double("Esperado E", 0.0, 1e100,
                                     true, true, &expected)) return;
    if(unknown != 1 && !prompt_double("Cantidad grupos M", 0.0, 1e100,
                                     false, true, &groups)) return;
    if(unknown != 2 && !prompt_double("Probabilidad P", 0.0, 1.0,
                                     false, true, &probability)) return;
    if(unknown == 0) expected = groups * probability;
    if(unknown == 1) groups = expected / probability;
    if(unknown == 2) probability = expected / groups;
    if(!isfinite(expected) || !isfinite(groups) ||
       !stat_probability_valid(probability, false)) {
        show_message("Datos incompatibles", "Revise E, M y P", NULL, NULL);
        return;
    }
    solution_t s = {0};
    add_line(&s, "E=M*P");
    add_line(&s, "E=%.10g", expected);
    add_line(&s, "M=%.10g", groups);
    add_line(&s, "P=%.10g", probability);
    add_line(&s, "Verif M*P=%.10g", groups * probability);
    show_solution("Frecuencia: despejar", &s);
}

static void calc_scored_exam(void)
{
    static const char *items[] = {
        "Calcular P(aprobar)", "Hallar p requerido"
    };
    int mode = menu_select("Examen", items, ARRAY_SIZE(items));
    if(mode < 0) return;
    int n;
    double p = NAN, correct, penalty, passing, target = NAN;
    if(!prompt_int("Preguntas n", 1, 100000, &n)) return;
    if(!prompt_double("Puntos correcto", 0.0, 1e100, false, true, &correct)) return;
    if(!prompt_double("Penalidad error", 0.0, 1e100, true, true, &penalty)) return;
    if(!prompt_double("Puntaje minimo", -1e100, 1e100, true, true, &passing)) return;
    if(mode == 0 && !prompt_double("p de acierto", 0.0, 1.0,
                                   true, true, &p)) return;
    if(mode == 1 && !prompt_double("P deseada aprobar", 0.0, 1.0,
                                   false, false, &target)) return;

    int k = stat_scored_exam_min_successes(n, correct, penalty, passing);
    solution_t s = {0};
    add_line(&s, "Nota=x*c-(n-x)*r");
    add_line(&s, "n=%d", n);
    add_line(&s, "c=%.8g r=%.8g", correct, penalty);
    add_line(&s, "Min nota=%.8g", passing);
    add_line(&s, "x >= (nota+rn)/(c+r)");
    add_line(&s, "Aciertos min=%d", k);
    add_line(&s, "Se calcula P(X>=%d)", k);
    if(mode == 0) {
        double probability = k <= 0 ? 1.0 :
            (k > n ? 0.0 : stat_binomial_event(n, p, STAT_GE, k, k));
        add_line(&s, "p acierto=%.10g", p);
        add_probability(&s, probability);
    }
    else if(k <= 0 || k > n) {
        add_line(&s, "Aprobacion es siempre");
        add_line(&s, k <= 0 ? "segura para todo p" : "imposible para todo p");
    }
    else {
        double roots[4];
        int count = stat_binomial_solve_p(n, STAT_GE, k, k, target,
                                          roots, ARRAY_SIZE(roots));
        add_line(&s, "P aprobar deseada=%.10g", target);
        if(count == 0) add_line(&s, "Sin p en 0..1");
        for(int i = 0; i < count; i++) {
            add_line(&s, "p requerido=%.10g", roots[i]);
            add_line(&s, "Verif P=%.10g",
                     stat_binomial_event(n, roots[i], STAT_GE, k, k));
        }
    }
    show_solution("Examen al azar", &s);
}

static void calc_expected_groups(void)
{
    static const char *models[] = {"Binomial", "Poisson"};
    int model = menu_select("Modelo base", models, ARRAY_SIZE(models));
    if(model < 0) return;
    double probability;
    char ev[32];
    solution_t s = {0};

    if(model == 0) {
        int n, a, b;
        double p;
        stat_event_t event;
        if(!input_binomial(&n, &p, &event, &a, &b)) return;
        probability = stat_binomial_event(n, p, event, a, b);
        discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);
        add_line(&s, "Modelo Bin(%d,%.6g)", n, p);
    }
    else {
        double lambda;
        int a, b;
        stat_event_t event;
        if(!input_poisson(&lambda, &event, &a, &b)) return;
        probability = stat_poisson_event(lambda, event, a, b);
        discrete_event_text(ev, ARRAY_SIZE(ev), event, a, b);
        add_line(&s, "Modelo Poi(%.8g)", lambda);
    }
    double groups;
    if(!prompt_double("Cantidad grupos M", 0.0, 1e100, true, true, &groups)) return;
    add_line(&s, "Evento: %s", ev);
    add_line(&s, "P=%.10g", probability);
    add_line(&s, "Esperado=M*P");
    add_line(&s, "M=%.10g", groups);
    add_line(&s, "E=%.10g", groups * probability);
    show_solution("Frecuencia esperada", &s);
}

static void calc_poisson_approx(void)
{
    int n, a, b;
    double p;
    if(!prompt_int("Ensayos n", 1, 100000, &n)) return;
    if(!prompt_double("Prob rara p", 0.0, 1.0, true, true, &p)) return;
    int e = pick_discrete_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    if(!input_discrete_bounds(event, n, &a, &b)) return;
    double lambda = n * p;
    double approx = stat_poisson_event(lambda, event, a, b);
    double exact = stat_binomial_event(n, p, event, a, b);
    solution_t s = {0};
    add_line(&s, "Binomial -> Poisson");
    add_line(&s, "lambda=n*p");
    add_line(&s, "n=%d p=%.10g", n, p);
    add_line(&s, "lambda=%.10g", lambda);
    add_line(&s, "P aprox=%.10g", approx);
    add_line(&s, "P exacta=%.10g", exact);
    add_line(&s, "Dif=%.4g", fabs(exact - approx));
    show_solution("Aprox Bin->Poi", &s);
}

static void calc_normal(void)
{
    double mu, sigma, a, b;
    stat_event_t event;
    if(!input_normal(&mu, &sigma, &event, &a, &b)) return;
    double probability = stat_normal_event(mu, sigma, event, a, b);
    char ev[32];
    continuous_event_text(ev, ARRAY_SIZE(ev), event, a, b);
    solution_t s = {0};
    add_section(&s, "PASO 2: DATOS");
    add_line(&s, "X ~ N(mu,sigma)");
    add_line(&s, "mu=%.10g", mu);
    add_line(&s, "sigma=%.10g", sigma);
    add_line(&s, "Evento: %s", ev);
    add_section(&s, "PASO 3: ESTANDARIZAR");
    add_line(&s, "z=(x-mu)/sigma");
    add_line(&s, "z(a)=%.10g", (a - mu) / sigma);
    if(event == STAT_BETWEEN || event == STAT_OUTSIDE)
        add_line(&s, "z(b)=%.10g", (b - mu) / sigma);
    add_section(&s, "PASO 4: RESPUESTA");
    add_probability(&s, probability);
    show_solution("Normal", &s);
}

static void calc_normal_cutoff(void)
{
    double mu, sigma, left;
    if(!prompt_double("Media mu", -1e100, 1e100, true, true, &mu)) return;
    if(!prompt_double("Desv sigma", 0.0, 1e100, false, true, &sigma)) return;
    if(!input_left_cdf(&left)) return;
    double z = stat_normal_inv_cdf(left);
    double x = stat_normal_cutoff(mu, sigma, left);
    solution_t s = {0};
    add_line(&s, "Buscar x con P(X<=x)=F");
    add_line(&s, "F=%.10g", left);
    add_section(&s, "PASO 2: AREAS");
    add_line(&s, "z=Phi^-1(F)");
    add_line(&s, "z=%.10g", z);
    add_section(&s, "PASO 3: DESPEJAR");
    add_line(&s, "x=mu+z*sigma");
    add_line(&s, "x=%.10g", x);
    add_section(&s, "PASO 4: COMPROBAR");
    add_line(&s, "Cola der r: F=1-r");
    show_solution("Cuantil normal", &s);
}

static void calc_normal_params(void)
{
    double x1, f1, x2, f2, mu, sigma;
    if(!prompt_double("Valor x1", -1e100, 1e100, true, true, &x1)) return;
    if(!input_left_cdf(&f1)) return;
    if(!prompt_double("Valor x2", -1e100, 1e100, true, true, &x2)) return;
    if(!input_left_cdf(&f2)) return;
    if(!stat_normal_from_quantiles(x1, f1, x2, f2, &mu, &sigma)) {
        show_message("Datos incompatibles", "x y F deben crecer", "en el mismo sentido", NULL);
        return;
    }
    double z1 = stat_normal_inv_cdf(f1);
    double z2 = stat_normal_inv_cdf(f2);
    solution_t s = {0};
    add_line(&s, "x1=mu+z1*sigma");
    add_line(&s, "x2=mu+z2*sigma");
    add_line(&s, "z1=%.10g", z1);
    add_line(&s, "z2=%.10g", z2);
    add_line(&s, "sigma=(x2-x1)/(z2-z1)");
    add_line(&s, "sigma=%.10g", sigma);
    add_line(&s, "mu=x1-z1*sigma");
    add_line(&s, "mu=%.10g", mu);
    show_solution("Hallar mu y sigma", &s);
}

static void calc_normal_one_unknown(void)
{
    static const char *items[] = {
        "Hallar corte x", "Hallar media mu", "Hallar desvio sigma"
    };
    int unknown = menu_select("x=mu+z*sigma", items, ARRAY_SIZE(items));
    if(unknown < 0) return;
    double x = NAN, mu = NAN, sigma = NAN, left;
    if(unknown != 0 && !prompt_double("Valor corte x", -1e100, 1e100,
                                     true, true, &x)) return;
    if(unknown != 1 && !prompt_double("Media mu", -1e100, 1e100,
                                     true, true, &mu)) return;
    if(unknown != 2 && !prompt_double("Desv sigma", 0.0, 1e100,
                                     false, true, &sigma)) return;
    if(!input_left_cdf(&left)) return;
    double z = stat_normal_inv_cdf(left);
    if(unknown == 0) x = stat_normal_cutoff(mu, sigma, left);
    if(unknown == 1) mu = stat_normal_mu_from_quantile(x, sigma, left);
    if(unknown == 2) sigma = stat_normal_sigma_from_quantile(x, mu, left);
    if(!isfinite(x) || !isfinite(mu) || !isfinite(sigma)) {
        show_message("Sin solucion", "El signo de x-mu", "debe coincidir con z", NULL);
        return;
    }
    solution_t s = {0};
    add_line(&s, "F=%.10g", left);
    add_line(&s, "z=Phi^-1(F)=%.10g", z);
    add_line(&s, "x=mu+z*sigma");
    add_line(&s, "x=%.10g", x);
    add_line(&s, "mu=%.10g", mu);
    add_line(&s, "sigma=%.10g", sigma);
    add_line(&s, "Verif F(x)=%.10g", stat_normal_event(mu, sigma,
             STAT_LE, x, x));
    show_solution("Normal: despejar", &s);
}

static void calc_normal_symmetric(void)
{
    static const char *items[] = {
        "Hallar semiancho d", "Hallar desvio sigma",
        "Hallar prob central"
    };
    int unknown = menu_select("P(|X-mu|<=d)", items, ARRAY_SIZE(items));
    if(unknown < 0) return;
    double d = NAN, sigma = NAN, probability = NAN;
    if(unknown != 0 && !prompt_double("Semiancho d", 0.0, 1e100,
                                     false, true, &d)) return;
    if(unknown != 1 && !prompt_double("Desv sigma", 0.0, 1e100,
                                     false, true, &sigma)) return;
    if(unknown != 2 && !prompt_double("Prob central", 0.0, 1.0,
                                     false, false, &probability)) return;
    if(unknown == 0)
        d = stat_normal_symmetric_halfwidth(sigma, probability);
    if(unknown == 1) {
        double z = stat_normal_inv_cdf(0.5 + probability / 2.0);
        sigma = d / z;
    }
    if(unknown == 2)
        probability = 2.0 * stat_normal_cdf(d / sigma) - 1.0;
    if(!isfinite(d) || !isfinite(sigma) || sigma <= 0.0 ||
       !stat_probability_valid(probability, true)) {
        show_message("Datos incompatibles", "Revise d, sigma y P", NULL, NULL);
        return;
    }
    double z = d / sigma;
    solution_t s = {0};
    add_line(&s, "P(mu-d<=X<=mu+d)");
    add_line(&s, "P=2*Phi(d/sigma)-1");
    add_line(&s, "d=%.10g", d);
    add_line(&s, "sigma=%.10g", sigma);
    add_line(&s, "z=d/sigma=%.10g", z);
    add_line(&s, "P central=%.10g", probability);
    show_solution("Normal simetrica", &s);
}

static void calc_normal_binomial(void)
{
    int n, a, b;
    double p;
    if(!prompt_int("Ensayos n", 1, 100000, &n)) return;
    if(!prompt_double("Prob exito p", 0.0, 1.0, false, false, &p)) return;
    int e = pick_discrete_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    if(!input_discrete_bounds(event, n, &a, &b)) return;
    double approx = stat_binomial_normal_approx(n, p, event, a, b);
    double exact = stat_binomial_event(n, p, event, a, b);
    double mean = n * p;
    double sigma = sqrt(n * p * (1.0 - p));
    solution_t s = {0};
    add_line(&s, "Aprox normal +0.5");
    add_line(&s, "mu=np=%.10g", mean);
    add_line(&s, "sigma=sqrt(npq)");
    add_line(&s, "sigma=%.10g", sigma);
    add_line(&s, "P aprox=%.10g", approx);
    add_line(&s, "P exacta=%.10g", exact);
    add_line(&s, "Dif=%.4g", fabs(exact - approx));
    add_line(&s, "Validez: np,nq >=5");
    show_solution("Normal a Binomial", &s);
}

static void calc_normal_expected(void)
{
    double mu, sigma, a, b, population;
    stat_event_t event;
    if(!input_normal(&mu, &sigma, &event, &a, &b)) return;
    if(!prompt_double("Poblacion M", 0.0, 1e100, true, true, &population)) return;
    double probability = stat_normal_event(mu, sigma, event, a, b);
    solution_t s = {0};
    add_line(&s, "P=%.10g", probability);
    add_line(&s, "M=%.10g", population);
    add_line(&s, "Esperado=M*P");
    add_line(&s, "E=%.10g", population * probability);
    show_solution("Esperado normal", &s);
}

static bool input_sampling_base(double *mu, double *sigma,
                                int *n, int *population_n)
{
    if(!prompt_double("Media poblac mu", -1e100, 1e100, true, true, mu)) return false;
    if(!prompt_double("Desv poblac sigma", 0.0, 1e100, false, true, sigma)) return false;
    if(!prompt_int("Tam muestra n", 1, 100000000, n)) return false;
    if(!prompt_int("Poblac N (0=grande)", 0, 100000000, population_n)) return false;
    if(*population_n > 0 && *population_n < *n) {
        show_message("Datos incompatibles", "N debe ser >= n", NULL, NULL);
        return false;
    }
    return true;
}

static void calc_sample_mean(void)
{
    double mu, sigma, a, b;
    int n, population_n;
    if(!input_sampling_base(&mu, &sigma, &n, &population_n)) return;
    int e = pick_continuous_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    if(!input_continuous_bounds(event, &a, &b)) return;
    double se = stat_sample_mean_se(sigma, n, population_n);
    double probability = stat_sample_mean_event(mu, sigma, n, population_n,
                                                event, a, b);
    char ev[32];
    continuous_event_text(ev, ARRAY_SIZE(ev), event, a, b);
    solution_t s = {0};
    add_section(&s, "PASO 2: DATOS");
    add_line(&s, "Xbarra ~ N(mu,SE)");
    add_line(&s, "mu_Xb=%.10g", mu);
    add_section(&s, "PASO 3: ERROR EST");
    add_line(&s, "SE=sigma/sqrt(n)");
    if(population_n > 0) add_line(&s, "FPC=sqrt((N-n)/(N-1))");
    add_line(&s, "SE=%.10g", se);
    add_line(&s, "var_Xb=%.10g", se * se);
    add_section(&s, "PASO 4: PROBABILID.");
    add_line(&s, "Evento: %s", ev);
    add_line(&s, "z(a)=%.10g", (a - mu) / se);
    if(event == STAT_BETWEEN || event == STAT_OUTSIDE)
        add_line(&s, "z(b)=%.10g", (b - mu) / se);
    add_section(&s, "PASO 5: RESPUESTA");
    add_probability(&s, probability);
    show_solution("Media muestral", &s);
}

static void calc_sum(void)
{
    double mu, sigma, a, b;
    int n;
    if(!prompt_double("Media individual", -1e100, 1e100, true, true, &mu)) return;
    if(!prompt_double("Desv individual", 0.0, 1e100, false, true, &sigma)) return;
    if(!prompt_int("Cantidad n", 1, 100000000, &n)) return;
    int e = pick_continuous_event();
    if(e < 0) return;
    stat_event_t event = (stat_event_t)e;
    if(!input_continuous_bounds(event, &a, &b)) return;
    double sum_mu = n * mu;
    double sum_sigma = sqrt((double)n) * sigma;
    double probability = stat_sum_event(mu, sigma, n, event, a, b);
    solution_t s = {0};
    add_line(&s, "Suma S=X1+...+Xn");
    add_line(&s, "mu_S=n*mu=%.10g", sum_mu);
    add_line(&s, "sigma_S=sqrt(n)*sigma");
    add_line(&s, "sigma_S=%.10g", sum_sigma);
    add_line(&s, "z(a)=%.10g", (a - sum_mu) / sum_sigma);
    if(event == STAT_BETWEEN || event == STAT_OUTSIDE)
        add_line(&s, "z(b)=%.10g", (b - sum_mu) / sum_sigma);
    add_probability(&s, probability);
    show_solution("Suma / total", &s);
}

static void calc_sample_cutoff(void)
{
    double mu, sigma, left;
    int n, population_n;
    if(!input_sampling_base(&mu, &sigma, &n, &population_n)) return;
    if(!input_left_cdf(&left)) return;
    double se = stat_sample_mean_se(sigma, n, population_n);
    double z = stat_normal_inv_cdf(left);
    double x = stat_sample_mean_cutoff(mu, sigma, n, population_n, left);
    solution_t s = {0};
    add_line(&s, "P(Xbarra<=x)=F");
    add_line(&s, "SE=%.10g", se);
    add_line(&s, "z=Phi^-1(F)");
    add_line(&s, "z=%.10g", z);
    add_line(&s, "x=mu+z*SE");
    add_line(&s, "x=%.10g", x);
    show_solution("Corte de Xbarra", &s);
}

static void calc_sample_size(void)
{
    double sigma, error, confidence;
    if(!prompt_double("Desv sigma", 0.0, 1e100, false, true, &sigma)) return;
    if(!prompt_double("Error max E", 0.0, 1e100, false, true, &error)) return;
    if(!prompt_double("Confianza (0 a 1)", 0.0, 1.0, false, false, &confidence)) return;
    int n = stat_sample_size_for_mean(sigma, error, confidence);
    double z = stat_normal_inv_cdf(0.5 + confidence / 2.0);
    double raw = (z * sigma / error) * (z * sigma / error);
    solution_t s = {0};
    add_section(&s, "PASO 2: DATOS");
    add_line(&s, "Sigma=%.10g", sigma);
    add_line(&s, "Error E=%.10g", error);
    add_line(&s, "Confianza=%.10g", confidence);
    add_section(&s, "PASO 3: VALOR Z");
    add_line(&s, "F=0.5+conf/2");
    add_line(&s, "z=%.10g", z);
    add_section(&s, "PASO 4: SUSTITUIR");
    add_line(&s, "n=(z*sigma/E)^2");
    add_line(&s, "n sin red=%.10g", raw);
    add_section(&s, "PASO 5: CONCLUSION");
    add_line(&s, "Redondear arriba");
    add_line(&s, "n minimo=%d", n);
    show_solution("Tamano muestral", &s);
}

static void calc_sample_params(void)
{
    double mu, sigma;
    int n, population_n;
    if(!input_sampling_base(&mu, &sigma, &n, &population_n)) return;
    double se = stat_sample_mean_se(sigma, n, population_n);
    solution_t s = {0};
    add_line(&s, "Distribucion Xbarra");
    add_line(&s, "mu_Xb=mu=%.10g", mu);
    add_line(&s, "SE=sigma/sqrt(n)");
    if(population_n > 0) add_line(&s, "Con correccion finita");
    add_line(&s, "SE=%.10g", se);
    add_line(&s, "var_Xb=SE^2");
    add_line(&s, "var_Xb=%.10g", se * se);
    add_line(&s, "TCL: aprox normal");
    show_solution("Parametros Xbarra", &s);
}

static void calc_sample_one_unknown(void)
{
    static const char *items[] = {
        "Hallar corte x", "Hallar media mu", "Hallar desvio sigma",
        "Hallar tam muestra n"
    };
    int unknown = menu_select("Xbarra: despejar", items, ARRAY_SIZE(items));
    if(unknown < 0) return;
    double x = NAN, mu = NAN, sigma = NAN, left;
    int n = 0, population_n;
    if(unknown != 0 && !prompt_double("Corte de Xbarra x", -1e100, 1e100,
                                     true, true, &x)) return;
    if(unknown != 1 && !prompt_double("Media poblac mu", -1e100, 1e100,
                                     true, true, &mu)) return;
    if(unknown != 2 && !prompt_double("Desv poblac sigma", 0.0, 1e100,
                                     false, true, &sigma)) return;
    if(unknown != 3 && !prompt_int("Tam muestra n", 1, 100000000, &n)) return;
    if(!prompt_int("Poblac N (0=grande)", 0, 100000000, &population_n)) return;
    if(unknown != 3 && population_n > 0 && population_n < n) {
        show_message("Datos incompatibles", "N debe ser >= n", NULL, NULL);
        return;
    }
    if(!input_left_cdf(&left)) return;
    double z = stat_normal_inv_cdf(left);
    double n_real = n;
    if(unknown == 0) x = stat_sample_mean_cutoff(mu, sigma, n,
                                                 population_n, left);
    if(unknown == 1) mu = stat_sample_mean_mu_from_cutoff(x, sigma, n,
                                                          population_n, left);
    if(unknown == 2) sigma = stat_sample_mean_sigma_from_cutoff(x, mu, n,
                                                                population_n,
                                                                left);
    if(unknown == 3) n_real = stat_sample_mean_n_from_cutoff(x, mu, sigma,
                                                             population_n,
                                                             left);
    if(!isfinite(x) || !isfinite(mu) || !isfinite(sigma) ||
       !isfinite(n_real) || n_real < 1.0 || n_real > 100000000.0 ||
       (population_n > 0 && n_real > population_n)) {
        show_message("Sin solucion", "Revise signos, F", "y tamano poblacion", NULL);
        return;
    }
    solution_t s = {0};
    add_line(&s, "x=mu+z*SE");
    add_line(&s, "z=%.10g F=%.8g", z, left);
    add_line(&s, "x=%.10g", x);
    add_line(&s, "mu=%.10g", mu);
    add_line(&s, "sigma=%.10g", sigma);
    if(unknown == 3) {
        int floor_n = (int)floor(n_real);
        int ceil_n = (int)ceil(n_real);
        add_line(&s, "n teorico=%.10g", n_real);
        add_line(&s, "Probar n=%d o %d", floor_n, ceil_n);
        if(floor_n >= 1)
            add_line(&s, "F con piso=%.10g",
                     stat_sample_mean_event(mu, sigma, floor_n, population_n,
                                            STAT_LE, x, x));
        if(ceil_n >= 1 && (population_n == 0 || ceil_n <= population_n))
            add_line(&s, "F con techo=%.10g",
                     stat_sample_mean_event(mu, sigma, ceil_n, population_n,
                                            STAT_LE, x, x));
    }
    else {
        double se = stat_sample_mean_se(sigma, n, population_n);
        add_line(&s, "n=%d SE=%.10g", n, se);
        add_line(&s, "Verif F=%.10g",
                 stat_sample_mean_event(mu, sigma, n, population_n,
                                        STAT_LE, x, x));
    }
    show_solution("Xbarra: despejar", &s);
}

static void calc_margin_relation(void)
{
    static const char *items[] = {
        "Hallar n", "Hallar error E", "Hallar sigma"
    };
    int unknown = menu_select("E=z*sigma/sqrt(n)", items, ARRAY_SIZE(items));
    if(unknown < 0) return;
    double sigma = NAN, error = NAN, confidence;
    int n = 0;
    if(unknown != 0 && !prompt_int("Tam muestra n", 1, 100000000, &n)) return;
    if(unknown != 1 && !prompt_double("Error max E", 0.0, 1e100,
                                     false, true, &error)) return;
    if(unknown != 2 && !prompt_double("Desv sigma", 0.0, 1e100,
                                     false, true, &sigma)) return;
    if(!prompt_double("Confianza (0 a 1)", 0.0, 1.0,
                      false, false, &confidence)) return;
    double z = stat_normal_inv_cdf(0.5 + confidence / 2.0);
    double n_real = n;
    if(unknown == 0) {
        n_real = (z * sigma / error) * (z * sigma / error);
        n = stat_sample_size_for_mean(sigma, error, confidence);
    }
    if(unknown == 1) error = stat_margin_error_for_mean(sigma, n, confidence);
    if(unknown == 2) sigma = stat_sigma_from_margin_error(error, n, confidence);
    if(!isfinite(sigma) || !isfinite(error) || n <= 0 || n > 100000000) {
        show_message("Datos incompatibles", "Revise n, E, sigma", NULL, NULL);
        return;
    }
    solution_t s = {0};
    add_line(&s, "F=0.5+conf/2");
    add_line(&s, "z=%.10g", z);
    add_line(&s, "E=z*sigma/sqrt(n)");
    add_line(&s, "sigma=%.10g", sigma);
    add_line(&s, "E=%.10g", error);
    if(unknown == 0) add_line(&s, "n teorico=%.10g", n_real);
    add_line(&s, "n entero=%d", n);
    show_solution("Error/confianza", &s);
}

static void calc_sample_system(void)
{
    int n, population_n;
    double x1, f1, x2, f2, mu, se;
    if(!prompt_int("Tam muestra n", 1, 100000000, &n)) return;
    if(!prompt_int("Poblac N (0=grande)", 0, 100000000,
                   &population_n)) return;
    if(population_n > 0 && population_n <= n) {
        show_message("Datos incompatibles", "Para sistema use N>n", NULL, NULL);
        return;
    }
    if(!prompt_double("Corte x1", -1e100, 1e100, true, true, &x1)) return;
    if(!input_left_cdf(&f1)) return;
    if(!prompt_double("Corte x2", -1e100, 1e100, true, true, &x2)) return;
    if(!input_left_cdf(&f2)) return;
    if(!stat_normal_from_quantiles(x1, f1, x2, f2, &mu, &se)) {
        show_message("Sin solucion", "Las dos condiciones", "son incompatibles", NULL);
        return;
    }
    double fpc = population_n > 0 ?
        sqrt((population_n - n) / (double)(population_n - 1)) : 1.0;
    double sigma = se * sqrt((double)n) / fpc;
    solution_t s = {0};
    add_line(&s, "x1=mu+z1*SE");
    add_line(&s, "x2=mu+z2*SE");
    add_line(&s, "z1=%.8g z2=%.8g",
             stat_normal_inv_cdf(f1), stat_normal_inv_cdf(f2));
    add_line(&s, "Sistema da mu,SE");
    add_line(&s, "mu=%.10g", mu);
    add_line(&s, "SE=%.10g", se);
    if(population_n > 0) add_line(&s, "sigma=SE*sqrt(n)/FPC");
    else add_line(&s, "sigma=SE*sqrt(n)");
    add_line(&s, "sigma=%.10g", sigma);
    show_solution("Sistema de Xbarra", &s);
}

static void calc_sum_one_unknown(void)
{
    static const char *items[] = {
        "Hallar corte total x", "Hallar media indiv mu",
        "Hallar desvio indiv", "Hallar cantidad n"
    };
    int unknown = menu_select("Suma: despejar", items, ARRAY_SIZE(items));
    if(unknown < 0) return;
    double x = NAN, mu = NAN, sigma = NAN, left;
    int n = 0;
    if(unknown != 0 && !prompt_double("Corte total x", -1e100, 1e100,
                                     true, true, &x)) return;
    if(unknown != 1 && !prompt_double("Media individual", -1e100, 1e100,
                                     true, true, &mu)) return;
    if(unknown != 2 && !prompt_double("Desv individual", 0.0, 1e100,
                                     false, true, &sigma)) return;
    if(unknown != 3 && !prompt_int("Cantidad n", 1, 100000000, &n)) return;
    if(!input_left_cdf(&left)) return;
    double roots[2];
    int count = 0;
    if(unknown == 0) x = stat_sum_cutoff(mu, sigma, n, left);
    if(unknown == 1) mu = stat_sum_mu_from_cutoff(x, sigma, n, left);
    if(unknown == 2) sigma = stat_sum_sigma_from_cutoff(x, mu, n, left);
    if(unknown == 3)
        count = stat_sum_n_from_cutoff(x, mu, sigma, left,
                                       roots, ARRAY_SIZE(roots));
    if((unknown != 3 && (!isfinite(x) || !isfinite(mu) ||
                         !isfinite(sigma))) || (unknown == 3 && count == 0)) {
        show_message("Sin solucion", "Revise signos", "y area acumulada", NULL);
        return;
    }
    solution_t s = {0};
    double z = stat_normal_inv_cdf(left);
    add_line(&s, "x=n*mu+z*sqrt(n)*sig");
    add_line(&s, "z=%.10g F=%.8g", z, left);
    add_line(&s, "x=%.10g", x);
    add_line(&s, "mu=%.10g", mu);
    add_line(&s, "sigma=%.10g", sigma);
    if(unknown == 3) {
        add_line(&s, "Sea y=sqrt(n)");
        add_line(&s, "mu*y^2+z*sig*y-x=0");
        for(int i = 0; i < count; i++) {
            add_line(&s, "n%d teorico=%.10g", i + 1, roots[i]);
            if(roots[i] <= 100000000.0)
                add_line(&s, "n entero cercano=%d",
                         (int)floor(roots[i] + 0.5));
            else add_line(&s, "n supera limite interfaz");
        }
    }
    else {
        add_line(&s, "n=%d", n);
        add_line(&s, "Verif F=%.10g",
                 stat_normal_event(n * mu, sqrt((double)n) * sigma,
                                   STAT_LE, x, x));
    }
    show_solution("Suma: despejar", &s);
}

static void calc_sum_system(void)
{
    int n;
    double x1, f1, x2, f2, total_mu, total_sigma;
    if(!prompt_int("Cantidad n", 1, 100000000, &n)) return;
    if(!prompt_double("Corte total x1", -1e100, 1e100,
                      true, true, &x1)) return;
    if(!input_left_cdf(&f1)) return;
    if(!prompt_double("Corte total x2", -1e100, 1e100,
                      true, true, &x2)) return;
    if(!input_left_cdf(&f2)) return;
    if(!stat_normal_from_quantiles(x1, f1, x2, f2,
                                   &total_mu, &total_sigma)) {
        show_message("Sin solucion", "Las dos condiciones", "son incompatibles", NULL);
        return;
    }
    double mu = total_mu / n;
    double sigma = total_sigma / sqrt((double)n);
    solution_t s = {0};
    add_line(&s, "x1=n*mu+z1*sqrt(n)*sig");
    add_line(&s, "x2=n*mu+z2*sqrt(n)*sig");
    add_line(&s, "Sistema del total:");
    add_line(&s, "mu_total=%.10g", total_mu);
    add_line(&s, "sig_total=%.10g", total_sigma);
    add_line(&s, "mu=mu_total/n");
    add_line(&s, "mu individual=%.10g", mu);
    add_line(&s, "sig=sig_total/sqrt(n)");
    add_line(&s, "sigma individual=%.10g", sigma);
    show_solution("Sistema de suma", &s);
}

static void show_help(void)
{
    solution_t s = {0};
    add_line(&s, "STAT U123G v3 beta");
    add_line(&s, "Graph 35+E II");
    add_line(&s, "UP/DN: elegir");
    add_line(&s, "EXE: aceptar");
    add_line(&s, "EXIT: volver");
    add_line(&s, "DEL: borrar digito");
    add_line(&s, "Use punto decimal");
    add_line(&s, "Cola derecha r:");
    add_line(&s, "se convierte a F=1-r");
    add_line(&s, "Menus Despejar:");
    add_line(&s, "elija el dato faltante");
    add_line(&s, "Sistema: use 2 datos");
    add_line(&s, "Se verifican raices");
    add_line(&s, "FPC: N=0 la omite");
    add_line(&s, "Resultados con CDF");
    add_line(&s, "numerica, no tabla Z");
    add_line(&s, "Uso solo si examen");
    add_line(&s, "y docente lo permiten");
    show_solution("Ayuda", &s);
}

static void ayuda_selector(int unit);
static void ayuda_general(void);

static void run_unit1(void)
{
    static const char *items[] = {
        "AYUDA: ELEGIR MODULO",
        "Binomial", "Bin: hallar p de P",
        "Bin: hallar n de P", "Bin: momentos/desp.",
        "Poisson", "Poi: hallar lambda de P",
        "Cuantil Bin/Poisson", "Poisson: escalar tasa",
        "Regla tasa: despejar", "Poisson: lambda de P0",
        "Examen con penaliz.", "Esperado en M grupos",
        "E=M*P: despejar", "Aprox Bin->Poisson"
    };
    while(true) {
        int choice = menu_select("Unidad 1", items, ARRAY_SIZE(items));
        if(choice < 0) return;
        if(choice==0) { ayuda_selector(1); continue; }
        choice--;
        switch(choice) {
        case 0: calc_binomial(); break;
        case 1: calc_binomial_solve_p(); break;
        case 2: calc_binomial_solve_n(); break;
        case 3: calc_binomial_moments(); break;
        case 4: calc_poisson(); break;
        case 5: calc_poisson_solve_lambda(); break;
        case 6: calc_discrete_quantile(); break;
        case 7: calc_scaled_poisson(); break;
        case 8: calc_poisson_scale_unknown(); break;
        case 9: calc_poisson_from_p0(); break;
        case 10: calc_scored_exam(); break;
        case 11: calc_expected_groups(); break;
        case 12: calc_expected_relation(); break;
        case 13: calc_poisson_approx(); break;
        }
    }
}

static void run_unit2(void)
{
    static const char *items[] = {
        "AYUDA: ELEGIR MODULO",
        "Normal: probabilidad", "Normal: cuantil/corte",
        "Normal: despejar dato", "Sistema: hallar mu,sig",
        "Normal: intervalo sim.", "Aprox normal-binomial",
        "Esperado en poblacion"
    };
    while(true) {
        int choice = menu_select("Unidad 2", items, ARRAY_SIZE(items));
        if(choice < 0) return;
        if(choice==0) { ayuda_selector(2); continue; }
        choice--;
        switch(choice) {
        case 0: calc_normal(); break;
        case 1: calc_normal_cutoff(); break;
        case 2: calc_normal_one_unknown(); break;
        case 3: calc_normal_params(); break;
        case 4: calc_normal_symmetric(); break;
        case 5: calc_normal_binomial(); break;
        case 6: calc_normal_expected(); break;
        }
    }
}

static void run_unit3(void)
{
    static const char *items[] = {
        "AYUDA: ELEGIR MODULO",
        "Media muestral", "Suma / peso total",
        "Corte de media", "Tamano muestral",
        "Parametros de Xbarra", "Xbarra: despejar dato",
        "Sistema de Xbarra", "Error/conf: despejar",
        "Suma: despejar dato", "Sistema de suma"
    };
    while(true) {
        int choice = menu_select("Unidad 3", items, ARRAY_SIZE(items));
        if(choice < 0) return;
        if(choice==0) { ayuda_selector(3); continue; }
        choice--;
        switch(choice) {
        case 0: calc_sample_mean(); break;
        case 1: calc_sum(); break;
        case 2: calc_sample_cutoff(); break;
        case 3: calc_sample_size(); break;
        case 4: calc_sample_params(); break;
        case 5: calc_sample_one_unknown(); break;
        case 6: calc_sample_system(); break;
        case 7: calc_margin_relation(); break;
        case 8: calc_sum_one_unknown(); break;
        case 9: calc_sum_system(); break;
        }
    }
}

typedef struct {const char *name,*situacion,*modulo,*porque,*cargar,*atencion;} consejo_t;
static const consejo_t ayuda_u1[]={
 {"Exactamente / al menos","Exitos en n ensayos","U1 > Binomial","X cuenta exitos","n, p, evento, k",">= incluye al k"},
 {"Algun evento en zona","Impactos o llamadas","U1 > Poisson","Conteos en tiempo/area","lambda y evento","L=tasa por area"},
 {"Tasa cambia tiempo","Por hora, pide minuto","U1 > Poisson escalar","L=L0*t/t0","L0, t0, t, k","Mismas unidades"},
 {"Cuantos con evento","M lotes o clientes","U1 > Esperado M","Cantidad=M*P","P evento y M","Cantidad NO es P"},
 {"Dato p desconocido","Dan n y prob evento","U1 > Bin hallar p","Resolver P=f(p)","n, evento, P dada","P puede dar 2 p"},
 {"Numero n desconocid","Dan p y prob evento","U1 > Bin hallar n","n debe ser entero","p, evento, P dada","Verif enteros"},
 {"Examen y penalidad","Acierto suma puntos","U1 > Examen","Modelar aciertos X","n,p,premio,multa","Corte por puntaje"}
};
static const consejo_t ayuda_u2[]={
 {"Menor / mayor x","X normal en intervalo","U2 > Normal probab.","z=(x-mu)/sigma","mu,sigma,x","Der=1-Phi(z)"},
 {"Entre dos tiempos","Normal entre a y b","U2 > Normal probab.","P=Phi(zb)-Phi(za)","mu,sigma,a,b","Convertir AMBOS"},
 {"Top 10 pct rapido","Buscan limite de X","U2 > Cuantil normal","F=1-porc superior","mu,sigma,area","x=mu+z*sigma"},
 {"2 percentiles dados","Se buscan mu y sigma","U2 > Sistema mu sig","x1=mu+z1*sigma","x1,F1,x2,F2","Dos ecuaciones"},
 {"Corte / mu / sigma","Falta dato normal","U2 > Despejar dato","x=mu+z*sigma","datos, area, opcion","Verificar signo"},
 {"Binomial muy grande","Aproximar con Z","U2 > Normal-binomial","mu=np, sig=sqrt(npq)","n,p,evento,k","Corregir con 0.5"}
};
static const consejo_t ayuda_u3[]={
 {"Media de n datos","Promedio de muestra","U3 > Media muestral","EE=sigma/sqrt(n)","mu,sigma,n,corte","No usar sigma sola"},
 {"Peso total de cajas","SUMA, no promedio","U3 > Suma total","muS=n*mu","mu,sigma,n,corte","sigS=sqrt(n)*sig"},
 {"Hallar n minimo","Error E o precision","U3 > Tam muestra","n=(z*sig/E)^2","sigma,confianza,E","Redondear ARRIBA"},
 {"Promedio limite","Xbarra supera valor","U3 > Corte media","x=mu+z*EE","mu,sigma,n,area","Cola derecha 1-F"},
 {"Dato muestral falta","Se pide mu,sigma,n","U3 > Xbarra desp.","Despejar de Z","prob, datos, unknown","n tiene que entero"},
 {"Muestra sin reemplaz","Poblacion finita N","U3 > Media muestral","FPC=sqrt((N-n)/(N-1))","N total, n muestra","No aplica si N=0"},
 {"Dos medias/percent","Reconstruir mu y sig","U3 > Sistema Xbarra","2 ecuaciones en Z","dos cortes y areas","SE antes que sig"}
};
static void ayuda_selector(int unit)
{
    const consejo_t *a=unit==1?ayuda_u1:unit==2?ayuda_u2:ayuda_u3;
    int n=unit==1?ARRAY_SIZE(ayuda_u1):unit==2?ARRAY_SIZE(ayuda_u2):ARRAY_SIZE(ayuda_u3);
    const char *names[10];
    for(int i=0;i<n;i++)names[i]=a[i].name;
    int c=menu_select("QUE PIDE EL ENUNCIADO",names,n);
    if(c<0)return;
    solution_t s={0};
    add_section(&s,"PASO 2: RECONOCER");add_line(&s,"%s",a[c].situacion);
    add_section(&s,"PASO 3: MODULO");add_line(&s,"%s",a[c].modulo);
    add_section(&s,"PASO 4: POR QUE");add_line(&s,"%s",a[c].porque);
    add_section(&s,"PASO 5: QUE CARGAR");add_line(&s,"%s",a[c].cargar);
    add_section(&s,"PASO 6: ATENCION");add_line(&s,"%s",a[c].atencion);
    show_solution("Guia de seleccion",&s);
}
static void ayuda_general(void)
{
    static const char *names[]={"U1: Binomial/Poisson","U2: Distrib Normal","U3: Media y muestra","Teclas del resolutor"};
    int c=menu_select("GUIA: ELEGIR MODULO",names,ARRAY_SIZE(names));
    if(c<0)return;
    if(c<3){ayuda_selector(c+1);return;}
    show_help();
}

int main(void)
{
    static const char *items[] = {
        "GUIA: ELEGIR MODULO", "Unidad 1: Bin/Poi",
        "Unidad 2: Normal", "Unidad 3: Muestreo", "Ayuda / Acerca de"
    };
    while(true) {
        int choice = menu_select("STAT U123", items, ARRAY_SIZE(items));
        if(choice < 0) return 1;
        if(choice == 0) ayuda_general();
        if(choice == 1) run_unit1();
        if(choice == 2) run_unit2();
        if(choice == 3) run_unit3();
        if(choice == 4) show_help();
    }
}
