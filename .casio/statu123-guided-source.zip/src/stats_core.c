#include "stats_core.h"

#include <float.h>
#include <math.h>

#define STAT_PI 3.14159265358979323846264338327950288
#define STAT_SQRT_2PI 2.50662827463100050241576528481104525

static double clamp01(double x)
{
    if(x < 0.0) return 0.0;
    if(x > 1.0) return 1.0;
    return x;
}

bool stat_probability_valid(double p, bool strict)
{
    return isfinite(p) && (strict ? (p > 0.0 && p < 1.0)
                                   : (p >= 0.0 && p <= 1.0));
}

/* Abramowitz-Stegun 26.2.17. Max absolute error is below 8e-8. */
double stat_normal_cdf(double z)
{
    if(isnan(z)) return NAN;
    if(z == INFINITY) return 1.0;
    if(z == -INFINITY) return 0.0;

    double x = fabs(z);
    double t = 1.0 / (1.0 + 0.2316419 * x);
    double poly = t * (0.319381530 + t * (-0.356563782 +
                  t * (1.781477937 + t * (-1.821255978 +
                  t * 1.330274429))));
    double tail = exp(-0.5 * x * x) * poly / STAT_SQRT_2PI;
    return clamp01(z >= 0.0 ? 1.0 - tail : tail);
}

/* Peter J. Acklam's inverse-normal rational approximation. */
double stat_normal_inv_cdf(double p)
{
    static const double a[] = {
        -3.969683028665376e+01,  2.209460984245205e+02,
        -2.759285104469687e+02,  1.383577518672690e+02,
        -3.066479806614716e+01,  2.506628277459239e+00
    };
    static const double b[] = {
        -5.447609879822406e+01,  1.615858368580409e+02,
        -1.556989798598866e+02,  6.680131188771972e+01,
        -1.328068155288572e+01
    };
    static const double c[] = {
        -7.784894002430293e-03, -3.223964580411365e-01,
        -2.400758277161838e+00, -2.549732539343734e+00,
         4.374664141464968e+00,  2.938163982698783e+00
    };
    static const double d[] = {
         7.784695709041462e-03,  3.224671290700398e-01,
         2.445134137142996e+00,  3.754408661907416e+00
    };
    const double p_low = 0.02425;
    const double p_high = 1.0 - p_low;
    double q, r, x;

    if(p <= 0.0) return -INFINITY;
    if(p >= 1.0) return INFINITY;

    if(p < p_low) {
        q = sqrt(-2.0 * log(p));
        x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q +
             c[4]) * q + c[5]) /
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0);
    }
    else if(p <= p_high) {
        q = p - 0.5;
        r = q * q;
        x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r +
             a[4]) * r + a[5]) * q /
            (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r +
             b[4]) * r + 1.0);
    }
    else {
        q = sqrt(-2.0 * log(1.0 - p));
        x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q +
              c[4]) * q + c[5]) /
             ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0);
    }

    /* One Newton correction aligns the inverse with our CDF routine. */
    double density = exp(-0.5 * x * x) / STAT_SQRT_2PI;
    if(density > DBL_MIN) x -= (stat_normal_cdf(x) - p) / density;
    return x;
}

double stat_normal_event(double mu, double sigma, stat_event_t event,
                         double a, double b)
{
    if(!isfinite(mu) || !isfinite(sigma) || sigma <= 0.0) return NAN;
    double za = (a - mu) / sigma;
    double lo, hi, inside;

    switch(event) {
    case STAT_EQ:
        return 0.0;
    case STAT_LE:
    case STAT_LT:
        return stat_normal_cdf(za);
    case STAT_GE:
    case STAT_GT:
        return clamp01(1.0 - stat_normal_cdf(za));
    case STAT_BETWEEN:
    case STAT_OUTSIDE:
        lo = fmin(a, b);
        hi = fmax(a, b);
        inside = stat_normal_cdf((hi - mu) / sigma) -
                 stat_normal_cdf((lo - mu) / sigma);
        return event == STAT_BETWEEN ? clamp01(inside)
                                     : clamp01(1.0 - inside);
    default:
        return NAN;
    }
}

double stat_normal_cutoff(double mu, double sigma, double left_cdf)
{
    if(!isfinite(mu) || !isfinite(sigma) || sigma <= 0.0 ||
       !stat_probability_valid(left_cdf, true)) return NAN;
    return mu + sigma * stat_normal_inv_cdf(left_cdf);
}

bool stat_normal_from_quantiles(double x1, double left_cdf1,
                                double x2, double left_cdf2,
                                double *mu, double *sigma)
{
    if(!mu || !sigma || !isfinite(x1) || !isfinite(x2) ||
       !stat_probability_valid(left_cdf1, true) ||
       !stat_probability_valid(left_cdf2, true) || x1 == x2 ||
       left_cdf1 == left_cdf2) return false;

    double z1 = stat_normal_inv_cdf(left_cdf1);
    double z2 = stat_normal_inv_cdf(left_cdf2);
    double s = (x2 - x1) / (z2 - z1);
    if(!isfinite(s) || s <= 0.0) return false;
    *sigma = s;
    *mu = x1 - z1 * s;
    return isfinite(*mu);
}

double stat_normal_mu_from_quantile(double x, double sigma,
                                    double left_cdf)
{
    if(!isfinite(x) || !isfinite(sigma) || sigma <= 0.0 ||
       !stat_probability_valid(left_cdf, true)) return NAN;
    return x - stat_normal_inv_cdf(left_cdf) * sigma;
}

double stat_normal_sigma_from_quantile(double x, double mu,
                                       double left_cdf)
{
    if(!isfinite(x) || !isfinite(mu) ||
       !stat_probability_valid(left_cdf, true)) return NAN;
    double z = stat_normal_inv_cdf(left_cdf);
    if(fabs(z) < 1e-14) return NAN;
    double sigma = (x - mu) / z;
    return isfinite(sigma) && sigma > 0.0 ? sigma : NAN;
}

double stat_normal_symmetric_halfwidth(double sigma,
                                       double central_probability)
{
    if(!isfinite(sigma) || sigma <= 0.0 ||
       !stat_probability_valid(central_probability, true)) return NAN;
    return sigma * stat_normal_inv_cdf(0.5 + central_probability / 2.0);
}

static double log_factorial(int n)
{
    if(n < 2) return 0.0;
    if(n < 256) {
        double sum = 0.0;
        for(int i = 2; i <= n; i++) sum += log((double)i);
        return sum;
    }
    double x = (double)n;
    double x2 = x * x;
    return (x + 0.5) * log(x) - x + 0.5 * log(2.0 * STAT_PI) +
           1.0 / (12.0 * x) - 1.0 / (360.0 * x * x2) +
           1.0 / (1260.0 * x * x2 * x2);
}

double stat_binomial_pmf(int n, double p, int k)
{
    if(n < 0 || k < 0 || k > n || !stat_probability_valid(p, false))
        return 0.0;
    if(p == 0.0) return k == 0 ? 1.0 : 0.0;
    if(p == 1.0) return k == n ? 1.0 : 0.0;

    double q = 1.0 - p;
    double lp = log_factorial(n) - log_factorial(k) -
                log_factorial(n - k) + k * log(p) +
                (n - k) * log(q);
    return exp(lp);
}

/* Stable finite-range sum, expanding from the distribution's mode. */
static double binomial_range(int n, double p, int lo, int hi)
{
    if(lo < 0) lo = 0;
    if(hi > n) hi = n;
    if(lo > hi || n < 0) return 0.0;
    if(p == 0.0) return lo <= 0 && 0 <= hi ? 1.0 : 0.0;
    if(p == 1.0) return lo <= n && n <= hi ? 1.0 : 0.0;

    double q = 1.0 - p;
    int mode = (int)floor((n + 1.0) * p);
    if(mode < 0) mode = 0;
    if(mode > n) mode = n;
    double p_mode = stat_binomial_pmf(n, p, mode);
    double sum = (mode >= lo && mode <= hi) ? p_mode : 0.0;

    double pk = p_mode;
    for(int k = mode; k > 0; k--) {
        pk *= ((double)k / (n - k + 1.0)) * (q / p);
        int j = k - 1;
        if(j >= lo && j <= hi) sum += pk;
        if(j < lo && pk < DBL_EPSILON * fmax(sum, DBL_MIN)) break;
    }

    pk = p_mode;
    for(int k = mode; k < n; k++) {
        pk *= ((double)(n - k) / (k + 1.0)) * (p / q);
        int j = k + 1;
        if(j >= lo && j <= hi) sum += pk;
        if(j > hi && pk < DBL_EPSILON * fmax(sum, DBL_MIN)) break;
    }
    return clamp01(sum);
}

double stat_binomial_event(int n, double p, stat_event_t event,
                           int a, int b)
{
    if(n < 0 || !stat_probability_valid(p, false)) return NAN;
    switch(event) {
    case STAT_EQ: return binomial_range(n, p, a, a);
    case STAT_LE: return binomial_range(n, p, 0, a);
    case STAT_LT: return binomial_range(n, p, 0, a - 1);
    case STAT_GE: return binomial_range(n, p, a, n);
    case STAT_GT: return binomial_range(n, p, a + 1, n);
    case STAT_BETWEEN:
        return binomial_range(n, p, a < b ? a : b, a < b ? b : a);
    case STAT_OUTSIDE: {
        int lo = a < b ? a : b;
        int hi = a < b ? b : a;
        return clamp01(binomial_range(n, p, 0, lo) +
                       binomial_range(n, p, hi, n));
    }
    default: return NAN;
    }
}

static void append_root(double *roots, int *count, int max_roots,
                        double root)
{
    if(!roots || !count || *count >= max_roots || !isfinite(root)) return;
    for(int i = 0; i < *count; i++)
        if(fabs(roots[i] - root) <= 1e-7 * fmax(1.0, fabs(root))) return;
    roots[*count] = root;
    (*count)++;
}

int stat_binomial_solve_p(int n, stat_event_t event, int a, int b,
                          double target_probability, double *roots,
                          int max_roots)
{
    if(n <= 0 || !roots || max_roots <= 0 ||
       !stat_probability_valid(target_probability, true)) return 0;

    const int segments = 512;
    int count = 0;
    double x0 = 0.0;
    double f0 = stat_binomial_event(n, x0, event, a, b) -
                target_probability;
    double best_x = x0;
    double best_abs = fabs(f0);
    bool zero_run = f0 == 0.0;
    if(zero_run) append_root(roots, &count, max_roots, x0);

    for(int i = 1; i <= segments; i++) {
        double x1 = i / (double)segments;
        double f1 = stat_binomial_event(n, x1, event, a, b) -
                    target_probability;
        if(fabs(f1) < best_abs) {
            best_abs = fabs(f1);
            best_x = x1;
        }
        if(f1 == 0.0 && !zero_run)
            append_root(roots, &count, max_roots, x1);
        if(isfinite(f0) && isfinite(f1) && f0 * f1 < 0.0) {
            double lo = x0, hi = x1, flo = f0;
            for(int j = 0; j < 64; j++) {
                double mid = 0.5 * (lo + hi);
                double fm = stat_binomial_event(n, mid, event, a, b) -
                            target_probability;
                if(flo * fm <= 0.0) hi = mid;
                else { lo = mid; flo = fm; }
            }
            append_root(roots, &count, max_roots, 0.5 * (lo + hi));
        }
        x0 = x1;
        f0 = f1;
        zero_run = f1 == 0.0;
    }
    /* Catch a tangential solution where the curve only touches the target. */
    if(count == 0) {
        double step = 1.0 / segments;
        double lo = fmax(0.0, best_x - step);
        double hi = fmin(1.0, best_x + step);
        for(int i = 0; i < 72; i++) {
            double m1 = (2.0 * lo + hi) / 3.0;
            double m2 = (lo + 2.0 * hi) / 3.0;
            double e1 = fabs(stat_binomial_event(n, m1, event, a, b) -
                             target_probability);
            double e2 = fabs(stat_binomial_event(n, m2, event, a, b) -
                             target_probability);
            if(e1 <= e2) hi = m2;
            else lo = m1;
        }
        double tangent = 0.5 * (lo + hi);
        if(fabs(stat_binomial_event(n, tangent, event, a, b) -
                target_probability) < 1e-9)
            append_root(roots, &count, max_roots, tangent);
    }
    return count;
}

int stat_binomial_best_n(double p, stat_event_t event, int a, int b,
                         double target_probability, int min_n, int max_n,
                         double *matched_probability)
{
    if(!stat_probability_valid(p, false) ||
       !stat_probability_valid(target_probability, false) ||
       min_n < 1 || max_n < min_n || !matched_probability) return -1;
    int best_n = -1;
    double best_p = NAN;
    double best_error = INFINITY;
    for(int n = min_n; n <= max_n; n++) {
        double probability = stat_binomial_event(n, p, event, a, b);
        double error = fabs(probability - target_probability);
        if(error < best_error) {
            best_error = error;
            best_n = n;
            best_p = probability;
        }
    }
    *matched_probability = best_p;
    return best_n;
}

int stat_binomial_quantile(int n, double p, double left_cdf)
{
    if(n < 0 || !stat_probability_valid(p, false) ||
       !stat_probability_valid(left_cdf, true)) return -1;
    int lo = 0, hi = n;
    while(lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if(stat_binomial_event(n, p, STAT_LE, mid, mid) >= left_cdf)
            hi = mid;
        else lo = mid + 1;
    }
    return lo;
}

bool stat_binomial_from_mean_variance(double mean, double variance,
                                      double *n_real, double *p)
{
    if(!n_real || !p || !isfinite(mean) || !isfinite(variance) ||
       mean <= 0.0 || variance < 0.0 || variance >= mean) return false;
    double solved_p = 1.0 - variance / mean;
    double solved_n = mean / solved_p;
    if(!isfinite(solved_n) || solved_n <= 0.0 || solved_p <= 0.0 ||
       solved_p > 1.0) return false;
    *n_real = solved_n;
    *p = solved_p;
    return true;
}

double stat_binomial_normal_approx(int n, double p, stat_event_t event,
                                   int a, int b)
{
    if(n <= 0 || !stat_probability_valid(p, true)) return NAN;
    double mu = n * p;
    double sigma = sqrt(n * p * (1.0 - p));
    switch(event) {
    case STAT_EQ:
        return stat_normal_event(mu, sigma, STAT_BETWEEN,
                                 a - 0.5, a + 0.5);
    case STAT_LE:
        return stat_normal_event(mu, sigma, STAT_LE, a + 0.5, 0.0);
    case STAT_LT:
        return stat_normal_event(mu, sigma, STAT_LT, a - 0.5, 0.0);
    case STAT_GE:
        return stat_normal_event(mu, sigma, STAT_GE, a - 0.5, 0.0);
    case STAT_GT:
        return stat_normal_event(mu, sigma, STAT_GT, a + 0.5, 0.0);
    case STAT_BETWEEN: {
        int lo = a < b ? a : b;
        int hi = a < b ? b : a;
        return stat_normal_event(mu, sigma, STAT_BETWEEN,
                                 lo - 0.5, hi + 0.5);
    }
    case STAT_OUTSIDE: {
        int lo = a < b ? a : b;
        int hi = a < b ? b : a;
        return stat_normal_event(mu, sigma, STAT_OUTSIDE,
                                 lo + 0.5, hi - 0.5);
    }
    default: return NAN;
    }
}

double stat_poisson_pmf(double lambda, int k)
{
    if(!isfinite(lambda) || lambda < 0.0 || k < 0) return 0.0;
    if(lambda == 0.0) return k == 0 ? 1.0 : 0.0;
    return exp(-lambda + k * log(lambda) - log_factorial(k));
}

static double poisson_finite_range(double lambda, int lo, int hi)
{
    if(lo < 0) lo = 0;
    if(hi < lo) return 0.0;
    if(lambda == 0.0) return lo == 0 ? 1.0 : 0.0;

    int mode = (int)floor(lambda);
    if(mode < 0) mode = 0;
    double p_mode = stat_poisson_pmf(lambda, mode);
    double sum = (mode >= lo && mode <= hi) ? p_mode : 0.0;

    if(lo <= mode) {
        double pk = p_mode;
        for(int k = mode; k > lo; k--) {
            pk *= k / lambda;
            int j = k - 1;
            if(j <= hi) sum += pk;
        }
    }
    if(hi >= mode) {
        double pk = p_mode;
        for(int k = mode; k < hi; k++) {
            pk *= lambda / (k + 1.0);
            int j = k + 1;
            if(j >= lo) sum += pk;
        }
    }
    return clamp01(sum);
}

static double poisson_tail_ge(double lambda, int k)
{
    if(k <= 0) return 1.0;
    if(k <= lambda) return clamp01(1.0 - poisson_finite_range(lambda, 0, k - 1));

    double pk = stat_poisson_pmf(lambda, k);
    double sum = pk;
    for(int j = k; j < k + 200000; j++) {
        pk *= lambda / (j + 1.0);
        sum += pk;
        if(pk < DBL_EPSILON * fmax(sum, DBL_MIN)) break;
    }
    return clamp01(sum);
}

double stat_poisson_event(double lambda, stat_event_t event,
                          int a, int b)
{
    if(!isfinite(lambda) || lambda < 0.0) return NAN;
    switch(event) {
    case STAT_EQ: return stat_poisson_pmf(lambda, a);
    case STAT_LE: return poisson_finite_range(lambda, 0, a);
    case STAT_LT: return poisson_finite_range(lambda, 0, a - 1);
    case STAT_GE: return poisson_tail_ge(lambda, a);
    case STAT_GT: return poisson_tail_ge(lambda, a + 1);
    case STAT_BETWEEN:
        return poisson_finite_range(lambda, a < b ? a : b,
                                    a < b ? b : a);
    case STAT_OUTSIDE: {
        int lo = a < b ? a : b;
        int hi = a < b ? b : a;
        return clamp01(poisson_finite_range(lambda, 0, lo) +
                       poisson_tail_ge(lambda, hi));
    }
    default: return NAN;
    }
}

double stat_poisson_scaled_lambda(double base_lambda,
                                  double base_exposure,
                                  double target_exposure)
{
    if(!isfinite(base_lambda) || !isfinite(base_exposure) ||
       !isfinite(target_exposure) || base_lambda < 0.0 ||
       base_exposure <= 0.0 || target_exposure < 0.0) return NAN;
    return base_lambda * target_exposure / base_exposure;
}

double stat_poisson_lambda_from_p0(double p0)
{
    if(!stat_probability_valid(p0, true)) return NAN;
    return -log(p0);
}

int stat_poisson_solve_lambda(stat_event_t event, int a, int b,
                              double target_probability, double *roots,
                              int max_roots)
{
    if(!roots || max_roots <= 0 ||
       !stat_probability_valid(target_probability, true)) return 0;

    const int segments = 768;
    const double max_lambda = 1e6;
    const double umax = log1p(max_lambda);
    int count = 0;
    double x0 = 0.0;
    double f0 = stat_poisson_event(x0, event, a, b) -
                target_probability;
    double best_u = 0.0;
    double best_abs = fabs(f0);
    bool zero_run = f0 == 0.0;
    if(zero_run) append_root(roots, &count, max_roots, x0);

    for(int i = 1; i <= segments; i++) {
        double x1 = expm1(umax * i / (double)segments);
        double f1 = stat_poisson_event(x1, event, a, b) -
                    target_probability;
        if(fabs(f1) < best_abs) {
            best_abs = fabs(f1);
            best_u = umax * i / (double)segments;
        }
        if(f1 == 0.0 && !zero_run)
            append_root(roots, &count, max_roots, x1);
        if(isfinite(f0) && isfinite(f1) && f0 * f1 < 0.0) {
            double lo = x0, hi = x1, flo = f0;
            for(int j = 0; j < 72; j++) {
                double mid = 0.5 * (lo + hi);
                double fm = stat_poisson_event(mid, event, a, b) -
                            target_probability;
                if(flo * fm <= 0.0) hi = mid;
                else { lo = mid; flo = fm; }
            }
            append_root(roots, &count, max_roots, 0.5 * (lo + hi));
        }
        x0 = x1;
        f0 = f1;
        zero_run = f1 == 0.0;
    }
    /* Same tangency case as an exact Poisson mass at its maximum. */
    if(count == 0) {
        double ustep = umax / segments;
        double ulo = fmax(0.0, best_u - ustep);
        double uhi = fmin(umax, best_u + ustep);
        for(int i = 0; i < 80; i++) {
            double u1 = (2.0 * ulo + uhi) / 3.0;
            double u2 = (ulo + 2.0 * uhi) / 3.0;
            double e1 = fabs(stat_poisson_event(expm1(u1), event, a, b) -
                             target_probability);
            double e2 = fabs(stat_poisson_event(expm1(u2), event, a, b) -
                             target_probability);
            if(e1 <= e2) uhi = u2;
            else ulo = u1;
        }
        double tangent = expm1(0.5 * (ulo + uhi));
        if(fabs(stat_poisson_event(tangent, event, a, b) -
                target_probability) < 1e-9)
            append_root(roots, &count, max_roots, tangent);
    }
    return count;
}

int stat_poisson_quantile(double lambda, double left_cdf)
{
    if(!isfinite(lambda) || lambda < 0.0 ||
       !stat_probability_valid(left_cdf, true)) return -1;
    int lo = 0;
    int hi = (int)fmax(1.0, ceil(lambda));
    while(hi < 1000000 &&
          stat_poisson_event(lambda, STAT_LE, hi, hi) < left_cdf) {
        if(hi > 500000) hi = 1000000;
        else hi *= 2;
    }
    if(stat_poisson_event(lambda, STAT_LE, hi, hi) < left_cdf) return -1;
    while(lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if(stat_poisson_event(lambda, STAT_LE, mid, mid) >= left_cdf)
            hi = mid;
        else lo = mid + 1;
    }
    return lo;
}

int stat_scored_exam_min_successes(int n, double points_correct,
                                   double penalty_wrong,
                                   double passing_score)
{
    if(n < 0 || !isfinite(points_correct) || !isfinite(penalty_wrong) ||
       !isfinite(passing_score) || points_correct + penalty_wrong <= 0.0)
        return -1;
    double threshold = (passing_score + penalty_wrong * n) /
                       (points_correct + penalty_wrong);
    return (int)ceil(threshold - 1e-12);
}

double stat_sample_mean_se(double sigma, int n, int population_n)
{
    if(!isfinite(sigma) || sigma <= 0.0 || n <= 0) return NAN;
    double se = sigma / sqrt((double)n);
    if(population_n > 0) {
        if(population_n < n || population_n <= 1) return NAN;
        se *= sqrt((population_n - n) / (double)(population_n - 1));
    }
    return se;
}

double stat_sample_mean_event(double mu, double sigma, int n,
                              int population_n, stat_event_t event,
                              double a, double b)
{
    double se = stat_sample_mean_se(sigma, n, population_n);
    return stat_normal_event(mu, se, event, a, b);
}

double stat_sample_mean_cutoff(double mu, double sigma, int n,
                               int population_n, double left_cdf)
{
    double se = stat_sample_mean_se(sigma, n, population_n);
    return stat_normal_cutoff(mu, se, left_cdf);
}

double stat_sum_event(double mu, double sigma, int n,
                      stat_event_t event, double a, double b)
{
    if(n <= 0) return NAN;
    return stat_normal_event(n * mu, sqrt((double)n) * sigma,
                             event, a, b);
}

int stat_sample_size_for_mean(double sigma, double max_error,
                              double confidence)
{
    if(!isfinite(sigma) || !isfinite(max_error) || sigma <= 0.0 ||
       max_error <= 0.0 || !stat_probability_valid(confidence, true))
        return -1;
    double z = stat_normal_inv_cdf(0.5 + confidence / 2.0);
    double raw = (z * sigma / max_error) * (z * sigma / max_error);
    if(raw > 2147483646.0) return -1;
    return (int)ceil(raw - 1e-12);
}

double stat_sample_mean_mu_from_cutoff(double cutoff, double sigma, int n,
                                       int population_n, double left_cdf)
{
    double se = stat_sample_mean_se(sigma, n, population_n);
    if(!isfinite(cutoff) || !isfinite(se) ||
       !stat_probability_valid(left_cdf, true)) return NAN;
    return cutoff - stat_normal_inv_cdf(left_cdf) * se;
}

double stat_sample_mean_sigma_from_cutoff(double cutoff, double mu, int n,
                                          int population_n,
                                          double left_cdf)
{
    if(!isfinite(cutoff) || !isfinite(mu) || n <= 0 ||
       !stat_probability_valid(left_cdf, true)) return NAN;
    double z = stat_normal_inv_cdf(left_cdf);
    if(fabs(z) < 1e-14) return NAN;
    double fpc = 1.0;
    if(population_n > 0) {
        if(population_n < n || population_n <= 1) return NAN;
        fpc = sqrt((population_n - n) /
                   (double)(population_n - 1));
        if(fpc <= 0.0) return NAN;
    }
    double sigma = (cutoff - mu) * sqrt((double)n) / (z * fpc);
    return isfinite(sigma) && sigma > 0.0 ? sigma : NAN;
}

double stat_sample_mean_n_from_cutoff(double cutoff, double mu, double sigma,
                                      int population_n, double left_cdf)
{
    if(!isfinite(cutoff) || !isfinite(mu) || !isfinite(sigma) ||
       sigma <= 0.0 || !stat_probability_valid(left_cdf, true)) return NAN;
    double z = stat_normal_inv_cdf(left_cdf);
    double delta = cutoff - mu;
    if(fabs(z) < 1e-14 || fabs(delta) < 1e-14 || delta / z <= 0.0)
        return NAN;
    double desired_se = delta / z;
    double sigma2 = sigma * sigma;
    double se2 = desired_se * desired_se;
    if(population_n <= 0) return sigma2 / se2;
    if(population_n <= 1) return NAN;
    return sigma2 * population_n /
           (se2 * (population_n - 1.0) + sigma2);
}

double stat_margin_error_for_mean(double sigma, int n, double confidence)
{
    if(!isfinite(sigma) || sigma <= 0.0 || n <= 0 ||
       !stat_probability_valid(confidence, true)) return NAN;
    double z = stat_normal_inv_cdf(0.5 + confidence / 2.0);
    return z * sigma / sqrt((double)n);
}

double stat_sigma_from_margin_error(double max_error, int n,
                                    double confidence)
{
    if(!isfinite(max_error) || max_error <= 0.0 || n <= 0 ||
       !stat_probability_valid(confidence, true)) return NAN;
    double z = stat_normal_inv_cdf(0.5 + confidence / 2.0);
    return max_error * sqrt((double)n) / z;
}

double stat_sum_cutoff(double mu, double sigma, double n,
                       double left_cdf)
{
    if(!isfinite(mu) || !isfinite(sigma) || !isfinite(n) || sigma <= 0.0 ||
       n <= 0.0 || !stat_probability_valid(left_cdf, true)) return NAN;
    return n * mu + stat_normal_inv_cdf(left_cdf) * sqrt(n) * sigma;
}

double stat_sum_mu_from_cutoff(double cutoff, double sigma, double n,
                               double left_cdf)
{
    if(!isfinite(cutoff) || !isfinite(sigma) || !isfinite(n) || sigma <= 0.0 ||
       n <= 0.0 || !stat_probability_valid(left_cdf, true)) return NAN;
    return (cutoff - stat_normal_inv_cdf(left_cdf) * sqrt(n) * sigma) / n;
}

double stat_sum_sigma_from_cutoff(double cutoff, double mu, double n,
                                  double left_cdf)
{
    if(!isfinite(cutoff) || !isfinite(mu) || !isfinite(n) || n <= 0.0 ||
       !stat_probability_valid(left_cdf, true)) return NAN;
    double z = stat_normal_inv_cdf(left_cdf);
    if(fabs(z) < 1e-14) return NAN;
    double sigma = (cutoff - n * mu) / (z * sqrt(n));
    return isfinite(sigma) && sigma > 0.0 ? sigma : NAN;
}

int stat_sum_n_from_cutoff(double cutoff, double mu, double sigma,
                           double left_cdf, double *roots, int max_roots)
{
    if(!roots || max_roots <= 0 || !isfinite(cutoff) || !isfinite(mu) ||
       !isfinite(sigma) || sigma <= 0.0 ||
       !stat_probability_valid(left_cdf, true)) return 0;
    double b = stat_normal_inv_cdf(left_cdf) * sigma;
    int count = 0;
    if(fabs(mu) < 1e-14) {
        if(fabs(b) < 1e-14) return 0;
        double y = cutoff / b;
        if(y > 0.0) append_root(roots, &count, max_roots, y * y);
        return count;
    }
    double disc = b * b + 4.0 * mu * cutoff;
    if(disc < 0.0) return 0;
    double root_disc = sqrt(disc);
    double y1 = (-b + root_disc) / (2.0 * mu);
    double y2 = (-b - root_disc) / (2.0 * mu);
    if(y1 > 0.0) append_root(roots, &count, max_roots, y1 * y1);
    if(y2 > 0.0) append_root(roots, &count, max_roots, y2 * y2);
    return count;
}
