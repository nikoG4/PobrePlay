#ifndef STATS_CORE_H
#define STATS_CORE_H

#include <stdbool.h>

typedef enum {
    STAT_EQ = 0,
    STAT_LE,
    STAT_LT,
    STAT_GE,
    STAT_GT,
    STAT_BETWEEN,
    STAT_OUTSIDE
} stat_event_t;

bool stat_probability_valid(double p, bool strict);

double stat_normal_cdf(double z);
double stat_normal_inv_cdf(double p);
double stat_normal_event(double mu, double sigma, stat_event_t event,
                         double a, double b);
double stat_normal_cutoff(double mu, double sigma, double left_cdf);
bool stat_normal_from_quantiles(double x1, double left_cdf1,
                                double x2, double left_cdf2,
                                double *mu, double *sigma);
double stat_normal_mu_from_quantile(double x, double sigma,
                                    double left_cdf);
double stat_normal_sigma_from_quantile(double x, double mu,
                                       double left_cdf);
double stat_normal_symmetric_halfwidth(double sigma,
                                       double central_probability);

double stat_binomial_pmf(int n, double p, int k);
double stat_binomial_event(int n, double p, stat_event_t event,
                           int a, int b);
double stat_binomial_normal_approx(int n, double p, stat_event_t event,
                                   int a, int b);
int stat_binomial_solve_p(int n, stat_event_t event, int a, int b,
                          double target_probability, double *roots,
                          int max_roots);
int stat_binomial_best_n(double p, stat_event_t event, int a, int b,
                         double target_probability, int min_n, int max_n,
                         double *matched_probability);
int stat_binomial_quantile(int n, double p, double left_cdf);
bool stat_binomial_from_mean_variance(double mean, double variance,
                                      double *n_real, double *p);

double stat_poisson_pmf(double lambda, int k);
double stat_poisson_event(double lambda, stat_event_t event,
                          int a, int b);
double stat_poisson_scaled_lambda(double base_lambda,
                                  double base_exposure,
                                  double target_exposure);
double stat_poisson_lambda_from_p0(double p0);
int stat_poisson_solve_lambda(stat_event_t event, int a, int b,
                              double target_probability, double *roots,
                              int max_roots);
int stat_poisson_quantile(double lambda, double left_cdf);

int stat_scored_exam_min_successes(int n, double points_correct,
                                   double penalty_wrong,
                                   double passing_score);

double stat_sample_mean_se(double sigma, int n, int population_n);
double stat_sample_mean_event(double mu, double sigma, int n,
                              int population_n, stat_event_t event,
                              double a, double b);
double stat_sample_mean_cutoff(double mu, double sigma, int n,
                               int population_n, double left_cdf);
double stat_sum_event(double mu, double sigma, int n,
                      stat_event_t event, double a, double b);
int stat_sample_size_for_mean(double sigma, double max_error,
                              double confidence);
double stat_sample_mean_mu_from_cutoff(double cutoff, double sigma, int n,
                                       int population_n, double left_cdf);
double stat_sample_mean_sigma_from_cutoff(double cutoff, double mu, int n,
                                          int population_n,
                                          double left_cdf);
double stat_sample_mean_n_from_cutoff(double cutoff, double mu, double sigma,
                                      int population_n, double left_cdf);
double stat_margin_error_for_mean(double sigma, int n, double confidence);
double stat_sigma_from_margin_error(double max_error, int n,
                                    double confidence);

double stat_sum_cutoff(double mu, double sigma, double n,
                       double left_cdf);
double stat_sum_mu_from_cutoff(double cutoff, double sigma, double n,
                               double left_cdf);
double stat_sum_sigma_from_cutoff(double cutoff, double mu, double n,
                                  double left_cdf);
int stat_sum_n_from_cutoff(double cutoff, double mu, double sigma,
                           double left_cdf, double *roots, int max_roots);

#endif
