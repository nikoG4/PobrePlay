#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
build_dir="$project_dir/build-host"
mkdir -p "$build_dir"

cc -std=c11 -O2 -Wall -Wextra -Werror -pedantic \
  -I"$project_dir/src" \
  "$project_dir/src/stats_core.c" \
  "$project_dir/tests/test_stats_core.c" \
  -lm -o "$build_dir/test_stats_core"

cc -std=c11 -Wall -Wextra -Werror -pedantic -fsyntax-only \
  -I"$project_dir/tests/stubs" -I"$project_dir/src" \
  "$project_dir/src/main.c"

"$build_dir/test_stats_core"
