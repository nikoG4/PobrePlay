#ifndef TEST_GINT_DISPLAY_H
#define TEST_GINT_DISPLAY_H

#define C_WHITE 0
#define C_BLACK 1

void dclear(int color);
void drect(int x1, int y1, int x2, int y2, int color);
void drect_border(int x1, int y1, int x2, int y2,
                  int fill, int width, int border);
void dline(int x1, int y1, int x2, int y2, int color);
void dtext(int x, int y, int color, const char *text);
void dupdate(void);

#endif
