#ifndef TEST_GINT_KEYBOARD_H
#define TEST_GINT_KEYBOARD_H

typedef struct { int key; } key_event_t;
key_event_t getkey(void);

enum {
    KEY_0, KEY_1, KEY_2, KEY_3, KEY_4,
    KEY_5, KEY_6, KEY_7, KEY_8, KEY_9,
    KEY_UP, KEY_DOWN, KEY_EXE, KEY_EXIT,
    KEY_DEL, KEY_NEG, KEY_DOT, KEY_EXP,
    KEY_F1, KEY_F2, KEY_F3
};

#endif
