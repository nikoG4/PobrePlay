/* Include the real user interface, with gint provided by test doubles. */
#define main casio_program_main
#include "../src/main.c"
#undef main
#include <assert.h>

static int keys[]={KEY_F2, KEY_F2, KEY_F2, KEY_F3, KEY_EXIT};
static int kpos=0, frames=0, visible_numbers=0;
static char row[7][30];
void dclear(int x){(void)x;memset(row,0,sizeof row);}
void drect(int a,int b,int c,int d,int e){(void)a;(void)b;(void)c;(void)d;(void)e;}
void drect_border(int a,int b,int c,int d,int e,int f,int g){(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;}
void dline(int a,int b,int c,int d,int e){(void)a;(void)b;(void)c;(void)d;(void)e;}
void dtext(int x,int y,int color,const char*t){(void)x;(void)color;int idx=y==1?0:y==57?6:y>=11&&y<56?(y-11)/9+1:-1;if(idx>=0&&idx<7){snprintf(row[idx],sizeof row[idx],"%.21s",t);}}
void dupdate(void){frames++;for(int i=0;i<7;i++){if(strstr(row[i],"0.053955"))visible_numbers++;} }
key_event_t getkey(void){key_event_t a={kpos<(int)(sizeof keys/sizeof keys[0])?keys[kpos++]:KEY_EXIT};return a;}
int main(void){
    char v[160];
    portable_format(v,sizeof v,"n=%d p=%.10g P=%.10g",50,0.4,0.053955);
    assert(strstr(v,"n=50")&&strstr(v,"p=0.4")&&strstr(v,"P=0.053955"));
    portable_format(v,sizeof v,"X>=%.5g",-3.3857);
    assert(strstr(v,"-3.3857"));
    solution_t s={0};
    add_section(&s,"PASO 2: DATOS");
    add_line(&s,"x=14 n=50 p=%.5g",0.4);
    add_section(&s,"PASO 3: FORMULA");
    add_line(&s,"P=P(X<=14)");
    add_section(&s,"PASO 4: RESPUESTA");
    add_line(&s,"P = %.10g",0.053955);
    show_solution("Binomial",&s);
    assert(kpos==5);
    assert(frames>=4);
    assert(visible_numbers>=1);
    assert(s.count>=4);
    puts("PASS: numeric formatting, guided pages, answer visible, navigation");
    return 0;
}
