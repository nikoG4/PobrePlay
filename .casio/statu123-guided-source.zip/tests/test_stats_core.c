#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "stats_core.h"

static int failures = 0;
static int checks = 0;

static void check_close(const char *name, double actual, double expected,
                        double tolerance)
{
    checks++;
    double error = fabs(actual - expected);
    if(!isfinite(actual) || error > tolerance) {
        fprintf(stderr, "FAIL %-34s actual=%.12g expected=%.12g err=%.3g\n",
                name, actual, expected, error);
        failures++;
    }
}

static void check_int(const char *name, int actual, int expected)
{
    checks++;
    if(actual != expected) {
        fprintf(stderr, "FAIL %-34s actual=%d expected=%d\n",
                name, actual, expected);
        failures++;
    }
}

static void check_true(const char *name, int condition)
{
    checks++;
    if(!condition) {
        fprintf(stderr, "FAIL %s\n", name);
        failures++;
    }
}

static int contains_close(const double *values, int count, double expected,
                          double tolerance)
{
    for(int i = 0; i < count; i++)
        if(fabs(values[i] - expected) <= tolerance) return 1;
    return 0;
}

int main(void)
{
    /* Numerical primitives. */
    check_close("Phi(0)", stat_normal_cdf(0.0), 0.5, 1e-7);
    check_close("Phi^-1(0.975)", stat_normal_inv_cdf(0.975),
                1.95996398454, 2e-6);

    /* Guia 1: binomial. */
    check_close("G1 tazas: ninguna rota",
                stat_binomial_event(10, 0.10, STAT_EQ, 0, 0),
                0.3486784401, 1e-10);
    check_close("G1 tazas: exactamente una",
                stat_binomial_event(10, 0.10, STAT_EQ, 1, 1),
                0.387420489, 1e-10);
    check_close("G1 tazas: al menos una",
                stat_binomial_event(10, 0.10, STAT_GE, 1, 1),
                0.6513215599, 1e-10);
    check_close("G1 app: entre 3 y 5",
                stat_binomial_event(10, 0.20, STAT_BETWEEN, 3, 5),
                0.3158310912, 1e-10);
    check_close("G1 app: como mucho 3",
                stat_binomial_event(10, 0.20, STAT_LE, 3, 3),
                0.8791261184, 1e-10);

    /* Guia 1: examen con penalizacion. */
    int k = stat_scored_exam_min_successes(10, 1.0, 0.25, 5.0);
    check_int("G1 examen: aciertos minimos", k, 6);
    check_close("G1 examen: aprobar al azar",
                stat_binomial_event(10, 0.20, STAT_GE, k, k),
                0.0063693824, 1e-10);

    /* Guia 1: Poisson y escalado de intervalo. */
    double l15 = stat_poisson_scaled_lambda(6.0, 60.0, 15.0);
    check_close("G1 llamadas: lambda 15 min", l15, 1.5, 1e-14);
    check_close("G1 llamadas: una en 15 min",
                stat_poisson_event(l15, STAT_EQ, 1, 1),
                0.3346952402, 1e-10);
    double l30 = stat_poisson_scaled_lambda(6.0, 60.0, 30.0);
    check_close("G1 llamadas: menos de 2",
                stat_poisson_event(l30, STAT_LT, 2, 2),
                0.1991482735, 1e-10);
    double l90 = stat_poisson_scaled_lambda(6.0, 60.0, 90.0);
    check_close("G1 llamadas: al menos 3",
                stat_poisson_event(l90, STAT_GE, 3, 3),
                0.9937678049, 1e-10);
    check_close("Control: lambda desde P0",
                stat_poisson_lambda_from_p0(exp(-2.0)), 2.0, 1e-12);
    check_close("Poisson grande: CDF(1000;1000)",
                stat_poisson_event(1000.0, STAT_LE, 1000, 1000),
                0.5084093672, 3e-10);

    /* Guia 2: normal directa e inversa. */
    check_close("G2 reclutas: mas de 69",
                stat_normal_event(72.0, 6.0, STAT_GT, 69.0, 0.0),
                0.6914624613, 2e-7);
    check_close("G2 reclutas: entre 70.5 y 75",
                stat_normal_event(72.0, 6.0, STAT_BETWEEN, 70.5, 75.0),
                0.2901687869, 2e-7);
    check_close("G2 lampara: 90% excede",
                stat_normal_cutoff(10000.0, 800.0, 0.10),
                8974.758747, 0.01);

    /* Control: hallar mu y sigma desde dos areas. */
    double mu = 0.0, sigma = 0.0;
    if(!stat_normal_from_quantiles(4.0, 0.40, 6.0, 0.65,
                                   &mu, &sigma)) {
        fprintf(stderr, "FAIL Control normal inversa: no resolvio\n");
        failures++;
    }
    else {
        check_close("Control normal inversa: mu", mu, 4.793, 0.01);
        check_close("Control normal inversa: sigma", sigma, 3.13, 0.02);
    }

    /* Guia 3: media muestral y suma. */
    check_close("G3 SE n=36",
                stat_sample_mean_se(15.0, 36, 0), 2.5, 1e-14);
    check_close("G3 SE n=144",
                stat_sample_mean_se(15.0, 144, 0), 1.25, 1e-14);
    check_close("G3 media envases 498..502",
                stat_sample_mean_event(500.0, 12.0, 64, 0,
                                       STAT_BETWEEN, 498.0, 502.0),
                0.8175775605, 3e-7);
    check_close("G3 promedio examen <7",
                stat_sample_mean_event(7.2, 0.8, 50, 0,
                                       STAT_LT, 7.0, 0.0),
                0.0385499359, 3e-7);
    check_close("G3 montacargas suma >230",
                stat_sum_event(25.0, 4.0, 9, STAT_GT, 230.0, 0.0),
                0.3384611195, 3e-7);

    /* Extensions from the textbook: continuity correction and FPC. */
    check_close("Normal approx Bin(200,.5): 90..120",
                stat_binomial_normal_approx(200, 0.5, STAT_BETWEEN, 90, 120),
                0.9293470026, 3e-7);
    check_close("Finite population correction",
                stat_sample_mean_se(10.0, 50, 200),
                (10.0 / sqrt(50.0)) * sqrt(150.0 / 199.0), 1e-14);
    check_int("Sample size 95%, sigma15, E5",
              stat_sample_size_for_mean(15.0, 5.0, 0.95), 35);

    /* V1.1: despejes e inversiones. */
    double roots[6];
    int root_count = stat_binomial_solve_p(
        10, STAT_GE, 1, 1, 0.6513215599, roots, 6);
    check_true("Bin inversa p: encontro raiz",
               contains_close(roots, root_count, 0.10, 2e-9));
    double bin_tangent_target = stat_binomial_event(10, 0.10,
                                                     STAT_EQ, 1, 1);
    root_count = stat_binomial_solve_p(10, STAT_EQ, 1, 1,
                                       bin_tangent_target, roots, 6);
    check_true("Bin inversa p: raiz tangente",
               contains_close(roots, root_count, 0.10, 2e-8));
    double matched_probability = 0.0;
    check_int("Bin inversa n: mejor entero",
              stat_binomial_best_n(0.20, STAT_BETWEEN, 3, 5,
                                    0.3158310912, 1, 100,
                                    &matched_probability), 10);
    check_close("Bin inversa n: verifica P", matched_probability,
                0.3158310912, 1e-10);
    check_int("Cuantil binomial", stat_binomial_quantile(10, 0.20, 0.80), 3);
    check_close("Binomial evento fuera",
                stat_binomial_event(10, 0.20, STAT_OUTSIDE, 1, 4),
                1.0 - stat_binomial_event(10, 0.20, STAT_BETWEEN, 2, 3),
                1e-12);

    double n_real = 0.0, solved_p = 0.0;
    check_true("Bin sistema mu,var: resolvio",
               stat_binomial_from_mean_variance(2.0, 1.6,
                                                 &n_real, &solved_p));
    check_close("Bin sistema mu,var: p", solved_p, 0.20, 1e-14);
    check_close("Bin sistema mu,var: n", n_real, 10.0, 1e-12);

    root_count = stat_poisson_solve_lambda(
        STAT_EQ, 0, 0, exp(-2.0), roots, 6);
    check_true("Poisson inversa: lambda=2",
               contains_close(roots, root_count, 2.0, 2e-9));
    double poisson_target = stat_poisson_event(1.0, STAT_EQ, 2, 2);
    root_count = stat_poisson_solve_lambda(STAT_EQ, 2, 2,
                                           poisson_target, roots, 6);
    check_true("Poisson inversa: varias raices",
               root_count >= 2 && contains_close(roots, root_count, 1.0, 2e-9));
    double poi_tangent_target = stat_poisson_event(2.0, STAT_EQ, 2, 2);
    root_count = stat_poisson_solve_lambda(STAT_EQ, 2, 2,
                                           poi_tangent_target, roots, 6);
    check_true("Poisson inversa: raiz tangente",
               contains_close(roots, root_count, 2.0, 5e-8));
    check_int("Cuantil Poisson", stat_poisson_quantile(3.0, 0.60), 3);

    double x90 = stat_normal_cutoff(10.0, 2.0, 0.90);
    check_close("Normal despeje mu",
                stat_normal_mu_from_quantile(x90, 2.0, 0.90),
                10.0, 1e-10);
    check_close("Normal despeje sigma",
                stat_normal_sigma_from_quantile(x90, 10.0, 0.90),
                2.0, 1e-10);
    check_close("Normal intervalo central 95%",
                stat_normal_symmetric_halfwidth(2.0, 0.95),
                3.919927969, 5e-6);

    double xb90 = stat_sample_mean_cutoff(500.0, 12.0, 64, 0, 0.90);
    check_close("Xbarra despeje mu",
                stat_sample_mean_mu_from_cutoff(xb90, 12.0, 64, 0, 0.90),
                500.0, 1e-10);
    check_close("Xbarra despeje sigma",
                stat_sample_mean_sigma_from_cutoff(xb90, 500.0, 64, 0, 0.90),
                12.0, 1e-10);
    check_close("Xbarra despeje n",
                stat_sample_mean_n_from_cutoff(xb90, 500.0, 12.0, 0, 0.90),
                64.0, 1e-9);

    double error95 = stat_margin_error_for_mean(15.0, 36, 0.95);
    check_close("Margen despeje sigma",
                stat_sigma_from_margin_error(error95, 36, 0.95),
                15.0, 1e-10);

    double sum90 = stat_sum_cutoff(25.0, 4.0, 9.0, 0.90);
    check_close("Suma despeje mu",
                stat_sum_mu_from_cutoff(sum90, 4.0, 9.0, 0.90),
                25.0, 1e-10);
    check_close("Suma despeje sigma",
                stat_sum_sigma_from_cutoff(sum90, 25.0, 9.0, 0.90),
                4.0, 1e-10);
    root_count = stat_sum_n_from_cutoff(sum90, 25.0, 4.0, 0.90,
                                        roots, 6);
    check_true("Suma despeje n",
               contains_close(roots, root_count, 9.0, 1e-9));

    if(failures) {
        fprintf(stderr, "\n%d/%d checks failed\n", failures, checks);
        return EXIT_FAILURE;
    }
    printf("PASS: %d numerical checks\n", checks);
    return EXIT_SUCCESS;
}
