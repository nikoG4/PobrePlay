# STAT U456 v3.1 — Casio Graph 35+E II

Tres add-ins independientes `STAT-U4.g1a`, `STAT-U5.g1a`, `STAT-U6.g1a`.

## Novedades v3.1

- U4: **Region exacta binom**: ingresar `n`, `p0`, `alfa` y tipo de cola. Calcula frontera crítica discreta y probabilidad real de error tipo I. Para bilateral puede haber regiones no contiguas: comprueba cada x con «Binomial exacta».
- U5: **F razon H0 original**: ingresar `var1` observada, `var2` observada, `var1` poblacional postulada, `var2` poblacional postulada, `n1`, `n2`, alfa y cola. Usa varianzas muestrales **corregidas** y no obliga al usuario a dividir las varianzas. Modelo supone normalidad e independencia.
- U5: **IC t datos crudos**: introducción de n mediciones, calcula media, suma de desviaciones cuadráticas, desviación con divisor n, t crítico, error, margen e intervalo.
- U6: **Ajuste desde %**: ingresar O y p teórica (como proporción 0..1) por categoría. Valida que la suma de probabilidades sea 1. Calcula E=N*p, χ², gl y p-valor.
- U6: **Sumar muchos Ji2**: ingresar de 2 a 12 estadísticos y sus gl (solo si son independientes) y calcular el contraste conjunto.
- U6: **Yates 2 clases**: contraste 1×2 con corrección de continuidad, no confundir con Yates 2×2.
- U6: **F4 CELDAS/CATEGORIAS** en independencia y bondad de ajuste para inspeccionar todos los totales, esperados y contribuciones sin consumir RAM del programa guardando cientos de líneas.
- Contrastes: muestran de qué distribución/cola viene el p-valor, además de decisiones ilustrativas con α=0.05 y 0.01 en el procedimiento, sin introducir otra vez la muestra.
- Ayuda «Elegir prueba»: ahora incluye los modos nuevos (40 situaciones).

## Navegación
- Terminado el ingreso comienza directamente PASO 1. No hay pantalla de resultado separada.
- `F2` o `↓`: siguiente pantalla, `↑`: anterior, `F3`: última pantalla.
- `F1`: gráfico donde exista. `F4`: vista de categorías/celdas donde se indique.
- `EXIT`: salir del desarrollo. Para algunas vistas `EXE` selecciona detalle y vuelve.

## Cómo probar ejemplos del libro

### Spiegel 11.52 (U5 → F razon H0 original)
`90 → 50 → 40 → 60 → 10 → 15 → 0.05 → Derecha`.
F = (90/40)/(50/60) = 2.7, gl1=9, gl2=14, p≈0.04666. No confundir varianzas muestrales con desviaciones.

### Spiegel 12.28 (U6 → Ajuste desde %)
`k=5`; pares `(22,0.12)`, `(34,0.18)`, `(66,0.40)`, `(16,0.18)`, `(12,0.12)`; `parametros estimados=0`; `alfa=0.05`.
E=18,27,60,27,18; χ²≈9.785185, gl=4, p≈0.04421. `F4` muestra todas las categorías.

### Spiegel 12.58 (U6 → Sumar muchos Ji2)
`5` pruebas; pares `(8.3,4)`, `(9.1,4)`, `(8.9,4)`, `(7.8,4)`, `(8.6,4)`; `alfa=0.05`. χ²=42.7, gl=20, p≈0.00224.

### Spiegel 12.27 (U6 → Yates 2 clases)
`37 → 23 → 0.5 → 0.05` → χ² corregida≈2.816667, gl1.

### Spiegel 11.27 (U5 → IC t datos crudos)
`5` mediciones: `0.28`, `0.30`, `0.27`, `0.33`, `0.31`; confianza `0.95`.
Media=0.298; desviación divisor n≈0.0213542; IC≈[0.268356, 0.327644].

### Spiegel 10.6 (U4 → Region exacta binom)
`n=50`, `p0=0.4`, `alfa=0.05`, `Izquierda`: región exacta conservadora hasta `x=13` (en x=14 p≈0.053955 y no se rechaza).

## Compilar
Con fxSDK y gint: `fxsdk build-fx`; el CMakeLists.txt genera los tres G1A. La rama Actions de PobrePlay sirve solamente como entorno de compilación.

## Límites conocidos
- La Casio no lee enunciados libres con IA; la ayuda orienta al usuario a seleccionar método.
- La pantalla de 128×64 y la RAM limitada requieren repartir la explicación en páginas y ofrecer F4 para tablas grandes.
- Las categorías con esperados bajos (<5) requieren revisión y, si son ordenadas, eventual reagrupación estadísticamente justificada.
- F contra razón no unitaria presupone varianzas muestrales **corregidas** (divisor n-1); contrasta razón de varianzas poblacionales.
- Las pruebas de hipótesis dependen de los supuestos de cada método; el programa no prueba automáticamente normalidad o independencia.
- En contrastes bilaterales discretos, la región crítica puede no ser un intervalo simple: no inferir todos los x entre los extremos.
- Solo se automatiza la comparación al 5% y 1% para las pruebas aplicables; no es un intérprete general de múltiples incisos.
- Los formatos y pruebas C se validaron en un simulador simple; el funcionamiento físico necesita confirmarse con tu Casio.
