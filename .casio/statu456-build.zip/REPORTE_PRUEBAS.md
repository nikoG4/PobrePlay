# Regresión STAT U456 v3.1
- 37 pruebas core stats, 12 inversas, 20 extraordinarias: **69/69 OK**.
- 14 pruebas numéricas adicionales contra referencias de los problemas de Spiegel: **14/14 OK**.
- 6 recorridos GUI simulados para los modos nuevos: **6/6 OK**.
- 2 recorridos F4 (tabla de contingencia y bondad de ajuste): **2/2 OK**.
- Compilación real fxSDK y verificación de identificadores `.g1a`: pendiente de la tarea en GitHub.
- Ejecución física en Graph 35+E II: pendiente.
