#include "inverse.h"
#include "stats.h"
#include <math.h>
#include <float.h>
static int good(double x){return isfinite(x);}
int st_inv_z_p0(double ph,double z,double n,double *p0){
  if(!p0||!good(ph)||ph<0||ph>1||!good(z)||!good(n)||n<=0)return 0;
  if(z==0){if(ph<=0||ph>=1)return 0;*p0=ph;return 1;}
  /* n*(ph-p)^2=z*z*p*(1-p); solver numerico estable. */
  double aa=n+z*z, bb=-(2*n*ph+z*z),cc=n*ph*ph;
  double disc=bb*bb-4*aa*cc;
  if(disc<0){if(disc>-1e-9)disc=0;else return 0;}
  double r1=(-bb-sqrt(disc))/(2*aa),r2=(-bb+sqrt(disc))/(2*aa);
  double r=z>0?r1:r2;
  if(!(r>0&&r<1) || (ph-r)*z<0)return 0;
  double check=(ph-r)/sqrt(r*(1-r)/n);
  if(!good(check)||fabs(check-z)>1e-6*fmax(1.,fabs(z)))return 0;
  *p0=r;return 1;
}
int st_inv_chi_expected(double o,double contribution,double *e_lo,double *e_hi){
  if(!e_lo||!e_hi||!good(o)||!good(contribution)||o<0||contribution<0)return 0;
  /* (O-E)^2/E=c => E=O+c/2 +/- sqrt(O*c+c^2/4). */
  double root=sqrt(o*contribution+contribution*contribution/4.);
  double small=o+contribution/2-root,large=o+contribution/2+root;
  if(!(large>0))return 0;
  *e_lo=small;*e_hi=large;return 1;
}
int st_inv_chi_binomial_x(double n,double p,double alpha,double *low,double *high){
  if(!low||!high||!good(n)||n<=0||p<=0||p>=1||alpha<=0||alpha>=1)return 0;
  double c=st_chi_inv(1-alpha,1),delta=sqrt(c*n*p*(1-p));
  if(!good(delta))return 0;
  *low=n*p-delta;*high=n*p+delta;return 1;
}
int st_inv_critical_z_mean(double mu,double sigma,double n,double alpha,int tail,double *lo,double *hi){
  if(!lo||!hi||!good(mu)||sigma<=0||n<=0||alpha<=0||alpha>=1||tail< -1||tail>1)return 0;
  *lo=-INFINITY;*hi=INFINITY;
  double c=st_normal_inv(1-alpha/(tail==ST_TWO?2:1)),margin=c*sigma/sqrt(n);
  if(tail!=ST_RIGHT)*lo=mu-margin;
  if(tail!=ST_LEFT)*hi=mu+margin;
  return good(margin);
}
int st_inv_critical_t_mean(double mu,double s_spiegel,double n,double alpha,int tail,double *lo,double *hi){
  if(!lo||!hi||!good(mu)||s_spiegel<=0||n<=1||alpha<=0||alpha>=1||tail< -1||tail>1)return 0;
  *lo=-INFINITY;*hi=INFINITY;
  double c=st_t_inv(1-alpha/(tail==ST_TWO?2:1),n-1),margin=c*s_spiegel/sqrt(n-1);
  if(tail!=ST_RIGHT)*lo=mu-margin;
  if(tail!=ST_LEFT)*hi=mu+margin;
  return good(margin);
}
int st_inv_min_n_z(double sigma,double diff,double alpha,int tail,int *n){
  if(!n||sigma<=0||diff<=0||alpha<=0||alpha>=1||tail< -1||tail>1)return 0;
  double c=st_normal_inv(1-alpha/(tail==ST_TWO?2:1));
  double nr=pow(c*sigma/diff,2);
  if(!good(nr)||nr>=10000000)return 0;
  int candidate=(int)ceil(nr);
  if(candidate<2)candidate=2;
  while(diff*sqrt((double)candidate)/sigma<c-1e-12)candidate++;
  *n=candidate;return 1;
}
int st_inv_min_n_t(double scorr,double diff,double alpha,int tail,int *n){
  if(!n||scorr<=0||diff<=0||alpha<=0||alpha>=1||tail<-1||tail>1)return 0;
  double quant=1-alpha/(tail==ST_TWO?2:1);
  int lower=2,upper=4;
  while(upper<=200000){
    double t=diff*sqrt((double)upper)/scorr;
    double c=st_t_inv(quant,upper-1);
    if(t>=c)break;
    lower=upper+1;upper*=2;
  }
  if(upper>200000)return 0;
  while(lower<upper){
    int mid=lower+(upper-lower)/2;
    double t=diff*sqrt((double)mid)/scorr;
    double c=st_t_inv(quant,mid-1);
    if(t>=c)upper=mid;else lower=mid+1;
  }
  *n=lower;return 1;
}
int st_inv_variance_sigma(double chi,double n,double sample_s_spiegel,double *sigma){
  if(!sigma||chi<=0||n<=1||sample_s_spiegel<=0)return 0;
  *sigma=sample_s_spiegel*sqrt(n/chi);
  return good(*sigma);
}
