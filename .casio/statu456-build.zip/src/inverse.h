#ifndef STAT456_INVERSE_H
#define STAT456_INVERSE_H
/* Soluciones inversas; toda cantidad n es tamano muestral salvo indicacion. */
int st_inv_z_p0(double ph,double z,double n,double *p0);
int st_inv_chi_expected(double o,double contribution,double *e_lo,double *e_hi);
int st_inv_chi_binomial_x(double n,double p,double alpha,double *low,double *high);
int st_inv_critical_z_mean(double mu,double sigma,double n,double alpha,int tail,double *lo,double *hi);
int st_inv_critical_t_mean(double mu,double s_spiegel,double n,double alpha,int tail,double *lo,double *hi);
int st_inv_min_n_z(double sigma,double diff,double alpha,int tail,int *n);
int st_inv_min_n_t(double scorr,double diff,double alpha,int tail,int *n);
int st_inv_variance_sigma(double chi,double n,double sample_s_spiegel,double *sigma);
#endif
