/* STAT-U4, STAT-U5, STAT-U6: interfaz gint para Graph 35+E II (128x64). */
#include <gint/display.h>
#include <gint/keyboard.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "stats.h"
#include "inverse.h"

#ifndef STAT_UNIT
#define STAT_UNIT 4
#endif
#define LINECH 22
static int cancelled=0;
static char lines[32][50];
static char procedures[72][50];
static int stepcount=0;
static char interpretation[6][50];
static int interpretcount=0;
static int auto_explain=0;
static int linecount=0;
static int result_tail=ST_TWO;
static int result_family=0; /* 1 Z, 2 t, 3 ji2 */
static STResult latest;
static int bin_n=0,bin_x=0;
static double bin_p=0;

static void printline(int y,const char *s){ char b[22];snprintf(b,sizeof b,"%.21s",s);dtext(1,y,C_BLACK,b); }
static void frame(const char *title,const char *subtitle){
  dclear(C_WHITE);drect(0,0,127,8,C_BLACK);
  dtext(2,0,C_WHITE,title);if(subtitle)printline(11,subtitle);
}
static void warnscreen(const char *a,const char *b){
  frame("AVISO",a);printline(23,b);printline(52,"EXE/EXIT volver");dupdate();getkey();
}
static int getbutton(void){return getkey().key;}
static int digit(int k){
  switch(k){
  case KEY_0:return 0;case KEY_1:return 1;case KEY_2:return 2;
  case KEY_3:return 3;case KEY_4:return 4;case KEY_5:return 5;
  case KEY_6:return 6;case KEY_7:return 7;case KEY_8:return 8;
  case KEY_9:return 9;default:return -1;
  }
}
static double readnum(const char *label,double min,double max){
  if(cancelled)return 0;
  char input[21]={0};int count=0;
  for(;;){
    frame("INTRODUCIR",label);printline(29,input);printline(53,"EXE=OK EXIT=atr.");dupdate();
    int k=getbutton(),z=digit(k);
    if(k==KEY_EXIT){cancelled=1;return 0;}
    if(k==KEY_EXE){
      if(count>0){char *end=NULL;double v=strtod(input,&end);
        if(end!=input&&*end=='\0'&&isfinite(v)&&v>=min&&v<=max)return v;
      }
      warnscreen("Valor incorrecto", "Revise los limites");
      continue;
    }
    if(k==KEY_DEL){if(count>0)input[--count]=0;continue;}
    if(z>=0&&count<18){input[count++]=(char)('0'+z);input[count]=0;continue;}
    if(k==KEY_DOT&&count<18&&!strchr(input,'.')){input[count++]='.';input[count]=0;continue;}
    if(k==KEY_NEG&&count<17){
      if(count==0){input[count++]='-';input[count]=0;}
      else if(input[count-1]=='e' || input[count-1]=='E') {input[count++]='-';input[count]=0;}
      continue;
    }
    if(k==KEY_EXP&&count>0&&count<16&&!strchr(input,'e')&&!strchr(input,'E')){input[count++]='e';input[count]=0;continue;}
  }
}
static int integer(const char *s,int lo,int hi){
  double x=readnum(s,lo,hi);if(cancelled)return 0;
  int v=(int)x;
  if(fabs(x-v)>1e-9){warnscreen("Hace falta", "numero entero");cancelled=1;return 0;}
  return v;
}
static double number(const char *s){return readnum(s,-1e12,1e12);}
static double positive(const char *s){return readnum(s,1e-12,1e12);}
static double alpha(void){return readnum("Alpha (ej. 0.05)",1e-8,0.5);}
static double confidence(void){return readnum("Confianza (ej. 0.95)",0.1,0.999999);}
static double fraction(const char *label){return readnum(label,0,1);}
static int getchoice(const char *title,const char **items,int n){
  int selected=0;
  for(;;){
    frame(title,NULL);
    int begin=selected<5?0:selected-4;
    if(begin>n-5&&n>5)begin=n-5;
    if(begin<0)begin=0;
    for(int i=begin;i<n&&i<begin+5;i++){
      char line[32];snprintf(line,sizeof(line),"%c %s",i==selected?'>':' ',items[i]);
      printline(11+(i-begin)*9,line);
    }
    printline(57,"UP/DN EXE  EXIT");dupdate();
    int k=getbutton();if(k==KEY_EXIT)return -1;
    if(k==KEY_UP)selected=(selected+n-1)%n;
    if(k==KEY_DOWN)selected=(selected+1)%n;
    if(k==KEY_EXE)return selected;
  }
}
static int tail(void){
  if(cancelled)return 0;
  static const char *names[]={"Derecha: mayor", "Izquierda: menor", "Bilateral: distinto"};
  int c=getchoice("TIPO DE CONTRASTE",names,3);
  if(c<0){cancelled=1;return 0;}
  return c==0?ST_RIGHT:c==1?ST_LEFT:ST_TWO;
}
static void resetlines(void){linecount=0;stepcount=0;interpretcount=0;result_family=0;auto_explain=0;}
static void step(const char *s){
  while(*s && stepcount<72){
    int n=(int)strlen(s);
    if(n<=21){snprintf(procedures[stepcount++],50,"%s",s);return;}
    int m=21;
    for(int i=21;i>=12;i--)if(s[i]==' '){m=i;break;}
    memcpy(procedures[stepcount],s,m);procedures[stepcount][m]=0;stepcount++;
    s+=m;while(*s==' ')s++;
  }
}
static void stepnum(const char *name,double x){char b[50];snprintf(b,sizeof b,"%s %.9g",name,x);step(b);}
static void interpret(const char *s){
  while(*s&&interpretcount<6){
    int n=(int)strlen(s),m=n<21?n:21;
    if(n>21){for(int j=21;j>=10;j--)if(s[j]==' '){m=j;break;}}
    memcpy(interpretation[interpretcount],s,m);interpretation[interpretcount++][m]=0;
    s+=m;while(*s==' ')s++;
  }
}
static void decision_steps(STResult r,int family,int tails){
  if(!r.ok)return;
  step("HIPOTESIS:");
  if(family==4){
    step("H0: varianza1=varianza2");
    step("H1: varianzas diferentes");
  } else if(family==5){
    step("H0: p=p0");
    step("H1: depende de la cola");
  } else if(family==3){
    step("H0: ajuste / independencia");
    step("H1: desajuste / dependencia");
    if(tails==ST_LEFT)step("Nota: contraste cola izquierda");
  } else {
    step(tails==ST_RIGHT?"H1: parametro > H0":tails==ST_LEFT?"H1: parametro < H0":"H1: parametro != H0");
    step("H0: parametro = valor H0");
  }
  if(family==1)step("Distribucion normal Z");
  if(family==2)step("Distribucion t Student");
  if(family==3)step("Distribucion ji cuadrada");
  if(family==4)step("Distribucion F Fisher");
  if(family==5)step("Binomial exacta");
  if(family==1||family==2){
    step("SUSTITUCION:");
    stepnum("Numerador =",r.effect);
    stepnum("Error estandar =",r.se);
    if(r.se>0)stepnum("Cociente =",r.effect/r.se);
  }
  if(family==3)step("Suma contribuciones (O-E)^2/E");
  if(family==2||family==3||family==4)stepnum("Grados libertad =",r.df);
  stepnum("Estadistico calculado =",r.statistic);
  if(isfinite(r.crit_lo))stepnum("Limite inferior =",r.crit_lo);
  if(isfinite(r.crit_hi))stepnum("Limite superior =",r.crit_hi);
  stepnum("p valor calculado =",r.p);
  step("REGLA: p valor < alpha");
  step(r.reject?"CONCLUSION: rechazar H0":"CONCLUSION: no rechazar H0");
  interpret(r.reject?"Hay evidencia contra H0.":"Evidencia insuficiente");
  if(!r.reject)interpret("para rechazar H0.");
  interpret("No prueba certeza absoluta.");
  if(r.warning)interpret("OJO: revisar supuestos.");
}

static void addline(const char *s){if(linecount<32){snprintf(lines[linecount],50,"%s",s);linecount++;}}
static void value(const char *label,double x){char s[50];snprintf(s,sizeof s,"%s %.8g",label,x);addline(s);}
static void result_base(const char *name,STResult r,int fam,int t){
  resetlines();latest=r;result_family=fam;result_tail=t;auto_explain=1;
  addline(name);
  if(!r.ok){addline("ERROR: revisar datos");return;}
  if(fam==1)addline("Modelo: Normal Z");
  if(fam==2)addline("Modelo: t Student");
  if(fam==3)addline("Modelo: ji cuadrada");
  if(fam==4)addline("Modelo: F Fisher");
  if(fam==5)addline("Modelo: binomial exacta");
  if(fam!=1)value("gl =",r.df);
  value("Estad. =",r.statistic);
  if(isfinite(r.crit_lo))value("Corte inf =",r.crit_lo);
  if(isfinite(r.crit_hi))value("Corte sup =",r.crit_hi);
  value("p valor =",r.p);
  addline(r.reject?"DECISION: RECHAZAR H0":"DECISION: NO RECH.H0");
  if(r.warning)addline("OJO: revisar supuestos");
}
static double density(double x){
  if(result_family==1)return exp(-x*x/2);
  if(result_family==2){double df=latest.df;return exp(-(df+1)/2*log1p(x*x/df));}
  if(result_family==4){
    if(x<=0)return 0;
    double a=latest.df/2,b=latest.aux/2,ratio=latest.df/latest.aux;
    return exp(a*log(ratio)+(a-1)*log(x)-(a+b)*log1p(ratio*x)-lgamma(a)-lgamma(b)+lgamma(a+b));
  }
  if(x<=0)return 0;
  double a=latest.df/2;
  return exp((a-1)*log(x/2)-x/2-lgamma(a));
}
static void chart(void){
  if(result_family==0||!latest.ok)return;
  if(result_family==5){
    frame("BINOMIAL EXACTA",NULL);
    int groups=bin_n+1;if(groups>32)groups=32;
    double probs[32]={0},maxp=0;
    for(int k=0;k<=bin_n;k++){
      int j=(int)((long long)k*groups/(bin_n+1));
      if(j>=groups)j=groups-1;
      probs[j]+=st_binom_pmf(k,bin_n,bin_p);
    }
    for(int j=0;j<groups;j++)if(probs[j]>maxp)maxp=probs[j];
    if(maxp<=0)return;
    dline(2,53,125,53,C_BLACK);
    for(int j=0;j<groups;j++){
      int xx=3+(int)(120.*j/groups),right=3+(int)(120.*(j+1)/groups)-1;
      int yy=52-(int)(30*probs[j]/maxp);
      if(right<xx)right=xx;
      for(int x=xx;x<=right;x++)dline(x,yy,x,52,C_BLACK);
    }
    int mark=3+(int)(120.*bin_x/(bin_n+1));
    dline(mark,17,mark,53,C_BLACK);
    char caption[25];snprintf(caption,sizeof caption,"x=%d n=%d p=%.2g",bin_x,bin_n,bin_p);
    printline(10,caption);
    printline(57,"Linea=observado");dupdate();getkey();return;
  }
  double low,high;
  if(result_family==3){low=0;high=fmax(latest.df+5*sqrt(2*latest.df),latest.statistic*1.1);}
  else if(result_family==4){low=0;high=fmax(st_f_inv(.99,latest.df,latest.aux),latest.statistic*1.2);if(!isfinite(high)||high>1e6)high=50;}
  else {double radius=fmax(4.0,fabs(latest.statistic)*1.15);low=-radius;high=radius;}
  frame("GRAFICO ESTADISTICO",NULL);
  char topline[25];snprintf(topline,sizeof topline,"Stat=%.4g",latest.statistic);printline(10,topline);
  int a=2,b=125,bottom=54,top=18;double maxd=1e-18;
  for(int i=0;i<=123;i++){double x=low+(high-low)*i/123;double y=density(x);if(y>maxd)maxd=y;}
  dline(a,bottom,b,bottom,C_BLACK);
  int py=bottom;
  for(int i=0;i<=123;i++){
    double x=low+(high-low)*i/123;double den=density(x);
    int yy=bottom-(int)(34*den/maxd);
    int reject=(x<=latest.crit_lo||x>=latest.crit_hi);
    if(reject && i%3==0 && yy<bottom)dline(a+i,yy+1,a+i,bottom-1,C_BLACK);
    if(i>0)dline(a+i-1,py,a+i,yy,C_BLACK);
    py=yy;
  }
  if(isfinite(latest.crit_lo)&&latest.crit_lo>=low&&latest.crit_lo<=high){
    int cx=a+(int)(123*(latest.crit_lo-low)/(high-low));dline(cx,top,cx,bottom,C_BLACK);
  }
  if(isfinite(latest.crit_hi)&&latest.crit_hi>=low&&latest.crit_hi<=high){
    int cx=a+(int)(123*(latest.crit_hi-low)/(high-low));dline(cx,top,cx,bottom,C_BLACK);
  }
  if(latest.statistic>=low&&latest.statistic<=high){
    int cx=a+(int)(123*(latest.statistic-low)/(high-low));dline(cx,bottom-9,cx,bottom,C_BLACK);
  }
  printline(57,"Rayado=RECHAZAR");dupdate();getkey();
}
static void show_result(void){
  if(!linecount)return;
  if(auto_explain && result_family && latest.ok)decision_steps(latest,result_family,result_tail);
  int pos=0,mode=0;
  for(;;){
    frame(mode==0?"RESULTADO":mode==1?"PROCEDIMIENTO":"INTERPRETACION",NULL);
    int count=mode==0?linecount:mode==1?stepcount:interpretcount;
    int displayed=0;
    for(int i=pos;i<count&&displayed<5;i++,displayed++){
      printline(11+9*displayed,mode==0?lines[i]:mode==1?procedures[i]:interpretation[i]);
    }
    printline(57,"F1=GRAF F2=PASOS F3=TXT");dupdate();
    int k=getbutton();if(k==KEY_EXIT||k==KEY_EXE)return;
    if(k==KEY_DOWN&&pos<count-5)pos++;
    if(k==KEY_UP&&pos>0)pos--;
    if(k==KEY_F1)chart();
    if(k==KEY_F2){mode=(mode==1?0:1);pos=0;}
    if(k==KEY_F3){mode=(mode==2?0:2);pos=0;}
  }
}
static void show_err(void){warnscreen("Datos no validos", "n, s, E, p, gl...");}

/* Unidad 4: decision normal (z). */
static void unit4(int op){
  STResult r={0};double x,y,s,t,n,m,a,p,z;
  cancelled=0;
  if(op==0){
    x=number("Media muestra xbar");y=number("Media H0 mu0");s=positive("Sigma poblacional");n=positive("Tamano n");a=alpha();int tailid=tail();if(cancelled)return;
    r=st_z_mean(x,y,s,n,a,tailid);result_base("Z: una media",r,1,tailid);value("Diferencia =",r.effect);value("EE =",r.se);
    step("Z=(xbar-mu0)/(sig/raiz n)");stepnum("xbar =",x);stepnum("mu0 =",y);stepnum("sigma =",s);stepnum("n =",n);
  } else if(op==1){
    x=number("Exitos x");n=positive("Tamano muestra n");p=fraction("Proporcion H0 p0");a=alpha();int tailid=tail();if(cancelled)return;
    r=st_z_prop(x,n,p,a,tailid);result_base("Z: proporcion",r,1,tailid);value("p muestra =",r.aux);value("EE nulo =",r.se);
    step("Z=(ph-p0)/raiz(p0*q0/n)");stepnum("x exitos =",x);stepnum("n =",n);stepnum("p0 =",p);stepnum("ph=x/n =",r.aux);
    if(r.warning)addline("Use test bin. exacto");
  } else if(op==2){
    x=number("Media grupo 1");y=number("Media grupo 2");s=positive("Sigma grupo 1");t=positive("Sigma grupo 2");n=positive("Tamano grupo 1");m=positive("Tamano grupo 2");a=alpha();int tailid=tail();if(cancelled)return;
    r=st_z_means(x,y,s,t,n,m,a,tailid);result_base("Z: dos medias",r,1,tailid);value("Diferencia =",r.effect);value("EE =",r.se);
    step("Z=(x1-x2)/raiz(s1^2/n1+s2^2/n2)");stepnum("x1 =",x);stepnum("x2 =",y);stepnum("sigma1 =",s);stepnum("sigma2 =",t);stepnum("n1 =",n);stepnum("n2 =",m);
  } else if(op==3){
    x=number("Exitos grupo 1");n=positive("Tamano grupo 1");y=number("Exitos grupo 2");m=positive("Tamano grupo 2");a=alpha();int tailid=tail();if(cancelled)return;
    r=st_z_props(x,n,y,m,a,tailid);result_base("Z: dos proporc.",r,1,tailid);value("Dif p1-p2 =",r.effect);value("p agrupada =",r.aux);
    step("Z=(p1-p2)/EE agrupado");stepnum("x1 =",x);stepnum("x2 =",y);stepnum("p agrupada =",r.aux);
  } else if(op==4){
    a=alpha();int tailid=tail();if(cancelled)return;
    r=st_z_test(0,a,tailid);resetlines();addline("VALOR CRITICO Z");
    if(isfinite(r.crit_lo))value("Lim inf =",r.crit_lo);
    if(isfinite(r.crit_hi))value("Lim sup =",r.crit_hi);
    addline("Compare con Z calc.");
  } else if(op==5){
    static const char *choices[]={"Hallar media xbar", "Hallar media mu0", "Hallar desvio sigma", "Hallar tamano n"};
    int which=getchoice("DESPEJAR Z",choices,4);if(which<0)return;
    z=number("Estadistico Z dado");x=number("Media xbar /0");y=number("Media H0 mu0 /0");s=positive("Sigma / 1 si falta");n=positive("n / 1 si falta");if(cancelled)return;
    resetlines();addline("Z=(xbar-mu0)/(s/raiz(n))");
    if(which==0)value("xbar =",y+z*s/sqrt(n));
    if(which==1)value("mu0 =",x-z*s/sqrt(n));
    if(which==2){if(z==0 || (x-y)/z<=0){show_err();return;}value("sigma =",(x-y)*sqrt(n)/z);}
    if(which==3){if(x==y || z==0 || (x-y)/z<0){show_err();return;}double nn=pow(z*s/(x-y),2);value("n teorico =",nn);value("n entero =",ceil(nn));}
  } else if(op==6){
    s=positive("Sigma conocida");x=positive("Diferencia min abs");a=alpha();p=fraction("Potencia deseada");int tailid=tail();if(cancelled)return;
    double za=st_normal_inv(tailid==ST_TWO?1-a/2:1-a);
    double zb=st_normal_inv(p);double nn=pow((za+zb)*s/x,2);
    resetlines();addline("n para potencia Z");value("n aproximado =",nn);value("Redondear a =",ceil(nn));addline("Aprox para mu normal");
  } else if(op==7){
    int xx=integer("Exitos observados x",0,5000);
    int nn=integer("Numero intentos n",1,5000);
    p=fraction("p0 bajo H0");a=alpha();int dir=tail();if(cancelled)return;
    r=st_binom_exact(xx,nn,p,a,dir);
    resetlines();addline("BINOMIAL EXACTA");
    latest=r;result_family=5;result_tail=dir;bin_n=nn;bin_x=xx;bin_p=p;
    step("X~Binomial(n,p0)");step("p valor=sum(P(X=k) en cola)");
    stepnum("x observado =",xx);stepnum("n =",nn);stepnum("p0 =",p);
    if(!r.ok){show_err();return;}
    value("p observada =",r.statistic);value("p valor exacto =",r.p);
    addline(r.reject?"RECHAZAR H0":"NO RECHAZAR H0");
    addline("No requiere normal Z");
  } else if(op==8){
    x=fraction("Proporcion muestra ph");z=number("Valor Z conocido");n=positive("Tamano muestra n");
    if(cancelled)return;double p0;
    if(!st_inv_z_p0(x,z,n,&p0)){show_err();return;}
    resetlines();addline("INVERSA: HALLAR p0");
    step("Z=(ph-p0)/sqrt(p0*(1-p0)/n)");
    step("Elevar al cuadrado");
    step("(n+z^2)*p0^2 -");step("(2*n*ph+z^2)*p0+");step("n*ph^2=0");
    step("Resolver cuadratica:");step("descartar raiz de signo opuesto");
    stepnum("ph =",x);stepnum("Z =",z);stepnum("n =",n);
    value("p0 recuperada =",p0);
    value("Z comprobado =",(x-p0)/sqrt(p0*(1-p0)/n));
    interpret("Dos raices al elevar cuadrado;");interpret("conservar la del signo de Z.");
  } else if(op==9){
    y=number("Media bajo H0 mu0");s=positive("Desvio pobl sigma");n=positive("Tamano n");a=alpha();int dir=tail();
    if(cancelled)return;double lo,hi;
    if(!st_inv_critical_z_mean(y,s,n,a,dir,&lo,&hi)){show_err();return;}
    resetlines();addline("XBAR CRITICA Z");
    latest=st_z_test(0,a,dir);result_family=1;result_tail=dir;step("Z=(xbar-mu0)/(sigma/sqrt n)");
    step("xbar=mu0+Zcrit*sigma/sqrt n");
    stepnum("mu0 =",y);stepnum("sigma =",s);stepnum("n =",n);stepnum("alpha =",a);
    if(isfinite(lo))value("Rechazar si X <",lo);
    if(isfinite(hi))value("Rechazar si X >",hi);
    interpret("Comparar media REAL con umbrales.");
  } else if(op==10){
    s=positive("Desvio pobl sigma");x=positive("Diferencia abs observada");a=alpha();int dir=tail();
    if(cancelled)return;int need;
    if(!st_inv_min_n_z(s,x,a,dir,&need)){show_err();return;}
    resetlines();addline("N MINIMO Z (LIMITE)");
    latest=st_z_test(x*sqrt((double)need)/s,a,ST_RIGHT);result_family=1;result_tail=ST_RIGHT;
    step("|Z|=|delta|*sqrt(n)/sigma");step("n>=(Zcrit*sigma/delta)^2");
    stepnum("sigma =",s);stepnum("|delta| =",x);stepnum("alpha =",a);
    value("n minimo entero =",need);
    value("Z a ese n =",x*sqrt((double)need)/s);
    addline("NO equivale a potencia");
    interpret("N min para ese efecto fijo.");interpret("No garantiza potencia estad.");
  } else if(op==11){
    x=number("Media grupo 1");y=number("Media grupo 2");s=positive("Sigma grupo 1");t=positive("Sigma grupo 2");
    n=readnum("Tamano grupo 1",2,1e10);m=readnum("Tamano grupo 2",2,1e10);
    z=number("Diferencia H0 delta0");a=alpha();int dir=tail();if(cancelled)return;
    r=st_z_means_delta(x,y,s,t,n,m,z,a,dir);
    result_base("Z dos medias delta0",r,1,dir);
    step("Z=((x1-x2)-delta0)/EE");
    step("EE=raiz(sig1^2/n1+sig2^2/n2)");
    stepnum("diferencia observada =",x-y);stepnum("delta0 =",z);
    value("Dif observada =",x-y);value("delta0 =",z);value("EE =",r.se);
  }
  if(cancelled)return;if(auto_explain && !r.ok)show_err();else show_result();
}

/* Unidad 5: pequenas muestras y t Student. */
static void unit5(int op){
  STResult r={0};double x,y,s,t,n,m,a,p;
  double A[ST_MAX],B[ST_MAX];cancelled=0;
  if(op==0 || op==2){
    int count=integer(op==0?"Cantidad valores n":"Cantidad parejas n",2,ST_MAX);
    if(cancelled)return;
    for(int i=0;i<count;i++){
      char label[24];snprintf(label,sizeof label,"%d - %s",i+1,op==0?"Dato X":"ANTES");A[i]=number(label);
      if(op==2){snprintf(label,sizeof label,"%d - DESPUES",i+1);B[i]=number(label);A[i]-=B[i];}
      if(cancelled)return;
    }
    y=op==0?number("Media H0 mu0"):0;
    a=alpha();int dir=tail();if(cancelled)return;
    x=st_mean(A,count);s=st_sd_pop(A,count);r=st_t_mean(x,y,s,count,a,dir);
    result_base(op==0?"t datos crudos":"t PAREADA",r,2,dir);
    step(op==2?"Diferencias = antes-despues":"Media y desvio desde datos");
    if(op==2){for(int j=0;j<count && j<12;j++){char buf[50];snprintf(buf,sizeof buf,"D[%d]=%.8g",j+1,A[j]);step(buf);}}
    step("t=(media-mu)*raiz(n-1)/s");stepnum("media =",x);stepnum("s (divide n) =",s);
    value("n =",count);value("Media dato/dif =",x);value("s divide n =",s);
    value("EE =",r.se);
  } else if(op==1){
    x=number("Media xbar");y=number("Media H0 mu0");s=positive("s formulario (div n)");n=positive("Tamano n");a=alpha();int dir=tail();if(cancelled)return;
    r=st_t_mean(x,y,s,n,a,dir);result_base("t: una media",r,2,dir);value("EE =",r.se);addline("t=(x-mu)*raiz(n-1)/s");
    step("t=(xbar-mu0)*raiz(n-1)/s");stepnum("xbar =",x);stepnum("mu0 =",y);stepnum("s (divide n) =",s);stepnum("n =",n);
  } else if(op==3 || op==4){
    x=number("Media grupo 1");y=number("Media grupo 2");s=positive(op==3?"s1 formulario (div n)":"s1 corregido (n-1)");t=positive(op==3?"s2 formulario (div n)":"s2 corregido (n-1)");n=positive("n1");m=positive("n2");a=alpha();int dir=tail();if(cancelled)return;
    r=op==3?st_t_pooled(x,y,s,t,n,m,a,dir):st_t_welch(x,y,s,t,n,m,a,dir);
    result_base(op==3?"t DOS: var iguales":"t WELCH: var distintas",r,2,dir);value("EE =",r.se);if(op==3)value("s agrupada =",r.aux);
    step(op==3?"t=(x1-x2)/(sp*raiz(1/n1+1/n2))":"Welch: t=(x1-x2)/raiz(v1/n1+v2/n2)");
    stepnum("x1 =",x);stepnum("x2 =",y);stepnum("s1 =",s);stepnum("s2 =",t);stepnum("n1 =",n);stepnum("n2 =",m);
    if(op==3)stepnum("sp agrupada =",r.aux);
  } else if(op==5){
    x=number("Media muestra xbar");s=positive("s formulario (div n)");n=positive("Tamano n");p=confidence();if(cancelled)return;
    r=st_t_ci(x,s,n,p);result_base("IC t para media",r,0,0);
    resetlines();addline("IC t para media");value("gl =",r.df);value("t critico =",r.crit_hi);value("Error =",r.se);value("Lim inferior =",r.lower);value("Lim superior =",r.upper);
  } else if(op==6){
    n=positive("Grados libertad gl");a=alpha();int dir=tail();if(cancelled)return;
    r=st_t_test(0,n,a,dir);resetlines();addline("VALOR CRITICO t");
    if(isfinite(r.crit_lo))value("Lim inf =",r.crit_lo);
    if(isfinite(r.crit_hi))value("Lim sup =",r.crit_hi);
    value("gl =",n);
  } else if(op==7){
    t=number("Estadistico t");n=positive("Grados libertad gl");a=alpha();int dir=tail();if(cancelled)return;
    r=st_t_test(t,n,a,dir);result_base("p-valor t dado",r,2,dir);
  } else if(op==8){
    x=positive("Efecto abs xbar-mu");s=positive("s formulario ref.");n=positive("n inicial/ref.");a=alpha();int dir=tail();if(cancelled)return;
    double target=st_t_inv(dir==ST_TWO?1-a/2:1-a,n-1);
    double nn=1+pow(target*s/x,2);
    resetlines();addline("n aprox efecto/crit");value("n aproximado =",nn);value("n entero =",ceil(nn));addline("Aprox: tcrit depende n");addline("Iterar/revalidar H0");
  } else if(op==9){
    static const char *choices[]={"Hallar media xbar", "Hallar media mu0", "Hallar desvio s", "Hallar tamano n"};
    int which=getchoice("DESPEJAR t",choices,4);if(which<0)return;
    t=number("Valor t dado");x=number("xbar / 0 falta");y=number("mu0 / 0 falta");s=positive("s / 1 falta");n=readnum("n / 2 falta",2,1e12);if(cancelled)return;
    resetlines();addline("t=(xbar-mu)*raiz(n-1)/s");
    if(which==0)value("xbar =",y+t*s/sqrt(n-1));
    if(which==1)value("mu0 =",x-t*s/sqrt(n-1));
    if(which==2){if(t==0 || (x-y)/t<=0){show_err();return;}value("s =",(x-y)*sqrt(n-1)/t);}
    if(which==3){if(x==y || t==0 || (x-y)/t<0){show_err();return;}double nn=1+pow(t*s/(x-y),2);value("n teorico =",nn);value("n entero =",ceil(nn));}
  } else if(op==10){
    x=positive("Varianza corr. s1^2");y=positive("Varianza corr. s2^2");n=positive("gl 1 = n1-1");s=positive("gl 2 = n2-1");a=alpha();int dir=tail();if(cancelled)return;
    r=st_f_test(x,y,n,s,a,dir);resetlines();addline("F: RAZON VARIANZAS");
    latest=r;result_family=4;result_tail=dir;auto_explain=1;
    step("F=var1_corregida/var2_corregida");
    step("gl1=n1-1, gl2=n2-1");
    stepnum("var1 =",x);stepnum("var2 =",y);
    if(!r.ok){show_err();return;}
    value("F = var1/var2 =",r.statistic);value("gl1 =",n);value("gl2 =",s);
    if(isfinite(r.crit_lo))value("Crit inf =",r.crit_lo);
    if(isfinite(r.crit_hi))value("Crit sup =",r.crit_hi);
    value("p valor =",r.p);addline(r.reject?"RECHAZAR H0":"NO RECHAZAR H0");addline("EXTRA del capitulo 11");
  }
  if(cancelled)return;if(auto_explain && !r.ok)show_err();else show_result();
}

/* Unidad 6: ji-cuadrada: ajuste, independencia y varianza. */
static void unit6(int op){
  STResult r={0};double A[ST_MAX]={0},B[ST_MAX]={0};double x,y,s,n,a,p;
  int k,rows,cols;cancelled=0;
  if(op==0 || op==1){
    k=integer("Numero de categorias",2,ST_MAX);
    if(cancelled)return;
    double tot=0;
    for(int i=0;i<k;i++){
      char b[30];snprintf(b,sizeof b,"Cat %d: observada",i+1);A[i]=readnum(b,0,1e12);
      if(cancelled)return;tot+=A[i];
      if(op==1){snprintf(b,sizeof b,"Cat %d: esperada",i+1);B[i]=positive(b);if(cancelled)return;}
    }
    if(op==0)for(int i=0;i<k;i++)B[i]=tot/k;
    int fitted=op==1?integer("Parametros estimados",0,k-2):0;
    a=alpha();if(cancelled)return;
    r=st_chi_gof(k,A,B,fitted,a);
    result_base(op==0?"JI2: uniforme":"JI2: ajuste teorico",r,3,ST_RIGHT);
    value("E min =",r.aux);value("gl =",r.df);
    step("TERM: (O-E)^2/E");
    for(int j=0;j<k&&j<35;j++){char b[50];snprintf(b,sizeof b,"%d: O=%.6g E=%.6g",j+1,A[j],B[j]);step(b);stepnum("  contrib =",(A[j]-B[j])*(A[j]-B[j])/B[j]);}
    if(r.warning)addline("Agrupar categorias E<5");
  } else if(op==2){
    k=integer("n intentos binomial",1,ST_MAX-1);
    p=fraction("Prob exito p");if(cancelled)return;
    double tot=0;
    for(int i=0;i<=k;i++){
      char b[30];snprintf(b,sizeof b,"X=%d ocurrencias",i);A[i]=readnum(b,0,1e12);
      if(cancelled)return;tot+=A[i];
    }
    a=alpha();if(cancelled)return;
    for(int i=0;i<=k;i++)B[i]=tot*st_binom_pmf(i,k,p);
    r=st_chi_gof(k+1,A,B,0,a);result_base("JI2: binomial fija",r,3,ST_RIGHT);
    value("E min =",r.aux);if(r.warning)addline("E<5: reagrupar!");
    step(op==2?"E=N*C(n,x)*p^x*q^(n-x)":"E=N*Poisson(lambda)");
    for(int j=0;j<(op==2?k+1:k) && j<30;j++){char b[50];snprintf(b,sizeof b,"X=%d: O=%.6g E=%.6g",j,A[j],B[j]);step(b);stepnum("   (O-E)^2/E =",(A[j]-B[j])*(A[j]-B[j])/B[j]);}
  } else if(op==3){
    k=integer("Numero categorias K",2,ST_MAX);
    p=positive("Lambda Poisson");if(cancelled)return;
    double tot=0,sum=0;
    for(int i=0;i<k;i++){
      char b[32];if(i==k-1)snprintf(b,sizeof b,"X>=%d: ocurrencias",i);
      else snprintf(b,sizeof b,"X=%d ocurrencias",i);
      A[i]=readnum(b,0,1e12);if(cancelled)return;tot+=A[i];
    }
    a=alpha();if(cancelled)return;
    for(int i=0;i<k-1;i++){B[i]=st_poisson_pmf(i,p);sum+=B[i];}
    B[k-1]=fmax(0,1-sum);
    for(int i=0;i<k;i++)B[i]*=tot;
    r=st_chi_gof(k,A,B,0,a);result_base("JI2: Poisson",r,3,ST_RIGHT);
    value("E min =",r.aux);if(r.warning)addline("E<5: reagrupar!");
    step(op==2?"E=N*C(n,x)*p^x*q^(n-x)":"E=N*Poisson(lambda)");
    for(int j=0;j<(op==2?k+1:k) && j<30;j++){char b[50];snprintf(b,sizeof b,"X=%d: O=%.6g E=%.6g",j,A[j],B[j]);step(b);stepnum("   (O-E)^2/E =",(A[j]-B[j])*(A[j]-B[j])/B[j]);}
  } else if(op==4||op==5){
    rows=op==5?2:integer("Numero filas",2,6);
    cols=op==5?2:integer("Numero columnas",2,6);
    if(cancelled)return;
    for(int i=0;i<rows;i++)for(int j=0;j<cols;j++){
      char b[30];snprintf(b,sizeof b,"Fila %d columna %d",i+1,j+1);
      A[i*cols+j]=readnum(b,0,1e12);if(cancelled)return;
    }
    a=alpha();if(cancelled)return;
    r=st_chi_independence(rows,cols,A,a,op==5);
    result_base(op==5?"JI2: Yates 2x2":"JI2: independencia",r,3,ST_RIGHT);
    value("Cramer V =",r.effect);value("Conting C =",r.se);value("E min =",r.aux);
    step("E=total fila*col/total");step("gl=(filas-1)*(columnas-1)");
    {double row[6]={0},col[6]={0},total=0;
     for(int ii=0;ii<rows;ii++)for(int jj=0;jj<cols;jj++){double v=A[ii*cols+jj];row[ii]+=v;col[jj]+=v;total+=v;}
     for(int ii=0;ii<rows;ii++)for(int jj=0;jj<cols;jj++){double e=row[ii]*col[jj]/total;double d=fabs(A[ii*cols+jj]-e);if(op==5)d=fmax(0,d-0.5);char b[50];snprintf(b,sizeof b,"(%d,%d): O=%.6g E=%.6g",ii+1,jj+1,A[ii*cols+jj],e);step(b);stepnum("    contrib =",d*d/e);}
    }
    if(rows==2&&cols==2){double fisher=st_fisher_2x2((int)A[0],(int)A[1],(int)A[2],(int)A[3],ST_TWO);value("Fisher p 2c =",fisher);}
    if(r.warning)addline("Frecuencias E<5:");
    if(r.warning)addline("2x2 use Fisher!");
  } else if(op==6){
    n=positive("Tamano muestra n");s=positive("s formulario (div n)");x=positive("Desvio H0 sigma0");a=alpha();int dir=tail();if(cancelled)return;
    r=st_chi_variance(n,s,x,a,dir);result_base("JI2: varianza sigma",r,3,dir);value("sigma H0 =",x);addline("Ji2=n*s^2/sigma0^2");
    step("Ji2=n*s_form^2/sigma0^2");stepnum("n =",n);stepnum("s divide n =",s);stepnum("sigma0 =",x);
  } else if(op==7){
    n=positive("Tamano muestra n");s=positive("s formulario (div n)");p=confidence();if(cancelled)return;
    r=st_chi_ci_sigma(n,s,p);resetlines();addline("IC para sigma");value("gl =",r.df);value("Ji2 inf =",r.crit_lo);value("Ji2 sup =",r.crit_hi);value("Sigma min =",r.lower);value("Sigma max =",r.upper);
  } else if(op==8){
    n=positive("Grados libertad gl");a=alpha();int dir=tail();if(cancelled)return;
    r=st_chi_test(n,n,a,dir);resetlines();addline("VALOR CRITICO JI2");
    if(isfinite(r.crit_lo))value("Lim inf =",r.crit_lo);
    if(isfinite(r.crit_hi))value("Lim sup =",r.crit_hi);
    value("gl =",n);
  } else if(op==9){
    x=readnum("Ji2 calculado",0,1e12);n=positive("Grados libertad gl");a=alpha();int dir=tail();if(cancelled)return;
    r=st_chi_test(x,n,a,dir);result_base("p-valor JI2",r,3,dir);
  } else if(op==10){
    int dir=tail();if(cancelled)return;
    int i=integer("Casilla a",0,1e5);int j=integer("Casilla b",0,1e5);
    int c=integer("Casilla c",0,1e5);int d=integer("Casilla d",0,1e5);a=alpha();if(cancelled)return;
    p=st_fisher_2x2(i,j,c,d,dir);
    resetlines();addline("FISHER EXACTA 2x2");value("p valor exacto =",p);
    addline(p<a?"RECHAZAR H0":"NO RECHAZAR H0");addline("Valido con E pequena");
  } else if(op==11){
    x=readnum("Estadistico ji2 #1",0,1e12);n=positive("Grados libertad #1");y=readnum("Estadistico ji2 #2",0,1e12);s=positive("Grados libertad #2");a=alpha();if(cancelled)return;
    r=st_chi_test(x+y,n+s,a,ST_RIGHT);result_base("SUMA: JI2 independientes",r,3,ST_RIGHT);
    addline("Solo si independientes");
  } else if(op==12){
    k=integer("n binomial ensayos",2,ST_MAX-1);if(cancelled)return;
    double sum=0,total=0;
    for(int i=0;i<=k;i++){
      char b[32];snprintf(b,sizeof b,"X=%d observadas",i);
      A[i]=readnum(b,0,1e12);if(cancelled)return;
      sum+=i*A[i];total+=A[i];
    }
    if(total<=0){show_err();return;}
    p=sum/(k*total);
    if(p<=0||p>=1){show_err();return;}
    for(int i=0;i<=k;i++)B[i]=total*st_binom_pmf(i,k,p);
    a=alpha();if(cancelled)return;
    r=st_chi_gof(k+1,A,B,1,a);
    result_base("JI2 Bin: p estimada",r,3,ST_RIGHT);
    value("p estimada =",p);value("E min =",r.aux);
    addline("gl=cat-1-1 param");
    if(r.warning)addline("Reagrupe si E<5");
  } else if(op==13){
    static const char *choices[]={"Hallar chi2", "Hallar sigma0", "Hallar s", "Hallar n"};
    int which=getchoice("DESPEJAR JI2",choices,4);if(which<0)return;
    x=positive("Ji2 / 1 si falta");y=positive("Sigma0 / 1 falta");s=positive("s formulario /1 falta");n=positive("Tamano n / 2 falta");if(cancelled)return;
    resetlines();addline("Ji2=n*s^2/sigma0^2");
    if(which==0)value("Ji2 =",n*s*s/(y*y));
    if(which==1)value("sigma0 =",s*sqrt(n/x));
    if(which==2)value("s =",y*sqrt(x/n));
    if(which==3){double nn=x*y*y/(s*s);value("n teorico =",nn);value("n entero =",ceil(nn));}
  } else if(op==14){
    x=readnum("Frecuencia observada O",0,1e9);y=readnum("Contribucion ji2",0,1e9);
    if(cancelled)return;double lo,hi;
    if(!st_inv_chi_expected(x,y,&lo,&hi)){show_err();return;}
    resetlines();addline("DESPEJAR ESPERADO E");
    step("C=(O-E)^2/E");step("E^2-(2O+C)E+O^2=0");
    step("E=O+C/2 +/- sqrt(O*C+C^2/4)");
    stepnum("O =",x);stepnum("C =",y);
    if(lo>0)value("Solucion E1 =",lo);
    if(hi>0)value("Solucion E2 =",hi);
    interpret("Verifique E con otras celdas");interpret("y el total de frecuencias.");
  } else if(op==15){
    n=integer("Intentos totales N",2,10000000);p=readnum("Prob. exito p",1e-9,0.999999999);a=alpha();
    if(cancelled)return;double lo,hi;
    if(!st_inv_chi_binomial_x(n,p,a,&lo,&hi)){show_err();return;}
    resetlines();addline("REGION ACEPTACION JI2");
    latest=st_chi_test(0,1,a,ST_RIGHT);result_family=3;result_tail=ST_RIGHT;
    step("O=(x, N-x); E=(Np,N(1-p))");
    step("Ji2=(x-Np)^2/(Np*(1-p))");
    step("|x-Np|<=sqrt(crit*Np(1-p))");
    stepnum("N =",n);stepnum("p =",p);
    value("x limite inf =",lo);value("x limite sup =",hi);
    value("x entero desde =",ceil(lo));value("x entero hasta =",floor(hi));
    interpret("Validar E>=5 en ambas clases.");
  } else if(op==16){
    x=positive("Ji2 calculado");n=readnum("Tamano n",2,1e9);s=positive("s formulario (divide n)");
    if(cancelled)return;double sigma;
    if(!st_inv_variance_sigma(x,n,s,&sigma)){show_err();return;}
    resetlines();addline("DESPEJAR SIGMA0");
    step("Ji2=n*s^2/sigma0^2");
    step("sigma0=s*sqrt(n/Ji2)");
    stepnum("Ji2 =",x);stepnum("n =",n);stepnum("s divide n =",s);
    value("sigma0 =",sigma);
    interpret("Supuesto: poblacion normal.");
  } else if(op==17){
    k=integer("Numero de categorias",2,ST_MAX);if(cancelled)return;
    for(int i=0;i<k;i++){
      char b[30];snprintf(b,sizeof b,"Cat %d observada",i+1);A[i]=readnum(b,0,1e10);
      snprintf(b,sizeof b,"Cat %d esperada",i+1);B[i]=positive(b);
      if(cancelled)return;
    }
    int fitted=integer("Parametros ajustados",0,k-2);a=alpha();if(cancelled)return;
    STResult rr=st_chi_gof(k,A,B,fitted,a);
    if(!rr.ok){show_err();return;}
    r=st_chi_test(rr.statistic,rr.df,a,ST_LEFT);r.warning=rr.warning;
    result_base("JI2: ajuste excesivo",r,3,ST_LEFT);
    step("Cola IZQUIERDA: ajuste raro");
    step("Ji2=sum((O-E)^2/E)");stepnum("chi2 observado =",r.statistic);
    for(int j=0;j<k && j<16;j++){
      char b[50];snprintf(b,sizeof b,"Cat %d: O=%.5g E=%.5g",j+1,A[j],B[j]);step(b);
    }
    interpret("Muy buen ajuste puede ser raro.");interpret("No demuestra manipulacion.");
  } else if(op==18){
    k=integer("Ensayos binomiales n",2,ST_MAX-1);p=readnum("p teorica",1e-10,0.999999999);if(cancelled)return;
    double total=0;
    for(int i=0;i<=k;i++){
      char b[30];snprintf(b,sizeof b,"X=%d ocurrencias",i);
      A[i]=readnum(b,0,1e12);if(cancelled)return;total+=A[i];
    }
    a=alpha();if(cancelled)return;
    for(int i=0;i<=k;i++)B[i]=total*st_binom_pmf(i,k,p);
    int begin[ST_MAX],end[ST_MAX],groups=0;double ob[ST_MAX],ex[ST_MAX];
    r=st_chi_merge_ordered(k+1,A,B,0,5.,a,begin,end,&groups,ob,ex);
    if(!r.ok){show_err();return;}
    result_base("JI2: bin agrupada",r,3,ST_RIGHT);
    step("Se fusionan categorias ORDENADAS");
    step("hasta cada E agrupada >= 5.");
    for(int j=0;j<groups;j++){
      char b[50];snprintf(b,sizeof b,"X:%d-%d O:%.6g E:%.6g",begin[j],end[j],ob[j],ex[j]);step(b);
      stepnum("  (O-E)^2/E =",(ob[j]-ex[j])*(ob[j]-ex[j])/ex[j]);
    }
    value("Categorias despues =",groups);
    value("gl =",r.df);
    interpret("Solo agrupar categorias con orden.");
  }
  if(cancelled)return;
  if(auto_explain && !r.ok)show_err();else show_result();
}

int main(void){
#if STAT_UNIT == 4
  static const char *title="STAT U4: NORMAL Z";
  static const char *menu[]={"Z una media", "Z una proporcion", "Z diferencia medias", "Z diferencia prop", "Criticos Z", "Despejar Z media", "n para potencia Z", "Binomial exacta", "Despejar p0 de Z", "X critico media", "n min Z (rechazo)", "Z dif con delta0"};
#elif STAT_UNIT == 5
  static const char *title="STAT U5: STUDENT";
  static const char *menu[]={"t 1 media datos", "t 1 media resumen", "t datos PAREADOS", "t 2 medias agrup.", "t Welch (var dist)", "Intervalo t media", "Criticos t", "p valor t", "n efecto (aprox)", "Despejar t", "F varianzas (extra)", "X critico t", "n min t (rechazo)", "t agrupada delta0", "t Welch delta0"};
#else
  static const char *title="STAT U6: JI-CUAD";
  static const char *menu[]={"Ajuste uniforme", "Ajuste esperados", "Ajuste binomial", "Ajuste Poisson", "Independencia R*C", "Yates 2x2", "JI2 sobre varianza", "IC para sigma", "Criticos JI2", "p valor JI2", "Fisher 2x2 exacta", "Sumar JI2", "Bin p estimada", "Despejar JI2", "Despejar esperado E", "Rango X en binomial", "Despejar sigma0", "Ajuste demasiado bueno", "Bin agrupar E<5"};
#endif
  while(1){
    int ch=getchoice(title,menu,sizeof(menu)/sizeof(menu[0]));
    if(ch<0)break;
#if STAT_UNIT == 4
    unit4(ch);
#elif STAT_UNIT == 5
    unit5(ch);
#else
    unit6(ch);
#endif
  }
  return 1;
}
