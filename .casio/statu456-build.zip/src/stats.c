#include "stats.h"
#include <math.h>
#include <float.h>

#define EPS 1e-12
static STResult invalid(void) { STResult r={0}; return r; }
static double min1(double a,double b){return a<b?a:b;}
static double max1(double a,double b){return a>b?a:b;}
static int good_alpha(double a){return a>0 && a<1;}
static double prob(double p){return fmax(0.,fmin(1.,p));}

/* Normal: erfc evita perdida de precision en las colas. */
double st_normal_cdf(double z){return 0.5*erfc(-z/M_SQRT2);}

/* Cuantil de Acklam y una iteracion Halley. */
double st_normal_inv(double p){
  static const double a[]={-3.969683028665376e+01,2.209460984245205e+02,-2.759285104469687e+02,1.383577518672690e+02,-3.066479806614716e+01,2.506628277459239e+00};
  static const double b[]={-5.447609879822406e+01,1.615858368580409e+02,-1.556989798598866e+02,6.680131188771972e+01,-1.328068155288572e+01};
  static const double c[]={-7.784894002430293e-03,-3.223964580411365e-01,-2.400758277161838e+00,-2.549732539343734e+00,4.374664141464968e+00,2.938163982698783e+00};
  static const double d[]={7.784695709041462e-03,3.224671290700398e-01,2.445134137142996e+00,3.754408661907416e+00};
  if(p<=0) return -INFINITY;
  if(p>=1) return INFINITY;
  double q,r,x;
  if(p<0.02425){q=sqrt(-2*log(p));x=(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5])/((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);}
  else if(p>1-0.02425){q=sqrt(-2*log(1-p));x=-(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5])/((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);}
  else{q=p-0.5;r=q*q;x=(((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q/(((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1);}
  if(p>1e-14 && p<1-1e-14){ double e=st_normal_cdf(x)-p;double u=e*sqrt(2*M_PI)*exp(x*x/2);x-=u/(1+x*u/2); }
  return x;
}

/* Incomplete beta continued fraction (Numerical Recipes form). */
static double betacf(double a,double b,double x){
  const double tiny=1e-290; double c=1,d=1-(a+b)*x/(a+1);
  if(fabs(d)<tiny)d=tiny;d=1/d;double h=d;
  for(int m=1;m<=260;m++){
    int m2=2*m;double aa=m*(b-m)*x/((a+m2-1)*(a+m2));
    d=1+aa*d;if(fabs(d)<tiny)d=tiny;
    c=1+aa/c;if(fabs(c)<tiny)c=tiny;d=1/d;h*=d*c;
    aa=-(a+m)*(a+b+m)*x/((a+m2)*(a+m2+1));
    d=1+aa*d;if(fabs(d)<tiny)d=tiny;
    c=1+aa/c;if(fabs(c)<tiny)c=tiny;d=1/d;
    double del=d*c;h*=del;if(fabs(del-1)<2e-14)break;
  }
  return h;
}
static double ibeta(double a,double b,double x){
  if(x<=0)return 0;if(x>=1)return 1;
  double pref=exp(lgamma(a+b)-lgamma(a)-lgamma(b)+a*log(x)+b*log1p(-x));
  if(x<(a+1)/(a+b+2))return prob(pref*betacf(a,b,x)/a);
  return prob(1-pref*betacf(b,a,1-x)/b);
}
double st_t_cdf(double t,double df){
  if(!(df>0))return NAN;
  if(t==0)return 0.5;
  double u=ibeta(df/2,0.5,df/(df+t*t))*0.5;
  return t<0?u:1-u;
}
double st_t_inv(double p,double df){
  if(!(df>0)||p<0||p>1)return NAN;
  if(p==0)return -INFINITY;if(p==1)return INFINITY;
  if(p==0.5)return 0;
  if(p<0.5)return -st_t_inv(1-p,df);
  double lo=0,hi=max1(1,st_normal_inv(p));
  while(st_t_cdf(hi,df)<p && hi<1e12)hi*=2;
  for(int i=0;i<105;i++){double mid=(lo+hi)/2;if(st_t_cdf(mid,df)<p)lo=mid;else hi=mid;}
  return (lo+hi)/2;
}

/* Complemento gamma Q(a,x) estable en cola alta. */
static double gamma_q(double a,double x){
  if(x<=0)return 1;
  if(x<a+1){
    double ap=a,sum=1/a,del=sum;
    for(int k=1;k<1500;k++){ap++;del*=x/ap;sum+=del;if(fabs(del)<fabs(sum)*2e-15)break;}
    return prob(1-sum*exp(-x+a*log(x)-lgamma(a)));
  }
  double b=x+1-a,c=1e300,d=1/(fabs(b)<1e-290?1e-290:b),h=d;
  for(int i=1;i<1500;i++){
    double an=-i*(i-a);b+=2;d=an*d+b;
    if(fabs(d)<1e-290)d=1e-290;
    c=b+an/c;if(fabs(c)<1e-290)c=1e-290;
    d=1/d;double del=d*c;h*=del;if(fabs(del-1)<2e-15)break;
  }
  return prob(exp(-x+a*log(x)-lgamma(a))*h);
}
double st_chi_cdf(double x,double df){if(df<=0)return NAN; if(x<=0)return 0;return 1-gamma_q(df/2,x/2);}
double st_chi_inv(double p,double df){
  if(!(df>0)||p<0||p>1)return NAN;
  if(p==0)return 0;if(p==1)return INFINITY;
  double lo=0,hi=max1(1,df);
  while(st_chi_cdf(hi,df)<p && hi<1e15)hi*=2;
  for(int i=0;i<110;i++){double m=(lo+hi)/2;if(st_chi_cdf(m,df)<p)lo=m;else hi=m;}
  return (hi+lo)/2;
}

double st_binom_pmf(int k,int n,double p){
  if(n<0 || k<0 || k>n || p<0 || p>1)return 0;
  if(p==0)return k==0;if(p==1)return k==n;
  return exp(lgamma(n+1)-lgamma(k+1)-lgamma(n-k+1)+k*log(p)+(n-k)*log1p(-p));
}
double st_poisson_pmf(int k,double lam){
  if(k<0||lam<0)return 0;if(lam==0)return k==0;
  return exp(-lam+k*log(lam)-lgamma(k+1));
}
double st_mean(const double *v,int n){if(n<1)return NAN;double s=0;for(int i=0;i<n;i++)s+=v[i];return s/n;}
double st_sd_pop(const double *v,int n){if(n<2)return NAN;double mu=st_mean(v,n),s=0;for(int i=0;i<n;i++)s+=(v[i]-mu)*(v[i]-mu);return sqrt(s/n);}
static STResult finalized(double stat,double df,double p,double cl,double ch,double alpha,double effect,double se){
  STResult r={0};r.ok=1;r.statistic=stat;r.df=df;r.p=prob(p);r.crit_lo=cl;r.crit_hi=ch;r.effect=effect;r.se=se;
  r.reject=r.p<alpha;
  return r;
}
STResult st_z_test(double z,double alpha,int tail){
  if(!good_alpha(alpha)||!isfinite(z)||tail < -1||tail>1)return invalid();
  double p,lo=-INFINITY,hi=INFINITY;
  if(tail==ST_RIGHT){p=st_normal_cdf(-z);hi=st_normal_inv(1-alpha);}
  else if(tail==ST_LEFT){p=st_normal_cdf(z);lo=st_normal_inv(alpha);}
  else{p=2*st_normal_cdf(-fabs(z));lo=st_normal_inv(alpha/2);hi=-lo;}
  return finalized(z,INFINITY,p,lo,hi,alpha,0,0);
}
STResult st_t_test(double t,double df,double alpha,int tail){
  if(!(df>0)||!good_alpha(alpha)||!isfinite(t)||tail < -1||tail>1)return invalid();
  double p,lo=-INFINITY,hi=INFINITY;
  if(tail==ST_RIGHT){p=st_t_cdf(-t,df);hi=st_t_inv(1-alpha,df);}
  else if(tail==ST_LEFT){p=st_t_cdf(t,df);lo=st_t_inv(alpha,df);}
  else {p=2*st_t_cdf(-fabs(t),df);lo=st_t_inv(alpha/2,df);hi=-lo;}
  return finalized(t,df,p,lo,hi,alpha,0,0);
}
STResult st_chi_test(double chi,double df,double alpha,int tail){
  if(!(df>0)||!good_alpha(alpha)||!(chi>=0)||tail< -1||tail>1)return invalid();
  double p,lo=-INFINITY,hi=INFINITY;
  double cdf=st_chi_cdf(chi,df),sf=gamma_q(df/2,chi/2);
  if(tail==ST_RIGHT){p=sf;hi=st_chi_inv(1-alpha,df);}
  else if(tail==ST_LEFT){p=cdf;lo=st_chi_inv(alpha,df);}
  else {p=2*min1(cdf,sf);lo=st_chi_inv(alpha/2,df);hi=st_chi_inv(1-alpha/2,df);}
  return finalized(chi,df,p,lo,hi,alpha,0,0);
}
STResult st_z_mean(double x,double mu,double sigma,double n,double alpha,int tail){
  if(!(n>0)||!(sigma>0))return invalid();
  double se=sigma/sqrt(n);STResult r=st_z_test((x-mu)/se,alpha,tail);r.effect=x-mu;r.se=se;return r;
}
double st_f_cdf(double f,double df1,double df2){
  if(!(df1>0 && df2>0))return NAN;
  if(f<=0)return 0;
  return ibeta(df1/2,df2/2,df1*f/(df1*f+df2));
}
double st_f_inv(double p,double df1,double df2){
  if(!(df1>0 && df2>0)||p<0||p>1)return NAN;
  if(p==0)return 0;if(p==1)return INFINITY;
  double lo=0,hi=1;
  while(st_f_cdf(hi,df1,df2)<p && hi<1e14)hi*=2;
  for(int k=0;k<100;k++){double m=(lo+hi)/2;
    if(st_f_cdf(m,df1,df2)<p)lo=m;else hi=m;
  }
  return (lo+hi)/2;
}
STResult st_f_test(double var1,double var2,double df1,double df2,double alpha,int tail){
  if(!(var1>0 && var2>0 && df1>0 && df2>0) || !good_alpha(alpha))return invalid();
  double f=var1/var2,cdf=st_f_cdf(f,df1,df2),p,lo=-INFINITY,hi=INFINITY;
  if(tail==ST_RIGHT){p=1-cdf;hi=st_f_inv(1-alpha,df1,df2);}
  else if(tail==ST_LEFT){p=cdf;lo=st_f_inv(alpha,df1,df2);}
  else if(tail==ST_TWO){p=2*min1(cdf,1-cdf);lo=st_f_inv(alpha/2,df1,df2);hi=st_f_inv(1-alpha/2,df1,df2);}
  else return invalid();
  STResult r=finalized(f,df1,p,lo,hi,alpha,var1,var2);r.aux=df2;return r;
}
STResult st_binom_exact(int successes,int n,double p0,double alpha,int tail){
  if(n<1||n>5000||successes<0||successes>n||p0<0||p0>1||!good_alpha(alpha))return invalid();
  double mass=st_binom_pmf(successes,n,p0),sum=0;
  for(int k=0;k<=n;k++){
    double m=st_binom_pmf(k,n,p0);
    if(tail==ST_LEFT && k<=successes)sum+=m;
    else if(tail==ST_RIGHT && k>=successes)sum+=m;
    else if(tail==ST_TWO && m<=mass*(1+1e-9))sum+=m;
  }
  STResult r=finalized((double)successes/n,n,prob(sum),-INFINITY,INFINITY,alpha,((double)successes/n)-p0,0);
  r.aux=p0;
  return r;
}
STResult st_z_prop(double successes,double n,double p0,double alpha,int tail){
  if(!(n>0)||successes<0||successes>n||fabs(successes-round(successes))>1e-9||p0<=0||p0>=1)return invalid();
  double ph=successes/n,se=sqrt(p0*(1-p0)/n);STResult r=st_z_test((ph-p0)/se,alpha,tail);
  r.effect=ph-p0;r.se=se;r.aux=ph;if(n*p0<5||n*(1-p0)<5)r.warning=1;return r;
}
STResult st_z_means(double a,double b,double sa,double sb,double na,double nb,double alpha,int tail){
  if(!(sa>=0&&sb>=0&&na>1&&nb>1))return invalid();double se=hypot(sa/sqrt(na),sb/sqrt(nb));if(se<=0)return invalid();
  STResult r=st_z_test((a-b)/se,alpha,tail);r.effect=a-b;r.se=se;return r;
}
STResult st_z_props(double x1,double n1,double x2,double n2,double alpha,int tail){
  if(n1<=0||n2<=0||x1<0||x2<0||x1>n1||x2>n2||fabs(x1-round(x1))>1e-9||fabs(x2-round(x2))>1e-9)return invalid();
  double ph1=x1/n1,ph2=x2/n2,p=(x1+x2)/(n1+n2);
  if(p<=0||p>=1)return invalid();double se=sqrt(p*(1-p)*(1/n1+1/n2));
  STResult r=st_z_test((ph1-ph2)/se,alpha,tail);r.effect=ph1-ph2;r.se=se;r.aux=p;
  if(min1(n1*p,n2*p)<5||min1(n1*(1-p),n2*(1-p))<5)r.warning=1;return r;
}
STResult st_t_mean(double x,double mu,double s_pop,double n,double alpha,int tail){
  if(!(n>1)||!(s_pop>0))return invalid();double se=s_pop/sqrt(n-1);
  STResult r=st_t_test((x-mu)/se,n-1,alpha,tail);r.effect=x-mu;r.se=se;return r;
}
STResult st_t_pooled(double x1,double x2,double s1_pop,double s2_pop,double n1,double n2,double alpha,int tail){
  if(n1<=1||n2<=1||s1_pop<0||s2_pop<0)return invalid();
  double df=n1+n2-2,sp=sqrt((n1*s1_pop*s1_pop+n2*s2_pop*s2_pop)/df);
  double se=sp*sqrt(1/n1+1/n2);if(!(se>0))return invalid();
  STResult r=st_t_test((x1-x2)/se,df,alpha,tail);r.effect=x1-x2;r.se=se;r.aux=sp;return r;
}
STResult st_t_welch(double x1,double x2,double s1_corr,double s2_corr,double n1,double n2,double alpha,int tail){
  if(n1<=1||n2<=1||s1_corr<0||s2_corr<0)return invalid();
  double a=s1_corr*s1_corr/n1,b=s2_corr*s2_corr/n2,se=sqrt(a+b);
  if(se<=0)return invalid();double df=(a+b)*(a+b)/(a*a/(n1-1)+b*b/(n2-1));
  STResult r=st_t_test((x1-x2)/se,df,alpha,tail);r.effect=x1-x2;r.se=se;return r;
}
STResult st_chi_gof(int k,const double *obs,const double *expv,int fitted,double alpha){
  if(k<2||k>ST_MAX||fitted<0||fitted>=k-1)return invalid();
  double ch=0,no=0,ne=0,mine=INFINITY;
  for(int i=0;i<k;i++){
    if(obs[i]<0||expv[i]<=0)return invalid();
    no+=obs[i];ne+=expv[i];mine=min1(mine,expv[i]);ch+=(obs[i]-expv[i])*(obs[i]-expv[i])/expv[i];
  }
  if(fabs(no-ne)>1e-6*max1(1,no))return invalid();
  STResult r=st_chi_test(ch,k-1-fitted,alpha,ST_RIGHT);r.aux=mine;r.warning=mine<5;return r;
}
STResult st_chi_independence(int rows,int cols,const double *obs,double alpha,int yates){
  if(rows<2||cols<2||rows*cols>ST_MAX)return invalid();
  double row[ST_MAX]={0},col[ST_MAX]={0},total=0,ch=0,mine=INFINITY;
  for(int i=0;i<rows;i++)for(int j=0;j<cols;j++){
    double v=obs[i*cols+j];if(v<0)return invalid();row[i]+=v;col[j]+=v;total+=v;
  }
  if(total<=0)return invalid();
  for(int i=0;i<rows;i++)for(int j=0;j<cols;j++){
    double e=row[i]*col[j]/total;if(e<=0)return invalid();
    mine=min1(mine,e);double d=fabs(obs[i*cols+j]-e);
    if(yates&&rows==2&&cols==2)d=max1(0,d-0.5);
    ch+=d*d/e;
  }
  STResult r=st_chi_test(ch,(rows-1)*(cols-1),alpha,ST_RIGHT);
  r.effect=sqrt(ch/(total*min1(rows-1,cols-1))); /* Cramer V */
  r.se=sqrt(ch/(ch+total)); /* coeficiente contingencia */
  r.aux=mine;r.warning=mine<5;return r;
}
STResult st_chi_variance(double n,double s_pop,double sig0,double alpha,int tail){
  if(n<=1||s_pop<0||sig0<=0)return invalid();
  double chi=n*s_pop*s_pop/(sig0*sig0);
  STResult r=st_chi_test(chi,n-1,alpha,tail);r.effect=s_pop;r.se=sig0;return r;
}
STResult st_t_ci(double xbar,double s_pop,double n,double confidence){
  if(n<=1||s_pop<0||!good_alpha(confidence))return invalid();
  double crit=st_t_inv((1+confidence)/2,n-1),margin=crit*s_pop/sqrt(n-1);
  STResult r={0};r.ok=1;r.df=n-1;r.crit_hi=crit;r.effect=xbar;r.se=margin;r.lower=xbar-margin;r.upper=xbar+margin;return r;
}
STResult st_chi_ci_sigma(double n,double s_pop,double confidence){
  if(n<=1||s_pop<=0||!good_alpha(confidence))return invalid();
  double qlo=st_chi_inv((1-confidence)/2,n-1),qhi=st_chi_inv((1+confidence)/2,n-1);
  STResult r={0};r.ok=1;r.df=n-1;r.statistic=n*s_pop*s_pop;r.crit_lo=qlo;r.crit_hi=qhi;
  r.lower=sqrt(r.statistic/qhi);r.upper=sqrt(r.statistic/qlo);return r;
}
static double hyper_prob(int a,int r1,int c1,int n){
  int c2=n-c1;
  if(a<0||a>c1||r1-a<0||r1-a>c2)return 0;
  return exp(lgamma(c1+1)-lgamma(a+1)-lgamma(c1-a+1)+lgamma(c2+1)-lgamma(r1-a+1)-lgamma(c2-r1+a+1)-lgamma(n+1)+lgamma(r1+1)+lgamma(n-r1+1));
}
double st_fisher_2x2(int a,int b,int c,int d,int tail){
  if(a<0||b<0||c<0||d<0)return NAN;
  int r1=a+b,c1=a+c,n=a+b+c+d,lo=(r1-(n-c1)>0)?r1-(n-c1):0,hi=(r1<c1?r1:c1);
  double observed=hyper_prob(a,r1,c1,n),s=0;
  for(int x=lo;x<=hi;x++){
    double v=hyper_prob(x,r1,c1,n);
    if(tail==ST_LEFT && x<=a)s+=v;
    if(tail==ST_RIGHT && x>=a)s+=v;
    if(tail==ST_TWO && v<=observed*(1+1e-9))s+=v;
  }
  return prob(s);
}

/* Las hipotesis de diferencias no nulas requieren restar delta0 del numerador. */
STResult st_z_means_delta(double x1,double x2,double sig1,double sig2,double n1,double n2,double delta0,double alpha,int tail){
  if(n1<=1||n2<=1||sig1<0||sig2<0)return invalid();
  double se=hypot(sig1/sqrt(n1),sig2/sqrt(n2));if(se<=0)return invalid();
  STResult r=st_z_test((x1-x2-delta0)/se,alpha,tail);
  r.effect=x1-x2-delta0;r.se=se;r.aux=x1-x2;return r;
}
STResult st_t_pooled_delta(double x1,double x2,double s1,double s2,double n1,double n2,double delta0,double alpha,int tail){
  if(n1<=1||n2<=1||s1<0||s2<0)return invalid();
  double df=n1+n2-2,sp=sqrt((n1*s1*s1+n2*s2*s2)/df);
  double se=sp*sqrt(1/n1+1/n2);if(se<=0)return invalid();
  STResult r=st_t_test((x1-x2-delta0)/se,df,alpha,tail);
  r.effect=x1-x2-delta0;r.se=se;r.aux=sp;return r;
}
STResult st_t_welch_delta(double x1,double x2,double s1,double s2,double n1,double n2,double delta0,double alpha,int tail){
  if(n1<=1||n2<=1||s1<0||s2<0)return invalid();
  double a=s1*s1/n1,b=s2*s2/n2,se=sqrt(a+b);
  if(se<=0)return invalid();
  double df=(a+b)*(a+b)/(a*a/(n1-1)+b*b/(n2-1));
  STResult r=st_t_test((x1-x2-delta0)/se,df,alpha,tail);
  r.effect=x1-x2-delta0;r.se=se;r.aux=x1-x2;return r;
}
/* Solo para categorias con orden natural (0,1,2,...). No reagrupar nominales. */
STResult st_chi_merge_ordered(int k,const double *obs,const double *expv,int fitted,double threshold,double alpha,int *start,int *end,int *g,double *group_o,double *group_e){
  if(k<2||k>ST_MAX||fitted<0||fitted>=k-1||threshold<=0||!start||!end||!g||!group_o||!group_e)return invalid();
  double total_o=0,total_e=0;
  for(int i=0;i<k;i++){
    if(!isfinite(obs[i])||!isfinite(expv[i])||obs[i]<0||expv[i]<=0)return invalid();
    total_o+=obs[i];total_e+=expv[i];
  }
  if(fabs(total_o-total_e)>1e-6*fmax(1,total_o))return invalid();
  int ng=0;
  double acc_o=0,acc_e=0;
  int begin=0;
  for(int i=0;i<k;i++){
    acc_o+=obs[i];acc_e+=expv[i];
    if(acc_e>=threshold){
      start[ng]=begin;end[ng]=i;group_o[ng]=acc_o;group_e[ng]=acc_e;ng++;
      begin=i+1;acc_o=0;acc_e=0;
    }
  }
  if(acc_e>0 && ng>0){
    end[ng-1]=k-1;group_o[ng-1]+=acc_o;group_e[ng-1]+=acc_e;
  }
  if(ng<2||ng<=fitted+1)return invalid();
  *g=ng;
  return st_chi_gof(ng,group_o,group_e,fitted,alpha);
}
