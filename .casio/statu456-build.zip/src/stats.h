#ifndef STAT456_STATS_H
#define STAT456_STATS_H

/* STAT U456 - motor numerico portatil. Sin dependencia de gint. */
#define ST_MAX 48
#define ST_RIGHT 1
#define ST_LEFT -1
#define ST_TWO 0

typedef struct {
  int ok;
  double statistic, df, p, crit_lo, crit_hi;
  double effect, se, aux, lower, upper;
  int reject, warning;
} STResult;

double st_normal_cdf(double z);
double st_normal_inv(double p);
double st_t_cdf(double t, double df);
double st_t_inv(double p, double df);
double st_chi_cdf(double x, double df);
double st_chi_inv(double p, double df);
double st_binom_pmf(int k, int n, double p);
double st_poisson_pmf(int k, double lam);
double st_mean(double const *v, int n);
double st_sd_pop(double const *v, int n);
STResult st_z_test(double z, double alpha, int tail);
STResult st_t_test(double t, double df, double alpha, int tail);
STResult st_chi_test(double chi, double df, double alpha, int tail);
STResult st_z_mean(double x, double mu, double sigma, double n, double alpha, int tail);
STResult st_binom_exact(int successes,int n,double p0,double alpha,int tail);
STResult st_z_prop(double successes, double n, double p0, double alpha, int tail);
STResult st_z_means(double a, double b, double sa, double sb, double na, double nb, double alpha, int tail);
STResult st_z_props(double x1,double n1,double x2,double n2,double alpha,int tail);
double st_f_cdf(double f,double df1,double df2);
double st_f_inv(double p,double df1,double df2);
STResult st_f_test(double var1,double var2,double df1,double df2,double alpha,int tail);
STResult st_t_mean(double x, double mu, double s_pop, double n, double alpha, int tail);
STResult st_t_pooled(double x1,double x2,double s1_pop,double s2_pop,double n1,double n2,double alpha,int tail);
STResult st_t_welch(double x1,double x2,double s1_corr,double s2_corr,double n1,double n2,double alpha,int tail);
STResult st_chi_gof(int k, const double *observed, const double *expected, int fitted, double alpha);
STResult st_chi_independence(int r,int c,const double *table,double alpha,int yates);
STResult st_chi_variance(double n,double s_pop,double sig0,double alpha,int tail);
STResult st_t_ci(double xbar,double s_pop,double n,double confidence);
STResult st_chi_ci_sigma(double n,double s_pop,double confidence);
double st_fisher_2x2(int a,int b,int c,int d,int tail);
STResult st_z_means_delta(double x1,double x2,double sigma1,double sigma2,double n1,double n2,double delta0,double alpha,int tail);
STResult st_t_pooled_delta(double x1,double x2,double s1_spiegel,double s2_spiegel,double n1,double n2,double delta0,double alpha,int tail);
STResult st_t_welch_delta(double x1,double x2,double s1_corrected,double s2_corrected,double n1,double n2,double delta0,double alpha,int tail);
STResult st_chi_merge_ordered(int k,const double *observed,const double *expected,int fitted,double min_expected,double alpha,int *group_start,int *group_end,int *num_groups,double *group_o,double *group_e);
#endif

