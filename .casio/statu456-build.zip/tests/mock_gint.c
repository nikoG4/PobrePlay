#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mock_gint/gint/display.h"
#include "mock_gint/gint/keyboard.h"

static int steps=0;
void dclear(int c){(void)c;}
void drect(int a,int b,int c,int d,int co){(void)a;(void)b;(void)c;(void)d;(void)co;}
void dline(int a,int b,int c,int d,int co){(void)a;(void)b;(void)c;(void)d;(void)co;}
void dtext(int x,int y,int color,char const *txt){(void)x;(void)color;if(y!=0&&txt&&txt[0])fprintf(stderr,"%s\n",txt);}
void dupdate(void){ }
mock_event getkey(void){
  if(steps++>1000)abort();
  int c=getchar();
  int key=KEY_EXIT;
  if(c>='0'&&c<='9')key=KEY_0+(c-'0');
  else switch(c){
   case 'e':key=KEY_EXE;break;
   case 'x':key=KEY_EXIT;break;
   case 'u':key=KEY_UP;break;
   case 'd':key=KEY_DOWN;break;
   case 'f':key=KEY_F1;break;
   case 'g':key=KEY_F2;break;
   case 'h':key=KEY_F3;break;
   case '.':key=KEY_DOT;break;
   case '-':key=KEY_NEG;break;
   case 'D':key=KEY_DEL;break;
   case 'E':key=KEY_EXP;break;
  }
  mock_event k={key};return k;
}
