#ifndef MOCK_DISPLAY_H
#define MOCK_DISPLAY_H
#define C_WHITE 0
#define C_BLACK 1
void dclear(int c);
void drect(int a,int b,int c,int d,int color);
void dline(int a,int b,int c,int d,int color);
void dtext(int x,int y,int color,char const *txt);
void dupdate(void);
#endif
