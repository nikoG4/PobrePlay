#ifndef MOCK_KEYBOARD_H
#define MOCK_KEYBOARD_H
enum {KEY_0=10,KEY_1,KEY_2,KEY_3,KEY_4,KEY_5,KEY_6,KEY_7,KEY_8,KEY_9,
KEY_NEG,KEY_DOT,KEY_EXP,KEY_EXE,KEY_EXIT,KEY_UP,KEY_DOWN,KEY_DEL,KEY_F1,KEY_F2,KEY_F3,KEY_F4};
typedef struct {int key;} mock_event;
mock_event getkey(void);
#endif
