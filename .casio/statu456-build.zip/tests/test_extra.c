#include "../src/stats.h"
#include "../src/inverse.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
static int tests=0;
static void eq(char *tag,double got,double ex,double eps){
 if(!isfinite(got)||fabs(got-ex)>eps){fprintf(stderr,"ERR %s got %.11g want %.11g\n",tag,got,ex);exit(1);} tests++;
}
int main(){
 /* Cambio sobre diferencia nula; H0: diferencia=4 (no 0). */
 STResult r=st_z_means_delta(105,98,12,10,65,70,4,.05,ST_RIGHT);
 eq("Z delta no 0",r.statistic,(7-4)/hypot(12/sqrt(65.),10/sqrt(70.)),1e-10);
 eq("Z is right tail",r.p,st_normal_cdf(-r.statistic),1e-10);
 r=st_t_pooled_delta(22.6,21.4,.48,.54,5,5,.4,.05,ST_RIGHT);
 double sp=sqrt((5*.48*.48+5*.54*.54)/8);
 eq("t pooled nonzero",r.statistic,(1.2-.4)/(sp*sqrt(2./5)),1e-12);
 eq("pooled df",r.df,8,0);
 r=st_t_welch_delta(81,76,12,19,11,9,2,.05,ST_RIGHT);
 double v1=144./11,v2=361./9;
 eq("Welch delta",r.statistic,3./sqrt(v1+v2),1e-12);
 eq("Welch df",r.df,(v1+v2)*(v1+v2)/(v1*v1/10+v2*v2/8),1e-10);
 /* Frecuencias binomiales raras en los extremos, reagrupamiento */
 double obs[]={1,4,11,17,10,6,1},ex[7];for(int j=0;j<7;j++)ex[j]=50*st_binom_pmf(j,6,.5);
 double o[ST_MAX]={0},e[ST_MAX]={0};int first[ST_MAX],last[ST_MAX],g=0;
 r=st_chi_merge_ordered(7,obs,ex,0,5,.05,first,last,&g,o,e);
 eq("grouped valid",r.ok,1,0);eq("merged category count",g,5,0);
 eq("merged first low",first[0],0,0);eq("merged first high",last[0],1,0);
 eq("merged last low",first[4],5,0);eq("merged last high",last[4],6,0);
 eq("merged expected total",e[0]+e[1]+e[2]+e[3]+e[4],50,1e-8);
 eq("merged degrees",r.df,4,0);
 /* Too good: zero deviation => probability left P(chi<=0)=0 */
 r=st_chi_test(0,4,.05,ST_LEFT);eq("too good lower tail",r.p,0,0);
 /* Libro 12.25: propiedad aditiva */
 r=st_chi_test(2.37+2.86+3.54,3,.05,ST_RIGHT);
 eq("additive chi",r.statistic,8.77,1e-12);eq("combined reject",r.reject,1,0);
 /* Perfil n minimo t, verifica anterior no cumple */
 int n; if(!st_inv_min_n_t(2.,1.,.05,ST_TWO,&n))exit(2);
 eq("min n t",n,18,0);
 eq("n prior not reject",1.*sqrt((double)n-1)/2 < st_t_inv(.975,n-2),1,0);
 /* Asegurar rechazo con el n calculado */
 eq("n sufficient",1.*sqrt((double)n)/2>=st_t_inv(.975,n-1),1,0);
 printf("%d extra tests PASS\n",tests);return 0;
}
