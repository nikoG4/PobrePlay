import subprocess, pathlib, re, math
root=pathlib.Path(__file__).resolve().parents[1]
for unit in (4,5,6):
    subprocess.run(['gcc','-std=gnu11','-Os','-DSTAT_UNIT='+str(unit),'-I'+str(root/'tests/mock_gint'),'-I'+str(root/'src'),str(root/'src/main.c'),str(root/'src/stats.c'),str(root/'src/inverse.c'),str(root/'tests/mock_capture.c'),'-lm','-o',f'/tmp/statgui_{unit}'],check=True)
def check(unit,menu_num,inputs,want,maxpages=150,more='',tail_select=False):
    commands='d'*menu_num+'e'
    for entry in inputs:
        if isinstance(entry,int) and entry<0:commands+='d'*(-entry)+'e' # unused
        else:commands+=str(entry)+'e'
    commands+=('e' if tail_select else '')+'g'*maxpages + more + 'x' * 3
    # Each entry in a getchoice requires `d` for menu selection, not number input.
    try:
        p=subprocess.run([f'/tmp/statgui_{unit}'],input=commands,text=True,capture_output=True,timeout=8)
    except subprocess.TimeoutExpired:raise AssertionError(f'timeout {unit} {menu_num}')
    if p.returncode not in (0,1):raise AssertionError(f'program {unit} menu{menu_num} returned {p.returncode}: {p.stderr[-200:]}')
    text=p.stdout
    for phrase in want:
        if phrase not in text:
            pathlib.Path('/tmp/fail_gui_'+str(unit)+'.txt').write_text(text)
            raise AssertionError(f'{unit}/{menu_num} missing {phrase}; frames={text.count("@@FRAME")} tail={text[-850:]}')
    print(f'UNIT{unit} menu{menu_num} OK - '+', '.join(want))
# to choose tails: default right; inputs to exact region same
check(4,13,[50,0.4,0.05],['REGION','ERROR TIPO I REAL'],40,tail_select=True)
check(5,16,[90,50,40,60,10,15,0.05],['DATOS DEL ENUNCIADO','NORMALIZAR'],60,tail_select=True)
check(5,17,[5,0.28,0.30,0.27,0.33,0.31,0.95],['CALCULAR MEDIA','INTERVALO FINAL'],60)
check(6,20,[5,22,0.12,34,0.18,66,0.4,16,0.18,12,0.12,0,0.05],['RECONOCER ENUNCIADO','SUMAR APORTES'],80)
check(6,21,[5,8.3,4,9.1,4,8.9,4,7.8,4,8.6,4,0.05],['REQUISITO PREVIO','COMBINAR RESULTADOS'],100)
check(6,22,[37,23,0.5,0.05],['DOS CATEGORIAS','CORRECCION'],60)

# Smoke de F4 sobre tabla 2x2 y ajuste desde probabilidades.
from subprocess import run
def inspect(unit,menu,vals,expected):
    src='d'*menu+'e'+''.join(str(v)+'e' for v in vals)+'j'+'h'+'x'+'x'+'x'
    proc=run([f'/tmp/statgui_{unit}'],input=src,text=True,capture_output=True,timeout=8)
    assert all(v in proc.stdout for v in expected),(expected,proc.stdout[-2000:])
    print(f'F4 UNIT{unit} menu{menu}: OK')
inspect(6,5,[2,2,49,25,30,96,0.05],['CELDA 1/4','CALCULO ESPERADO','Aporte ='])
inspect(6,20,[2,37,0.5,23,0.5,0,0.05],['CATEGORIA 1/2','Aporte Ji2'])
