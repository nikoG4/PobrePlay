#include "../src/inverse.h"
#include "../src/stats.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
static int count=0;
static void test(const char *label,double got,double exp,double eps){
 if(!isfinite(got)||fabs(got-exp)>eps){fprintf(stderr,"FAIL %s %.12g != %.12g\n",label,got,exp);exit(1);}count++;
}
int main(void){
 double p,lo,hi,v;int n;
 if(!st_inv_z_p0(.68,-.97590007295,500,&p))abort();test("inverse p0 Z Guia 13",p,.7,1e-8);
 if(!st_inv_z_p0(.8,2.5,100,&p))abort();test("reverse sign Z",(.8-p)/sqrt(p*(1-p)/100),2.5,1e-8);
 if(st_inv_z_p0(.8,2.5,0,&p))abort();
 if(!st_inv_chi_expected(20,5,&lo,&hi))abort();
 test("inverse chi E low",(20-lo)*(20-lo)/lo,5,1e-8);
 test("inverse chi E high",(20-hi)*(20-hi)/hi,5,1e-8);
 if(!st_inv_chi_binomial_x(200,.6,.05,&lo,&hi))abort();
 double crit=st_chi_inv(.95,1);
 test("inverse bin low",(lo-120)*(lo-120)/(200*.6*.4),crit,1e-7);
 test("inverse bin high",(hi-120)*(hi-120)/(200*.6*.4),crit,1e-7);
 if(!st_inv_critical_z_mean(1120,125,8,.05,ST_TWO,&lo,&hi))abort();
 test("critical Z mean low",lo,1120-st_normal_inv(.975)*125/sqrt(8),1e-8);
 test("critical Z mean high",hi,1120+st_normal_inv(.975)*125/sqrt(8),1e-8);
 if(!st_inv_critical_t_mean(23.2,.24,10,.01,ST_RIGHT,&lo,&hi))abort();
 test("critical t mean",hi,23.2+st_t_inv(.99,9)*.24/3,1e-8);
 if(!st_inv_min_n_z(125,50,.05,ST_TWO,&n))abort();
 test("min n z",n,25,0);
 if(!st_inv_min_n_t(2,1,.05,ST_TWO,&n))abort();
 test("min n t rejection",n,18,0); /* actual checked with CDF below */
 if(!st_inv_variance_sigma(22.5,10,3,&v))abort();test("inverse sigma0",v,2,1e-12);
 printf("%d inverse checks PASS\n",count);return 0;
}
