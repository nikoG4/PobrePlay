#include "../src/stats.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
static int okcount=0;
static void eq(const char *name,double actual,double expected,double tolerance){
 if(!isfinite(actual)||fabs(actual-expected)>tolerance){
  fprintf(stderr,"FAIL %-24s obtained %.12g expected %.12g tol %g\n",name,actual,expected,tolerance);
  exit(1);
 }
 ++okcount;printf("OK   %-24s %.9g\n",name,actual);
}
int main(void){
 eq("normal inv .975",st_normal_inv(.975),1.95996398454,1e-8);
 eq("normal cdf 2",st_normal_cdf(2),.977249868052,1e-9);
 eq("t crit df=9 .975",st_t_inv(.975,9),2.26215716,1e-6);
 eq("t crit df=7 .99",st_t_inv(.99,7),2.99795157,1e-6);
 eq("chi crit df2 95%",st_chi_inv(.95,2),5.99146455,1e-6);
 eq("chi crit df4 95%",st_chi_inv(.95,4),9.48772904,1e-6);
 eq("chi crit df2 99%",st_chi_inv(.99,2),9.21034037,1e-6);
 eq("bin pmf n2 x1",st_binom_pmf(1,2,2./3),4./9,1e-12);
 eq("poi pmf x3 lambda2",st_poisson_pmf(3,2),0.180447044,1e-8);
 /* Guia 11 */
 double water[]={1.5,1.6,1.5,1.4,1.9,1.4,1.3,1.9,1.8,1.7};
 STResult r=st_t_mean(st_mean(water,10),1.4,st_sd_pop(water,10),10,.01,ST_RIGHT);
 eq("Guia11 agua t",r.statistic,2.928,0.006);
 eq("Guia11 agua gl",r.df,9,0);
 eq("Guia11 agua rechaza",r.reject,1,0);
 double sms[]={51,175,47,49,44,54,145,203,21,59,42,100};
 r=st_t_mean(st_mean(sms,12),50,st_sd_pop(sms,12),12,.05,ST_RIGHT);
 eq("Guia11 mensajes t",r.statistic,1.892,0.01);
 eq("Guia11 mensajes rechazo",r.reject,1,0);
 double meds[]={9.2,8.7,8.9,8.6,8.8,8.5,8.7,9.0};
 r=st_t_mean(st_mean(meds,8),9,st_sd_pop(meds,8),8,.01,ST_LEFT);
 eq("Guia11 medicamentos t",r.statistic,-2.494,0.01);
 eq("Guia11 meds no rechaza",r.reject,0,0);
 double a[]={10,6,4,5,4},b[]={4,8,6,6,2,3};
 r=st_t_pooled(st_mean(a,5),st_mean(b,6),st_sd_pop(a,5),st_sd_pop(b,6),5,6,.05,ST_TWO);
 eq("Guia11 grupos t",r.statistic,0.680,0.01);
 eq("Guia11 grupos gl",r.df,9,0);
 /* Guia 12 */
 double ob1[]={45,30,40,35,50},ex1[]={40,40,40,40,40};
 r=st_chi_gof(5,ob1,ex1,0,.05);eq("Guia12 libros chi",r.statistic,6.25,1e-10);
 double tab2[]={10,30,20,20,25,15};
 r=st_chi_independence(2,3,tab2,.05,0);eq("Guia12 asistencia chi",r.statistic,4.5021645,0.0001);
 double ob3[]={10,50,30},ex3[]={10,40,40};
 r=st_chi_gof(3,ob3,ex3,0,.05);eq("Guia12 canicas chi",r.statistic,5,1e-10);
 double tab4[]={40,30,30,50,20,30};
 r=st_chi_independence(2,3,tab4,.01,0);eq("Guia12 lenguaje chi",r.statistic,3.11111111,1e-6);
 double ob5[]={120,60,20},ex5[]={120,60,20};
 r=st_chi_gof(3,ob5,ex5,0,.01);eq("Guia12 seguros chi",r.statistic,0,1e-10);
 /* Guia 13 */
 double jobs[]={20,50,30,30,90,80};
 r=st_chi_independence(2,3,jobs,.05,0);eq("Guia13 trabajo chi",r.statistic,3.17532467,0.002);
 r=st_z_prop(340,500,.7,.05,ST_LEFT);
 eq("Guia13 clientes Z",r.statistic,-.9759,0.005);
 double before[]={54.2,58,50.5,62.1,55,53.3,59.8,56.4};
 double after[]={51.5,56.2,50,59.4,53.8,52.5,57,55.1};
 double d[8];for(int i=0;i<8;i++)d[i]=before[i]-after[i];
 r=st_t_mean(st_mean(d,8),0,st_sd_pop(d,8),8,.01,ST_RIGHT);
 eq("Guia13 atletas t",r.statistic,5.326,0.008);
 r=st_z_means(45.2,42.8,5.4,5.1,45,50,.01,ST_RIGHT);
 eq("Guia13 norte sur Z",r.statistic,2.221,0.005);
 double families[]={10,58,112,98,22},expected[]={18.75,75,112.5,75,18.75};
 r=st_chi_gof(5,families,expected,0,.05);
 eq("Guia13 familias chi",r.statistic,15.5555555556,0.008);
 /* Casos raros */
 eq("Yates 2x2",st_chi_independence(2,2,(double[]){1,9,11,3},.05,1).statistic,8.4,1.0);
 eq("Fisher 2x2",st_fisher_2x2(1,9,11,3,ST_TWO),0.002759456,1e-6);
 r=st_chi_variance(10,3,2,.05,ST_TWO);eq("Var ji2",r.statistic,22.5,1e-12);
 r=st_t_ci(10,2,9,.95);eq("IC t lower",r.lower,10-st_t_inv(.975,8)*2/sqrt(8),1e-9);
 r=st_chi_ci_sigma(9,2,.95);eq("IC sig min",r.lower,sqrt(9*4/st_chi_inv(.975,8)),1e-8);
 eq("F crit q95 4,8",st_f_inv(.95,4,8),3.837853,1e-5);
 eq("Bin exacta left",st_binom_exact(0,10,.5,.05,ST_LEFT).p,1./1024,1e-10);
 eq("Bin exacta two",st_binom_exact(0,10,.5,.05,ST_TWO).p,2./1024,1e-10);
 eq("No acepta x fracc",st_z_prop(1.5,10,.5,.05,ST_TWO).ok,0,0);
 printf("%d / %d tests passed\n",okcount,okcount);return 0;
}
