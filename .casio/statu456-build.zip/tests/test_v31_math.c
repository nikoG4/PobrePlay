#include "../src/stats.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
static int count=0;
static void check(const char *name,double got,double expected,double eps){
  if(!isfinite(got)||fabs(got-expected)>eps){fprintf(stderr,"FAIL %s actual %.12g esperado %.12g\n",name,got,expected);exit(1);}++count;
}
int main(){
  STResult f=st_f_test(90./40.,50./60.,9,14,.05,ST_RIGHT);
  check("F original",f.statistic,2.7,1e-10);
  check("F p derecha",f.p,0.046663392,1e-5);
  double A[]={.28,.30,.27,.33,.31};double sum=st_mean(A,5),ss=st_sd_pop(A,5);
  STResult ci=st_t_ci(sum,ss,5,.95);
  check("Media datos",sum,.298,1e-12);
  check("s divide n",ss,sqrt(.00228/5),1e-12);
  check("IC inferior",ci.lower,.268355948,1e-5);
  check("IC superior",ci.upper,.327644052,1e-5);
  double O[]={22,34,66,16,12},P[]={.12,.18,.40,.18,.12},E[5];
  for(int j=0;j<5;j++)E[j]=150*P[j];
  STResult gof=st_chi_gof(5,O,E,0,.05);
  check("Ji2 %",gof.statistic,9.785185185185185,1e-9);
  check("gl %",gof.df,4,0);
  check("p ji2 %",gof.p,0.044211,3e-4);
  STResult sumchi=st_chi_test(8.3+9.1+8.9+7.8+8.6,20,.05,ST_RIGHT);
  check("Ji2 cinco",sumchi.statistic,42.7,1e-9);
  check("p cinco",sumchi.p,0.002238,2e-5);
  double d=fmax(0,fabs(37.-30.)-0.5);
  STResult cy=st_chi_test(d*d/30.+d*d/30.,1,.05,ST_RIGHT);
  check("Yates 1x2",cy.statistic,2.8166666666666664,1e-12);
  /* A la izquierda con 50 intentos, x=14 no rechaza y x=13 si. */
  STResult x14=st_binom_exact(14,50,.4,.05,ST_LEFT),x13=st_binom_exact(13,50,.4,.05,ST_LEFT);
  check("Region x14 no",x14.reject,0,0);
  check("Region x13 si",x13.reject,1,0);
  printf("%d pruebas especificas V3.1 PASS\n",count);
  return 0;
}
